<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Pancoran Mas</name>
   <tag></tag>
   <elementGuidId>2319c736-b883-4864-879b-00982ff54cb0</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//fieldset[@id='dashboardForm-p-0']/div/div/div/div/div/div[3]/div[8]/div[2]/div/div/div/div/div/ul/li[9]/a/span[2]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.dropdown-menu.show > div.inner.show > ul.dropdown-menu.inner.show > li.selected.active > a.dropdown-item.selected.active > span.text</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>7aa7b574-e07f-439d-bd96-49d3c0460a9a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>text</value>
      <webElementGuid>753f3055-5cd6-4a5f-9d1b-4e5eaeba1652</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Pancoran Mas</value>
      <webElementGuid>3b459047-5e70-4312-b31c-91004fc0f94a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;dashboardForm-p-0&quot;)/div[@class=&quot;row no-gutters py-2 mt-3&quot;]/div[@class=&quot;col-lg-12&quot;]/div[@class=&quot;body body-verifikasi&quot;]/div[@class=&quot;row no-gutters bg-delta p-3 p-lg-4 text-alfa&quot;]/div[@class=&quot;col&quot;]/div[@class=&quot;form-row double-column&quot;]/div[@class=&quot;col-md-6&quot;]/div[2]/div[@class=&quot;form-group&quot;]/div[@class=&quot;form-line&quot;]/div[@class=&quot;dropdown bootstrap-select form-control ms show&quot;]/div[@class=&quot;dropdown-menu show&quot;]/div[@class=&quot;inner show&quot;]/ul[@class=&quot;dropdown-menu inner show&quot;]/li[@class=&quot;selected active&quot;]/a[@class=&quot;dropdown-item selected active&quot;]/span[@class=&quot;text&quot;]</value>
      <webElementGuid>b7bf2582-c043-45f6-99bd-c8bc1442ae98</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//fieldset[@id='dashboardForm-p-0']/div/div/div/div/div/div[3]/div[8]/div[2]/div/div/div/div/div/ul/li[9]/a/span[2]</value>
      <webElementGuid>dca93783-abf8-48b5-b4f7-9ecb1b9b384a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Limo'])[2]/following::span[2]</value>
      <webElementGuid>afb24f31-a4e0-4c77-ac63-635c6105d676</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Cipayung/Depok'])[2]/following::span[4]</value>
      <webElementGuid>fc82b0a3-8bab-4b72-9f49-2c0992900580</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sawangan'])[2]/preceding::span[2]</value>
      <webElementGuid>3cf0af90-c9ea-4703-96c9-b872ecfddc76</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sukmajaya'])[2]/preceding::span[4]</value>
      <webElementGuid>175c0c96-d7e3-4f98-94e4-c75e1b118989</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[8]/div[2]/div/div/div/div/div/ul/li[9]/a/span[2]</value>
      <webElementGuid>031e1514-52b6-416e-8f02-8f1ea6751acf</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Pancoran Mas' or . = 'Pancoran Mas')]</value>
      <webElementGuid>6bd7dd34-819a-42cf-8bbc-c48c840d4605</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
