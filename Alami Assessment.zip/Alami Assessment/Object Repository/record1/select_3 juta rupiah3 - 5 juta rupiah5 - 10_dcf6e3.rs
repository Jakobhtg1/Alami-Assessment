<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>select_3 juta rupiah3 - 5 juta rupiah5 - 10_dcf6e3</name>
   <tag></tag>
   <elementGuidId>f9086e48-93b2-4d92-87ad-55714ed223f3</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//select[@id='monthlyIncome']</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#monthlyIncome</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>select</value>
      <webElementGuid>35a51a90-bfb4-408a-8eec-a94c2e2a29a5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>name</name>
      <type>Main</type>
      <value>user.rdlMonthlyIncome.id</value>
      <webElementGuid>f7d7e1c1-42ac-49a5-bf00-4e9650eea40b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>form-control ms</value>
      <webElementGuid>908ae0a6-7018-4e7f-b52b-b4d29ad3f4f8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>monthlyIncome</value>
      <webElementGuid>a860c787-8f2b-4bc3-8a35-d3f3ef185f1d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-size</name>
      <type>Main</type>
      <value>5</value>
      <webElementGuid>c2df7dae-101a-4171-b456-5f64ced23d9d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tabindex</name>
      <type>Main</type>
      <value>-98</value>
      <webElementGuid>cf2e5c2b-12a8-4b2e-91b4-300d1e0d83fd</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-required</name>
      <type>Main</type>
      <value>true</value>
      <webElementGuid>0a55d71f-438b-4c2a-947f-e5a715ec0d04</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
							                                            &lt; 3 juta rupiah
3 - 5 juta rupiah
5 - 10 juta rupiah
10 - 20 juta rupiah
20 - 50 juta rupiah
50 - 100 juta rupiah
100 - 500 juta rupiah
> 500 juta rupiah
</value>
      <webElementGuid>e9608489-a1e2-461c-a1a4-4f2aa5875b17</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;dashboardForm-p-0&quot;)/div[@class=&quot;row no-gutters py-2 mt-3&quot;]/div[@class=&quot;col-lg-12&quot;]/div[@class=&quot;body body-verifikasi&quot;]/div[@class=&quot;row no-gutters bg-delta p-3 p-lg-4 text-alfa&quot;]/div[@class=&quot;col&quot;]/div[@class=&quot;form-row double-column&quot;]/div[@class=&quot;col-md-6&quot;]/div[2]/div[@class=&quot;form-group&quot;]/div[@class=&quot;form-line&quot;]/div[@class=&quot;dropdown bootstrap-select form-control ms dropup show&quot;]/select[@id=&quot;monthlyIncome&quot;]</value>
      <webElementGuid>7e488f3d-b2e9-4249-a9c9-68a3f72264b7</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//select[@id='monthlyIncome']</value>
      <webElementGuid>4324deda-ece3-4462-9886-dab17bb944ac</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//fieldset[@id='dashboardForm-p-0']/div/div/div/div/div/div[4]/div[4]/div[2]/div/div/div/select</value>
      <webElementGuid>8f37f305-5783-40ae-8e6c-950d4b8854e5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Penghasilan Bulanan'])[1]/following::select[1]</value>
      <webElementGuid>2022811d-490d-4904-9a6a-23b28580bde7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Lainnya'])[4]/following::select[1]</value>
      <webElementGuid>5b702634-5efc-4958-94df-cd43b9803828</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Tidak ada yang dipilih'])[11]/preceding::select[1]</value>
      <webElementGuid>29501864-9237-4e71-a995-2624e5d51406</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='&lt; 3 juta rupiah'])[2]/preceding::select[1]</value>
      <webElementGuid>9ff2cb2b-3c9f-4c14-8eeb-7e2c9235091a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[4]/div[2]/div/div/div/select</value>
      <webElementGuid>7429a6cf-8ea0-4bc6-8f85-b258a697c2f1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//select[@name = 'user.rdlMonthlyIncome.id' and @id = 'monthlyIncome' and (text() = '
							                                            &lt; 3 juta rupiah
3 - 5 juta rupiah
5 - 10 juta rupiah
10 - 20 juta rupiah
20 - 50 juta rupiah
50 - 100 juta rupiah
100 - 500 juta rupiah
> 500 juta rupiah
' or . = '
							                                            &lt; 3 juta rupiah
3 - 5 juta rupiah
5 - 10 juta rupiah
10 - 20 juta rupiah
20 - 50 juta rupiah
50 - 100 juta rupiah
100 - 500 juta rupiah
> 500 juta rupiah
')]</value>
      <webElementGuid>fe435d79-2691-457d-99c6-c08c392b0d36</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
