<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>select_Individual - WNI (Mewakili Diri Send_a6f99a</name>
   <tag></tag>
   <elementGuidId>3793f56d-14f2-4604-b91a-2377bd71ce31</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//select[@id='tipeAkun']</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#tipeAkun</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>select</value>
      <webElementGuid>6c63d6a6-df57-4516-ab4e-760cc13313d5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>name</name>
      <type>Main</type>
      <value>tipeAkun</value>
      <webElementGuid>ba7fe258-8200-4dc9-b816-3ae4cebd7251</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>form-control ms is-invalid</value>
      <webElementGuid>2610d417-64f6-4789-a252-ac2130614a71</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>tipeAkun</value>
      <webElementGuid>d1838d39-cab0-4aa5-8dc4-f715d252abb3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>onchange</name>
      <type>Main</type>
      <value>tipeAkunChange(this)</value>
      <webElementGuid>2ce277f0-c3b3-408b-9244-0b8b23d4d39a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tabindex</name>
      <type>Main</type>
      <value>-98</value>
      <webElementGuid>599c48d4-9b97-4ee5-9867-32386c79c704</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-required</name>
      <type>Main</type>
      <value>true</value>
      <webElementGuid>bf31e0f7-d338-4381-b29a-f4102fd00f49</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                                                                            
                                                                                Individual - WNI (Mewakili Diri Sendiri)
                                                                            
                                                                                Individual - WNA (Mewakili Diri Sendiri)
                                                                            
                                                                                Badan Hukum - WNI (Mewakili Suatu Badan Hukum)
                                                                            
                                                                        </value>
      <webElementGuid>890e2ed6-3782-4801-9564-5a1a1fa91c56</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;tipeAkun&quot;)</value>
      <webElementGuid>cc9cc3e7-ca3b-4373-9747-a5494fc25b33</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//select[@id='tipeAkun']</value>
      <webElementGuid>9db02305-11b4-4adb-86c6-9f2a9f6923d1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//fieldset[@id='dashboardForm-p-0']/div/div/div/div/div/div/div[2]/div[2]/div/div/div/select</value>
      <webElementGuid>8bc44c0a-1d0f-4113-8b16-b1c366ce0c83</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Tipe Akun'])[1]/following::select[1]</value>
      <webElementGuid>d900492e-e28d-4544-b174-879ec540ad9e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Tipe Akun Pemberi Dana'])[1]/following::select[1]</value>
      <webElementGuid>1b06c700-a449-4b43-a4be-72684508c8bb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Tidak ada yang dipilih'])[1]/preceding::select[1]</value>
      <webElementGuid>a8cf80f0-65d1-43cf-a975-c85da7750adc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Individual - WNI (Mewakili Diri Sendiri)'])[2]/preceding::select[1]</value>
      <webElementGuid>fdd0593e-d222-4dc2-b570-34f67b87658c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//select</value>
      <webElementGuid>26bfbadc-19b6-45a2-bfa5-17d7ddaf8b7b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//select[@name = 'tipeAkun' and @id = 'tipeAkun' and (text() = '
                                                                            
                                                                                Individual - WNI (Mewakili Diri Sendiri)
                                                                            
                                                                                Individual - WNA (Mewakili Diri Sendiri)
                                                                            
                                                                                Badan Hukum - WNI (Mewakili Suatu Badan Hukum)
                                                                            
                                                                        ' or . = '
                                                                            
                                                                                Individual - WNI (Mewakili Diri Sendiri)
                                                                            
                                                                                Individual - WNA (Mewakili Diri Sendiri)
                                                                            
                                                                                Badan Hukum - WNI (Mewakili Suatu Badan Hukum)
                                                                            
                                                                        ')]</value>
      <webElementGuid>4b64f345-fb8a-4a5e-a221-2c4cbb377a99</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
