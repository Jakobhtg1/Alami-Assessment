<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>select_Gaji</name>
   <tag></tag>
   <elementGuidId>89102d2e-dcda-4367-a9d4-9cebe6a03a28</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//select[@id='monthlyIncome']</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#monthlyIncome</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>select</value>
      <webElementGuid>29a3f889-a834-4596-b31e-94235a0d2ff6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>name</name>
      <type>Main</type>
      <value>user.rdlMonthlyIncome.id</value>
      <webElementGuid>effb90eb-e2e4-4608-b318-b8268c2f4a57</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>form-control ms</value>
      <webElementGuid>cc98d9e9-8213-4458-92ff-00a791e6f0ab</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>monthlyIncome</value>
      <webElementGuid>3036f848-03e0-453a-b66f-6fab39f06d7b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-size</name>
      <type>Main</type>
      <value>5</value>
      <webElementGuid>c8d35125-44a0-4251-a6c7-329a59dbe581</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tabindex</name>
      <type>Main</type>
      <value>-98</value>
      <webElementGuid>3138dcf6-e45a-4640-8756-34c7aabac471</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-required</name>
      <type>Main</type>
      <value>true</value>
      <webElementGuid>9f1c3323-8fc9-4358-b604-eef332d91336</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
							                                            &lt; 3 juta rupiah
3 - 5 juta rupiah
5 - 10 juta rupiah
10 - 20 juta rupiah
20 - 50 juta rupiah
50 - 100 juta rupiah
100 - 500 juta rupiah
> 500 juta rupiah
</value>
      <webElementGuid>0ad45a1d-336b-4278-a507-cbbe3aed9363</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;dashboardForm-p-0&quot;)/div[@class=&quot;row no-gutters py-2 mt-3&quot;]/div[@class=&quot;col-lg-12&quot;]/div[@class=&quot;body body-verifikasi&quot;]/div[@class=&quot;row no-gutters bg-delta p-3 p-lg-4 text-alfa&quot;]/div[@class=&quot;col&quot;]/div[@class=&quot;form-row double-column&quot;]/div[@class=&quot;col-md-6&quot;]/div[2]/div[@class=&quot;form-group&quot;]/div[@class=&quot;form-line&quot;]/div[@class=&quot;dropdown bootstrap-select form-control ms dropup show&quot;]/select[@id=&quot;monthlyIncome&quot;]</value>
      <webElementGuid>e6e15e7a-73c2-4aab-8db2-a6cd170fca7c</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//select[@id='monthlyIncome']</value>
      <webElementGuid>851378e9-3500-4e83-a492-f3abda587cdf</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//fieldset[@id='dashboardForm-p-0']/div/div/div/div/div/div[4]/div[4]/div[2]/div/div/div/select</value>
      <webElementGuid>747d590a-66f8-4a8b-ba95-00ee666897b7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Penghasilan Bulanan'])[1]/following::select[1]</value>
      <webElementGuid>29aa9f65-9694-4569-94a0-3a1f9e783b02</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Lainnya'])[3]/following::select[1]</value>
      <webElementGuid>43074836-e4f7-42aa-a515-0aa2b8a3e4ca</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Tidak ada yang dipilih'])[3]/preceding::select[1]</value>
      <webElementGuid>20ff5919-a8e8-4acb-9fe9-592ef903c244</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='&lt; 3 juta rupiah'])[2]/preceding::select[1]</value>
      <webElementGuid>6fde7d96-7b28-473a-9e1e-1ee21c4ab68c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[4]/div[2]/div/div/div/select</value>
      <webElementGuid>0f4e8ed5-ad4a-466d-8c08-21c9b4307d0e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//select[@name = 'user.rdlMonthlyIncome.id' and @id = 'monthlyIncome' and (text() = '
							                                            &lt; 3 juta rupiah
3 - 5 juta rupiah
5 - 10 juta rupiah
10 - 20 juta rupiah
20 - 50 juta rupiah
50 - 100 juta rupiah
100 - 500 juta rupiah
> 500 juta rupiah
' or . = '
							                                            &lt; 3 juta rupiah
3 - 5 juta rupiah
5 - 10 juta rupiah
10 - 20 juta rupiah
20 - 50 juta rupiah
50 - 100 juta rupiah
100 - 500 juta rupiah
> 500 juta rupiah
')]</value>
      <webElementGuid>9621d1a5-9a79-4c29-9ad1-6f896c6901dd</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
