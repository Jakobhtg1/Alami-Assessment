<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>select_DepokDepok JayaMampangPancoran MasRa_9f44f1</name>
   <tag></tag>
   <elementGuidId>f85b0b48-6d90-4d5d-8a71-4ce3e4c6f91e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//select[@id='regency']</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#regency</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>select</value>
      <webElementGuid>622b8f99-809f-4fc1-8f42-f6ea1f6b9d2f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>name</name>
      <type>Main</type>
      <value>user.location.id</value>
      <webElementGuid>87167907-12ad-46d3-abae-8d7157dd08a3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>form-control ms is-invalid</value>
      <webElementGuid>8cec1591-8f40-417a-915d-77807d66c408</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>regency</value>
      <webElementGuid>9696ae8c-0038-476f-a595-7d5499ef6fe5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-size</name>
      <type>Main</type>
      <value>5</value>
      <webElementGuid>2b57c0b5-27ac-4194-9abc-b3cf25e12a91</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>onchange</name>
      <type>Main</type>
      <value>regencyChange(this)</value>
      <webElementGuid>11b1c3cc-a791-40d7-a3a9-7f9dc12ae97b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-required</name>
      <type>Main</type>
      <value>true</value>
      <webElementGuid>5a8d10b0-febf-4587-96b6-fcc00f8fc653</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tabindex</name>
      <type>Main</type>
      <value>-98</value>
      <webElementGuid>8891730f-0af3-46aa-a85c-6e2589950c2e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-invalid</name>
      <type>Main</type>
      <value>true</value>
      <webElementGuid>402c4468-ab82-4429-b2aa-77090c272554</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
																		Depok
Depok Jaya
Mampang
Pancoran Mas
Rangkapan Jaya Baru (Rangkapanjaya Baru)
Rangkapan Jaya (Rangkapanjaya)
</value>
      <webElementGuid>fc36e22f-af68-4144-8c10-e98dd53ff498</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;regency&quot;)</value>
      <webElementGuid>8c34dbfe-3200-4517-9eeb-6e9078cc6ed9</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//select[@id='regency']</value>
      <webElementGuid>21c5d0a6-c38a-4d63-99c5-c06f0c225ff1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//fieldset[@id='dashboardForm-p-0']/div/div/div/div/div/div[3]/div[9]/div[2]/div/div/div/select</value>
      <webElementGuid>cab385d8-f7bb-496e-973c-f41598ca0c6a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Kelurahan / Desa'])[1]/following::select[1]</value>
      <webElementGuid>05e02d3e-a44b-4c3d-8456-0c916fa4c361</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Tapos'])[2]/following::select[1]</value>
      <webElementGuid>cdb87d30-e567-4288-9193-d0587813f0fd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Tidak ada yang dipilih'])[6]/preceding::select[1]</value>
      <webElementGuid>3dc84a7f-678c-4ac6-b340-f076af6752fb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Depok'])[2]/preceding::select[1]</value>
      <webElementGuid>448637cb-0a06-4e06-9450-18a07e2b82e5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/div[9]/div[2]/div/div/div/select</value>
      <webElementGuid>e2afabcf-0f20-4997-ba74-2e76db275f95</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//select[@name = 'user.location.id' and @id = 'regency' and (text() = '
																		Depok
Depok Jaya
Mampang
Pancoran Mas
Rangkapan Jaya Baru (Rangkapanjaya Baru)
Rangkapan Jaya (Rangkapanjaya)
' or . = '
																		Depok
Depok Jaya
Mampang
Pancoran Mas
Rangkapan Jaya Baru (Rangkapanjaya Baru)
Rangkapan Jaya (Rangkapanjaya)
')]</value>
      <webElementGuid>04fbb58d-c556-4474-a2cc-51d6b071d43a</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
