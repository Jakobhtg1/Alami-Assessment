<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>select_Pekerjaan</name>
   <tag></tag>
   <elementGuidId>ee248884-c17e-4a88-808b-54be34463c18</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//select[@id='pekerjaan']</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#pekerjaan</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>select</value>
      <webElementGuid>22a2e675-f726-4233-9458-7a199fd1fbb7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>name</name>
      <type>Main</type>
      <value>user.rdlJob.id</value>
      <webElementGuid>009133a5-3c5c-4259-b81c-b614635920f8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>form-control ms</value>
      <webElementGuid>b6e83ce1-5ec4-4187-949f-12effd3ed7fd</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>pekerjaan</value>
      <webElementGuid>c4189ab9-9c12-459d-ba7e-00bb1c9ad968</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>onchange</name>
      <type>Main</type>
      <value>rdlJobChange(this)</value>
      <webElementGuid>6b59d126-2e30-4021-952e-c727fdc9a7f1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-required</name>
      <type>Main</type>
      <value>true</value>
      <webElementGuid>13cd658d-fe6e-48c0-9165-d4a264612193</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tabindex</name>
      <type>Main</type>
      <value>-98</value>
      <webElementGuid>8822e5e0-8d24-40e8-aff8-fe261dc6fe00</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
							                                            Pegawai Negeri
Pegawai Swasta
Pegawai BUMN/BUMD
TNI/POLRI
Pedagang
Petani/Nelayan
Pelajar/Mahasiswa
Ibu Rumah Tangga
Tidak Bekerja
Wiraswasta
Pejabat Negara
Akuntan
Pengacara/Notaris
Profesi
Pensiunan
Dosen/Guru Swasta
Dosen/Guru Negeri
Dokter
Pegawai BNI
Unit Afiliasi BNI
Lain-lain
</value>
      <webElementGuid>e0a467f8-7856-44e6-99cc-44d056d6615c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;pekerjaan&quot;)</value>
      <webElementGuid>25d2efb2-4fab-4721-b780-1cb6c6f57ace</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//select[@id='pekerjaan']</value>
      <webElementGuid>4f9964ae-5a55-40a7-892c-6805c80be151</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//fieldset[@id='dashboardForm-p-0']/div/div/div/div/div/div[4]/div[2]/div[2]/div/div/div/select</value>
      <webElementGuid>65f8186b-7bf6-418a-93c4-e8c94699c1b2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Pekerjaan'])[1]/following::select[1]</value>
      <webElementGuid>895893a2-7930-486a-a4e0-cf4835485d7c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Informasi Pekerjaan'])[1]/following::select[1]</value>
      <webElementGuid>b8845890-f766-4f5e-877a-95d5e8882c36</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Tidak ada yang dipilih'])[2]/preceding::select[1]</value>
      <webElementGuid>c2478f44-7c25-4da5-bc9e-681c1affc566</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Pegawai Negeri'])[2]/preceding::select[1]</value>
      <webElementGuid>a8f14209-2fd2-458f-b396-1ce46817cc1b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[4]/div[2]/div[2]/div/div/div/select</value>
      <webElementGuid>8e942e1e-6337-4691-8098-85a6a3a1e641</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//select[@name = 'user.rdlJob.id' and @id = 'pekerjaan' and (text() = '
							                                            Pegawai Negeri
Pegawai Swasta
Pegawai BUMN/BUMD
TNI/POLRI
Pedagang
Petani/Nelayan
Pelajar/Mahasiswa
Ibu Rumah Tangga
Tidak Bekerja
Wiraswasta
Pejabat Negara
Akuntan
Pengacara/Notaris
Profesi
Pensiunan
Dosen/Guru Swasta
Dosen/Guru Negeri
Dokter
Pegawai BNI
Unit Afiliasi BNI
Lain-lain
' or . = '
							                                            Pegawai Negeri
Pegawai Swasta
Pegawai BUMN/BUMD
TNI/POLRI
Pedagang
Petani/Nelayan
Pelajar/Mahasiswa
Ibu Rumah Tangga
Tidak Bekerja
Wiraswasta
Pejabat Negara
Akuntan
Pengacara/Notaris
Profesi
Pensiunan
Dosen/Guru Swasta
Dosen/Guru Negeri
Dokter
Pegawai BNI
Unit Afiliasi BNI
Lain-lain
')]</value>
      <webElementGuid>e80c825d-5a74-4569-b1e5-683c28b7861d</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
