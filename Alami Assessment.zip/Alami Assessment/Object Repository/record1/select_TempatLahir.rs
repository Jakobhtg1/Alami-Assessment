<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>select_TempatLahir</name>
   <tag></tag>
   <elementGuidId>6aa20011-a551-43b0-a69f-352f66326d9b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//fieldset[@id='dashboardForm-p-0']/div/div/div/div/div/div[2]/div[7]/div[2]/div/div/div/select</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>select.form-control.ms.select-all-cities</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>select</value>
      <webElementGuid>a9c381bf-737e-4262-bfe1-411e254e5e93</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>form-control ms select-all-cities</value>
      <webElementGuid>ca6708d9-9c0d-4b47-be80-1f6e923da805</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-live-search</name>
      <type>Main</type>
      <value>true</value>
      <webElementGuid>1ba44335-4151-4933-a795-5f480ad49b85</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-size</name>
      <type>Main</type>
      <value>5</value>
      <webElementGuid>ea936e36-858d-4cb0-80b2-9de8293417af</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tabindex</name>
      <type>Main</type>
      <value>-98</value>
      <webElementGuid>593e771d-20de-4eb0-b350-eeb903845b96</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Kab. Aceh Barat
Kab. Aceh Barat Daya
Kab. Aceh Besar
Kab. Aceh Jaya
Kab. Aceh Selatan
Kab. Aceh Singkil
Kab. Aceh Tamiang
Kab. Aceh Tengah
Kab. Aceh Tenggara
Kab. Aceh Timur
Kab. Aceh Utara
Kab. Agam
Kab. Alor
Kab. Asahan
Kab. Asmat
Kab. Badung
Kab. Balangan
Kab. Bandung
Kab. Bandung Barat
Kab. Banggai
Kab. Banggai Kepulauan
Kab. Banggai Laut
Kab. Bangka
Kab. Bangka Barat
Kab. Bangkalan
Kab. Bangka Selatan
Kab. Bangka Tengah
Kab. Bangli
Kab. Banjar
Kab. Banjarnegara
Kab. Bantaeng
Kab. Bantul
Kab. Banyuasin
Kab. Banyumas
Kab. Banyuwangi
Kab. Barito Kuala
Kab. Barito Selatan
Kab. Barito Timur
Kab. Barito Utara
Kab. Barru
Kab. Batang
Kab. Batang Hari
Kab. Batu Bara
Kab. Bekasi
Kab. Belitung
Kab. Belitung Timur
Kab. Belu
Kab. Bener Meriah
Kab. Bengkalis
Kab. Bengkayang
Kab. Bengkulu Selatan
Kab. Bengkulu Tengah
Kab. Bengkulu Utara
Kab. Berau
Kab. Biak Numfor
Kab. Bima
Kab. Bintan
Kab. Bireuen
Kab. Blitar
Kab. Blora
Kab. Boalemo
Kab. Bogor
Kab. Bojonegoro
Kab. Bolaang Mongondow
Kab. Bolaang Mongondow Selatan
Kab. Bolaang Mongondow Timur
Kab. Bolaang Mongondow Utara
Kab. Bombana
Kab. Bondowoso
Kab. Bone
Kab. Bone Bolango
Kab. Boven Digoel
Kab. Boyolali
Kab. Brebes
Kab. Buleleng
Kab. Bulukumba
Kab. Bulungan
Kab. Bungo
Kab. Buol
Kab. Buru
Kab. Buru Selatan
Kab. Buton
Kab. Buton Selatan
Kab. Buton Tengah
Kab. Buton Utara
Kab. Ciamis
Kab. Cianjur
Kab. Cilacap
Kab. Cirebon
Kab. Dairi
Kab. Deiyai
Kab. Deli Serdang
Kab. Demak
Kab. Dharmasraya
Kab. Dogiyai
Kab. Dompu
Kab. Donggala
Kab. Empat Lawang
Kab. Ende
Kab. Enrekang
Kab. Fakfak
Kab. Flores Timur
Kab. Garut
Kab. Gayo Lues
Kab. Gianyar
Kab. Gorontalo
Kab. Gorontalo Utara
Kab. Gowa
Kab. Gresik
Kab. Grobogan
Kab. Gunung Kidul
Kab. Gunung Mas
Kab. Halmahera Barat
Kab. Halmahera Selatan
Kab. Halmahera Tengah
Kab. Halmahera Timur
Kab. Halmahera Utara
Kab. Hulu Sungai Selatan
Kab. Hulu Sungai Tengah
Kab. Hulu Sungai Utara
Kab. Humbang Hasundutan
Kab. Indragiri Hilir
Kab. Indragiri Hulu
Kab. Indramayu
Kab. Intan Jaya
Kab. Jayapura
Kab. Jayawijaya
Kab. Jember
Kab. Jembrana
Kab. Jeneponto
Kab. Jepara
Kab. Jombang
Kab. Kaimana
Kab. Kampar
Kab. Kapuas
Kab. Kapuas Hulu
Kab. Karanganyar
Kab. Karangasem
Kab. Karawang
Kab. Karimun
Kab. Karo
Kab. Katingan
Kab. Kaur
Kab. Kayong Utara
Kab. Kebumen
Kab. Kediri
Kab. Keerom
Kab. Kendal
Kab. Kepahiang
Kab. Kepulauan Anambas
Kab. Kepulauan Aru
Kab. Kepulauan Mentawai
Kab. Kepulauan Meranti
Kab. Kepulauan Sangihe
Kab. Kepulauan Selayar
Kab. Kepulauan Seribu
Kab. Kepulauan Siau Tagulandang Biaro (Sitaro)
Kab. Kepulauan Sula
Kab. Kepulauan Talaud
Kab. Kepulauan Yapen
Kab. Kerinci
Kab. Ketapang
Kab. Klaten
Kab. Klungkung
Kab. Kolaka
Kab. Kolaka Timur
Kab. Kolaka Utara
Kab. Konawe
Kab. Konawe Kepulauan
Kab. Konawe Selatan
Kab. Konawe Utara
Kab. Kotabaru
Kab. Kotawaringin Barat
Kab. Kotawaringin Timur
Kab. Kuantan Singingi
Kab. Kubu Raya
Kab. Kudus
Kab. Kulon Progo
Kab. Kuningan
Kab. Kupang
Kab. Kutai Barat
Kab. Kutai Kartanegara
Kab. Kutai Timur
Kab. Labuhanbatu
Kab. Labuhanbatu Selatan
Kab. Labuhanbatu Utara
Kab. Lahat
Kab. Lamandau
Kab. Lamongan
Kab. Lampung Barat
Kab. Lampung Selatan
Kab. Lampung Tengah
Kab. Lampung Timur
Kab. Lampung Utara
Kab. Landak
Kab. Langkat
Kab. Lanny Jaya
Kab. Lebak
Kab. Lebong
Kab. Lembata
Kab. Lima Puluh Kota
Kab. Lingga
Kab. Lombok Barat
Kab. Lombok Tengah
Kab. Lombok Timur
Kab. Lombok Utara
Kab. Lumajang
Kab. Luwu
Kab. Luwu Timur
Kab. Luwu Utara
Kab. Madiun
Kab. Magelang
Kab. Magetan
Kab. Mahakam Ulu
Kab. Majalengka
Kab. Majene
Kab. Malaka
Kab. Malang
Kab. Malinau
Kab. Maluku Barat Daya
Kab. Maluku Tengah
Kab. Maluku Tenggara
Kab. Maluku Tenggara Barat
Kab. Mamasa
Kab. Mamberamo Raya
Kab. Mamberamo Tengah
Kab. Mamuju
Kab. Mamuju Tengah
Kab. Mamuju Utara
Kab. Mandailing Natal
Kab. Manggarai
Kab. Manggarai Barat
Kab. Manggarai Timur
Kab. Manokwari
Kab. Manokwari Selatan
Kab. Mappi
Kab. Maros
Kab. Maybrat
Kab. Melawi
Kab. Mempawah
Kab. Merangin
Kab. Merauke
Kab. Mesuji
Kab. Mimika
Kab. Minahasa
Kab. Minahasa Selatan
Kab. Minahasa Tenggara
Kab. Minahasa Utara
Kab. Mojokerto
Kab. Morowali
Kab. Morowali Utara
Kab. Muara Enim
Kab. Muaro Jambi
Kab. Muko Muko
Kab. Muna
Kab. Muna Barat
Kab. Murung Raya
Kab. Musi Banyuasin
Kab. Musi Rawas
Kab. Musi Rawas Utara
Kab. Nabire
Kab. Nagan Raya
Kab. Nagekeo
Kab. Natuna
Kab. Nduga
Kab. Ngada
Kab. Nganjuk
Kab. Ngawi
Kab. Nias
Kab. Nias Barat
Kab. Nias Selatan
Kab. Nias Utara
Kab. Nunukan
Kab. Ogan Ilir
Kab. Ogan Komering Ilir
Kab. Ogan Komering Ulu
Kab. Ogan Komering Ulu Selatan
Kab. Ogan Komering Ulu Timur
Kab. Pacitan
Kab. Padang Lawas
Kab. Padang Lawas Utara
Kab. Padang Pariaman
Kab. Pakpak Bharat
Kab. Pamekasan
Kab. Pandeglang
Kab. Pangandaran
Kab. Pangkajene Kepulauan
Kab. Paniai
Kab. Parigi Moutong
Kab. Pasaman
Kab. Pasaman Barat
Kab. Paser
Kab. Pasuruan
Kab. Pati
Kab. Pegunungan Arfak
Kab. Pegunungan Bintang
Kab. Pekalongan
Kab. Pelalawan
Kab. Pemalang
Kab. Penajam Paser Utara
Kab. Penukal Abab Lematang Ilir
Kab. Pesawaran
Kab. Pesisir Barat
Kab. Pesisir Selatan
Kab. Pidie
Kab. Pidie Jaya
Kab. Pinrang
Kab. Pohuwato
Kab. Polewali Mandar
Kab. Ponorogo
Kab. Poso
Kab. Pringsewu
Kab. Probolinggo
Kab. Pulang Pisau
Kab. Pulau Morotai
Kab. Pulau Taliabu
Kab. Puncak
Kab. Puncak Jaya
Kab. Purbalingga
Kab. Purwakarta
Kab. Purworejo
Kab. Raja Ampat
Kab. Rejang Lebong
Kab. Rembang
Kab. Rokan Hilir
Kab. Rokan Hulu
Kab. Rote Ndao
Kab. Sabu Raijua
Kab. Sambas
Kab. Samosir
Kab. Sampang
Kab. Sanggau
Kab. Sarmi
Kab. Sarolangun
Kab. Sekadau
Kab. Seluma
Kab. Semarang
Kab. Seram Bagian Barat
Kab. Seram Bagian Timur
Kab. Serang
Kab. Serdang Bedagai
Kab. Seruyan
Kab. Siak
Kab. Sidenreng Rappang
Kab. Sidoarjo
Kab. Sigi
Kab. Sijunjung
Kab. Sikka
Kab. Simalungun
Kab. Simeulue
Kab. Sinjai
Kab. Sintang
Kab. Situbondo
Kab. Sleman
Kab. Solok
Kab. Solok Selatan
Kab. Soppeng
Kab. Sorong
Kab. Sorong Selatan
Kab. Sragen
Kab. Subang
Kab. Sukabumi
Kab. Sukamara
Kab. Sukoharjo
Kab. Sumba Barat
Kab. Sumba Barat Daya
Kab. Sumba Tengah
Kab. Sumba Timur
Kab. Sumbawa
Kab. Sumbawa Barat
Kab. Sumedang
Kab. Sumenep
Kab. Supiori
Kab. Tabalong
Kab. Tabanan
Kab. Takalar
Kab. Tambrauw
Kab. Tanah Bumbu
Kab. Tanah Datar
Kab. Tanah Laut
Kab. Tana Tidung
Kab. Tana Toraja
Kab. Tangerang
Kab. Tanggamus
Kab. Tanjung Jabung Barat
Kab. Tanjung Jabung Timur
Kab. Tapanuli Selatan
Kab. Tapanuli Tengah
Kab. Tapanuli Utara
Kab. Tapin
Kab. Tasikmalaya
Kab. Tebo
Kab. Tegal
Kab. Teluk Bintuni
Kab. Teluk Wondama
Kab. Temanggung
Kab. Timor Tengah Selatan
Kab. Timor Tengah Utara
Kab. Toba Samosir
Kab. Tojo Una-Una
Kab. Tolikara
Kab. Toli-Toli
Kab. Toraja Utara
Kab. Trenggalek
Kab. Tuban
Kab. Tulang Bawang
Kab. Tulang Bawang Barat
Kab. Tulungagung
Kab. Wajo
Kab. Wakatobi
Kab. Waropen
Kab. Way Kanan
Kab. Wonogiri
Kab. Wonosobo
Kab. Yahukimo
Kab. Yalimo
Kota Ambon
Kota Balikpapan
Kota Banda Aceh
Kota Bandar Lampung
Kota Bandung
Kota Banjar
Kota Banjarbaru
Kota Banjarmasin
Kota Batam
Kota Batu
Kota Bau-Bau
Kota Bekasi
Kota Bengkulu
Kota Bima
Kota Binjai
Kota Bitung
Kota Blitar
Kota Bogor
Kota Bontang
Kota Bukittinggi
Kota Cilegon
Kota Cimahi
Kota Cirebon
Kota Denpasar
Kota Depok
Kota Dumai
Kota Gorontalo
Kota Gunungsitoli
Kota Jakarta Barat
Kota Jakarta Pusat
Kota Jakarta Selatan
Kota Jakarta Timur
Kota Jakarta Utara
Kota Jambi
Kota Jayapura
Kota Kediri
Kota Kendari
Kota Kotamobagu
Kota Kupang
Kota Langsa
Kota Lhokseumawe
Kota Lubuk Linggau
Kota Madiun
Kota Magelang
Kota Makassar
Kota Malang
Kota Manado
Kota Mataram
Kota Medan
Kota Metro
Kota Mojokerto
Kota Padang
Kota Padang Panjang
Kota Padang Sidempuan
Kota Pagar Alam
Kota Palangka Raya
Kota Palembang
Kota Palopo
Kota Palu
Kota Pangkal Pinang
Kota Parepare
Kota Pariaman
Kota Pasuruan
Kota Payakumbuh
Kota Pekalongan
Kota Pekanbaru
Kota Pematang Siantar
Kota Pontianak
Kota Prabumulih
Kota Probolinggo
Kota Sabang
Kota Salatiga
Kota Samarinda
Kota Sawah Lunto
Kota Semarang
Kota Serang
Kota Sibolga
Kota Singkawang
Kota Solok
Kota Sorong
Kota Subulussalam
Kota Sukabumi
Kota Sungaipenuh
Kota Surabaya
Kota Surakarta
Kota Tangerang
Kota Tangerang Selatan
Kota Tanjung Balai
Kota Tanjung Pinang
Kota Tarakan
Kota Tasikmalaya
Kota Tebing Tinggi
Kota Tegal
Kota Ternate
Kota Tidore Kepulauan
Kota Tomohon
Kota Tual
Kota Yogyakarta
Lainnya
</value>
      <webElementGuid>42355d77-3c05-4d02-bb9a-509f013ae9b8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;dashboardForm-p-0&quot;)/div[@class=&quot;row no-gutters py-2 mt-3&quot;]/div[@class=&quot;col-lg-12&quot;]/div[@class=&quot;body body-verifikasi&quot;]/div[@class=&quot;row no-gutters bg-delta p-3 p-lg-4 text-alfa&quot;]/div[@class=&quot;col&quot;]/div[@class=&quot;form-row double-column&quot;]/div[@class=&quot;col-md-6&quot;]/div[2]/div[@class=&quot;form-group&quot;]/div[@class=&quot;form-line&quot;]/div[@class=&quot;dropdown bootstrap-select form-control ms select-all-cities show&quot;]/select[@class=&quot;form-control ms select-all-cities&quot;]</value>
      <webElementGuid>22762057-fd7d-4593-bdbb-0e60dd784a64</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//fieldset[@id='dashboardForm-p-0']/div/div/div/div/div/div[2]/div[7]/div[2]/div/div/div/select</value>
      <webElementGuid>c07ac16c-74f8-4bb6-9cfa-384aef576b1a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Tempat Lahir'])[1]/following::select[1]</value>
      <webElementGuid>0900ae39-07ca-4132-b24f-017d6ff742e6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='(+263)'])[1]/following::select[1]</value>
      <webElementGuid>4227cd6e-5743-460f-b50c-12abd10a768a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Tidak ada yang dipilih'])[1]/preceding::select[1]</value>
      <webElementGuid>f6de7f1b-cb65-4da2-85cd-4a65647d89bd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Kab. Pekalongan'])[2]/preceding::select[1]</value>
      <webElementGuid>01e6fb4b-0f77-4570-9495-08be178ad0a4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[7]/div[2]/div/div/div/select</value>
      <webElementGuid>aa1fd447-6805-4ee3-beac-785e7cb63a18</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//select[(text() = 'Kab. Aceh Barat
Kab. Aceh Barat Daya
Kab. Aceh Besar
Kab. Aceh Jaya
Kab. Aceh Selatan
Kab. Aceh Singkil
Kab. Aceh Tamiang
Kab. Aceh Tengah
Kab. Aceh Tenggara
Kab. Aceh Timur
Kab. Aceh Utara
Kab. Agam
Kab. Alor
Kab. Asahan
Kab. Asmat
Kab. Badung
Kab. Balangan
Kab. Bandung
Kab. Bandung Barat
Kab. Banggai
Kab. Banggai Kepulauan
Kab. Banggai Laut
Kab. Bangka
Kab. Bangka Barat
Kab. Bangkalan
Kab. Bangka Selatan
Kab. Bangka Tengah
Kab. Bangli
Kab. Banjar
Kab. Banjarnegara
Kab. Bantaeng
Kab. Bantul
Kab. Banyuasin
Kab. Banyumas
Kab. Banyuwangi
Kab. Barito Kuala
Kab. Barito Selatan
Kab. Barito Timur
Kab. Barito Utara
Kab. Barru
Kab. Batang
Kab. Batang Hari
Kab. Batu Bara
Kab. Bekasi
Kab. Belitung
Kab. Belitung Timur
Kab. Belu
Kab. Bener Meriah
Kab. Bengkalis
Kab. Bengkayang
Kab. Bengkulu Selatan
Kab. Bengkulu Tengah
Kab. Bengkulu Utara
Kab. Berau
Kab. Biak Numfor
Kab. Bima
Kab. Bintan
Kab. Bireuen
Kab. Blitar
Kab. Blora
Kab. Boalemo
Kab. Bogor
Kab. Bojonegoro
Kab. Bolaang Mongondow
Kab. Bolaang Mongondow Selatan
Kab. Bolaang Mongondow Timur
Kab. Bolaang Mongondow Utara
Kab. Bombana
Kab. Bondowoso
Kab. Bone
Kab. Bone Bolango
Kab. Boven Digoel
Kab. Boyolali
Kab. Brebes
Kab. Buleleng
Kab. Bulukumba
Kab. Bulungan
Kab. Bungo
Kab. Buol
Kab. Buru
Kab. Buru Selatan
Kab. Buton
Kab. Buton Selatan
Kab. Buton Tengah
Kab. Buton Utara
Kab. Ciamis
Kab. Cianjur
Kab. Cilacap
Kab. Cirebon
Kab. Dairi
Kab. Deiyai
Kab. Deli Serdang
Kab. Demak
Kab. Dharmasraya
Kab. Dogiyai
Kab. Dompu
Kab. Donggala
Kab. Empat Lawang
Kab. Ende
Kab. Enrekang
Kab. Fakfak
Kab. Flores Timur
Kab. Garut
Kab. Gayo Lues
Kab. Gianyar
Kab. Gorontalo
Kab. Gorontalo Utara
Kab. Gowa
Kab. Gresik
Kab. Grobogan
Kab. Gunung Kidul
Kab. Gunung Mas
Kab. Halmahera Barat
Kab. Halmahera Selatan
Kab. Halmahera Tengah
Kab. Halmahera Timur
Kab. Halmahera Utara
Kab. Hulu Sungai Selatan
Kab. Hulu Sungai Tengah
Kab. Hulu Sungai Utara
Kab. Humbang Hasundutan
Kab. Indragiri Hilir
Kab. Indragiri Hulu
Kab. Indramayu
Kab. Intan Jaya
Kab. Jayapura
Kab. Jayawijaya
Kab. Jember
Kab. Jembrana
Kab. Jeneponto
Kab. Jepara
Kab. Jombang
Kab. Kaimana
Kab. Kampar
Kab. Kapuas
Kab. Kapuas Hulu
Kab. Karanganyar
Kab. Karangasem
Kab. Karawang
Kab. Karimun
Kab. Karo
Kab. Katingan
Kab. Kaur
Kab. Kayong Utara
Kab. Kebumen
Kab. Kediri
Kab. Keerom
Kab. Kendal
Kab. Kepahiang
Kab. Kepulauan Anambas
Kab. Kepulauan Aru
Kab. Kepulauan Mentawai
Kab. Kepulauan Meranti
Kab. Kepulauan Sangihe
Kab. Kepulauan Selayar
Kab. Kepulauan Seribu
Kab. Kepulauan Siau Tagulandang Biaro (Sitaro)
Kab. Kepulauan Sula
Kab. Kepulauan Talaud
Kab. Kepulauan Yapen
Kab. Kerinci
Kab. Ketapang
Kab. Klaten
Kab. Klungkung
Kab. Kolaka
Kab. Kolaka Timur
Kab. Kolaka Utara
Kab. Konawe
Kab. Konawe Kepulauan
Kab. Konawe Selatan
Kab. Konawe Utara
Kab. Kotabaru
Kab. Kotawaringin Barat
Kab. Kotawaringin Timur
Kab. Kuantan Singingi
Kab. Kubu Raya
Kab. Kudus
Kab. Kulon Progo
Kab. Kuningan
Kab. Kupang
Kab. Kutai Barat
Kab. Kutai Kartanegara
Kab. Kutai Timur
Kab. Labuhanbatu
Kab. Labuhanbatu Selatan
Kab. Labuhanbatu Utara
Kab. Lahat
Kab. Lamandau
Kab. Lamongan
Kab. Lampung Barat
Kab. Lampung Selatan
Kab. Lampung Tengah
Kab. Lampung Timur
Kab. Lampung Utara
Kab. Landak
Kab. Langkat
Kab. Lanny Jaya
Kab. Lebak
Kab. Lebong
Kab. Lembata
Kab. Lima Puluh Kota
Kab. Lingga
Kab. Lombok Barat
Kab. Lombok Tengah
Kab. Lombok Timur
Kab. Lombok Utara
Kab. Lumajang
Kab. Luwu
Kab. Luwu Timur
Kab. Luwu Utara
Kab. Madiun
Kab. Magelang
Kab. Magetan
Kab. Mahakam Ulu
Kab. Majalengka
Kab. Majene
Kab. Malaka
Kab. Malang
Kab. Malinau
Kab. Maluku Barat Daya
Kab. Maluku Tengah
Kab. Maluku Tenggara
Kab. Maluku Tenggara Barat
Kab. Mamasa
Kab. Mamberamo Raya
Kab. Mamberamo Tengah
Kab. Mamuju
Kab. Mamuju Tengah
Kab. Mamuju Utara
Kab. Mandailing Natal
Kab. Manggarai
Kab. Manggarai Barat
Kab. Manggarai Timur
Kab. Manokwari
Kab. Manokwari Selatan
Kab. Mappi
Kab. Maros
Kab. Maybrat
Kab. Melawi
Kab. Mempawah
Kab. Merangin
Kab. Merauke
Kab. Mesuji
Kab. Mimika
Kab. Minahasa
Kab. Minahasa Selatan
Kab. Minahasa Tenggara
Kab. Minahasa Utara
Kab. Mojokerto
Kab. Morowali
Kab. Morowali Utara
Kab. Muara Enim
Kab. Muaro Jambi
Kab. Muko Muko
Kab. Muna
Kab. Muna Barat
Kab. Murung Raya
Kab. Musi Banyuasin
Kab. Musi Rawas
Kab. Musi Rawas Utara
Kab. Nabire
Kab. Nagan Raya
Kab. Nagekeo
Kab. Natuna
Kab. Nduga
Kab. Ngada
Kab. Nganjuk
Kab. Ngawi
Kab. Nias
Kab. Nias Barat
Kab. Nias Selatan
Kab. Nias Utara
Kab. Nunukan
Kab. Ogan Ilir
Kab. Ogan Komering Ilir
Kab. Ogan Komering Ulu
Kab. Ogan Komering Ulu Selatan
Kab. Ogan Komering Ulu Timur
Kab. Pacitan
Kab. Padang Lawas
Kab. Padang Lawas Utara
Kab. Padang Pariaman
Kab. Pakpak Bharat
Kab. Pamekasan
Kab. Pandeglang
Kab. Pangandaran
Kab. Pangkajene Kepulauan
Kab. Paniai
Kab. Parigi Moutong
Kab. Pasaman
Kab. Pasaman Barat
Kab. Paser
Kab. Pasuruan
Kab. Pati
Kab. Pegunungan Arfak
Kab. Pegunungan Bintang
Kab. Pekalongan
Kab. Pelalawan
Kab. Pemalang
Kab. Penajam Paser Utara
Kab. Penukal Abab Lematang Ilir
Kab. Pesawaran
Kab. Pesisir Barat
Kab. Pesisir Selatan
Kab. Pidie
Kab. Pidie Jaya
Kab. Pinrang
Kab. Pohuwato
Kab. Polewali Mandar
Kab. Ponorogo
Kab. Poso
Kab. Pringsewu
Kab. Probolinggo
Kab. Pulang Pisau
Kab. Pulau Morotai
Kab. Pulau Taliabu
Kab. Puncak
Kab. Puncak Jaya
Kab. Purbalingga
Kab. Purwakarta
Kab. Purworejo
Kab. Raja Ampat
Kab. Rejang Lebong
Kab. Rembang
Kab. Rokan Hilir
Kab. Rokan Hulu
Kab. Rote Ndao
Kab. Sabu Raijua
Kab. Sambas
Kab. Samosir
Kab. Sampang
Kab. Sanggau
Kab. Sarmi
Kab. Sarolangun
Kab. Sekadau
Kab. Seluma
Kab. Semarang
Kab. Seram Bagian Barat
Kab. Seram Bagian Timur
Kab. Serang
Kab. Serdang Bedagai
Kab. Seruyan
Kab. Siak
Kab. Sidenreng Rappang
Kab. Sidoarjo
Kab. Sigi
Kab. Sijunjung
Kab. Sikka
Kab. Simalungun
Kab. Simeulue
Kab. Sinjai
Kab. Sintang
Kab. Situbondo
Kab. Sleman
Kab. Solok
Kab. Solok Selatan
Kab. Soppeng
Kab. Sorong
Kab. Sorong Selatan
Kab. Sragen
Kab. Subang
Kab. Sukabumi
Kab. Sukamara
Kab. Sukoharjo
Kab. Sumba Barat
Kab. Sumba Barat Daya
Kab. Sumba Tengah
Kab. Sumba Timur
Kab. Sumbawa
Kab. Sumbawa Barat
Kab. Sumedang
Kab. Sumenep
Kab. Supiori
Kab. Tabalong
Kab. Tabanan
Kab. Takalar
Kab. Tambrauw
Kab. Tanah Bumbu
Kab. Tanah Datar
Kab. Tanah Laut
Kab. Tana Tidung
Kab. Tana Toraja
Kab. Tangerang
Kab. Tanggamus
Kab. Tanjung Jabung Barat
Kab. Tanjung Jabung Timur
Kab. Tapanuli Selatan
Kab. Tapanuli Tengah
Kab. Tapanuli Utara
Kab. Tapin
Kab. Tasikmalaya
Kab. Tebo
Kab. Tegal
Kab. Teluk Bintuni
Kab. Teluk Wondama
Kab. Temanggung
Kab. Timor Tengah Selatan
Kab. Timor Tengah Utara
Kab. Toba Samosir
Kab. Tojo Una-Una
Kab. Tolikara
Kab. Toli-Toli
Kab. Toraja Utara
Kab. Trenggalek
Kab. Tuban
Kab. Tulang Bawang
Kab. Tulang Bawang Barat
Kab. Tulungagung
Kab. Wajo
Kab. Wakatobi
Kab. Waropen
Kab. Way Kanan
Kab. Wonogiri
Kab. Wonosobo
Kab. Yahukimo
Kab. Yalimo
Kota Ambon
Kota Balikpapan
Kota Banda Aceh
Kota Bandar Lampung
Kota Bandung
Kota Banjar
Kota Banjarbaru
Kota Banjarmasin
Kota Batam
Kota Batu
Kota Bau-Bau
Kota Bekasi
Kota Bengkulu
Kota Bima
Kota Binjai
Kota Bitung
Kota Blitar
Kota Bogor
Kota Bontang
Kota Bukittinggi
Kota Cilegon
Kota Cimahi
Kota Cirebon
Kota Denpasar
Kota Depok
Kota Dumai
Kota Gorontalo
Kota Gunungsitoli
Kota Jakarta Barat
Kota Jakarta Pusat
Kota Jakarta Selatan
Kota Jakarta Timur
Kota Jakarta Utara
Kota Jambi
Kota Jayapura
Kota Kediri
Kota Kendari
Kota Kotamobagu
Kota Kupang
Kota Langsa
Kota Lhokseumawe
Kota Lubuk Linggau
Kota Madiun
Kota Magelang
Kota Makassar
Kota Malang
Kota Manado
Kota Mataram
Kota Medan
Kota Metro
Kota Mojokerto
Kota Padang
Kota Padang Panjang
Kota Padang Sidempuan
Kota Pagar Alam
Kota Palangka Raya
Kota Palembang
Kota Palopo
Kota Palu
Kota Pangkal Pinang
Kota Parepare
Kota Pariaman
Kota Pasuruan
Kota Payakumbuh
Kota Pekalongan
Kota Pekanbaru
Kota Pematang Siantar
Kota Pontianak
Kota Prabumulih
Kota Probolinggo
Kota Sabang
Kota Salatiga
Kota Samarinda
Kota Sawah Lunto
Kota Semarang
Kota Serang
Kota Sibolga
Kota Singkawang
Kota Solok
Kota Sorong
Kota Subulussalam
Kota Sukabumi
Kota Sungaipenuh
Kota Surabaya
Kota Surakarta
Kota Tangerang
Kota Tangerang Selatan
Kota Tanjung Balai
Kota Tanjung Pinang
Kota Tarakan
Kota Tasikmalaya
Kota Tebing Tinggi
Kota Tegal
Kota Ternate
Kota Tidore Kepulauan
Kota Tomohon
Kota Tual
Kota Yogyakarta
Lainnya
' or . = 'Kab. Aceh Barat
Kab. Aceh Barat Daya
Kab. Aceh Besar
Kab. Aceh Jaya
Kab. Aceh Selatan
Kab. Aceh Singkil
Kab. Aceh Tamiang
Kab. Aceh Tengah
Kab. Aceh Tenggara
Kab. Aceh Timur
Kab. Aceh Utara
Kab. Agam
Kab. Alor
Kab. Asahan
Kab. Asmat
Kab. Badung
Kab. Balangan
Kab. Bandung
Kab. Bandung Barat
Kab. Banggai
Kab. Banggai Kepulauan
Kab. Banggai Laut
Kab. Bangka
Kab. Bangka Barat
Kab. Bangkalan
Kab. Bangka Selatan
Kab. Bangka Tengah
Kab. Bangli
Kab. Banjar
Kab. Banjarnegara
Kab. Bantaeng
Kab. Bantul
Kab. Banyuasin
Kab. Banyumas
Kab. Banyuwangi
Kab. Barito Kuala
Kab. Barito Selatan
Kab. Barito Timur
Kab. Barito Utara
Kab. Barru
Kab. Batang
Kab. Batang Hari
Kab. Batu Bara
Kab. Bekasi
Kab. Belitung
Kab. Belitung Timur
Kab. Belu
Kab. Bener Meriah
Kab. Bengkalis
Kab. Bengkayang
Kab. Bengkulu Selatan
Kab. Bengkulu Tengah
Kab. Bengkulu Utara
Kab. Berau
Kab. Biak Numfor
Kab. Bima
Kab. Bintan
Kab. Bireuen
Kab. Blitar
Kab. Blora
Kab. Boalemo
Kab. Bogor
Kab. Bojonegoro
Kab. Bolaang Mongondow
Kab. Bolaang Mongondow Selatan
Kab. Bolaang Mongondow Timur
Kab. Bolaang Mongondow Utara
Kab. Bombana
Kab. Bondowoso
Kab. Bone
Kab. Bone Bolango
Kab. Boven Digoel
Kab. Boyolali
Kab. Brebes
Kab. Buleleng
Kab. Bulukumba
Kab. Bulungan
Kab. Bungo
Kab. Buol
Kab. Buru
Kab. Buru Selatan
Kab. Buton
Kab. Buton Selatan
Kab. Buton Tengah
Kab. Buton Utara
Kab. Ciamis
Kab. Cianjur
Kab. Cilacap
Kab. Cirebon
Kab. Dairi
Kab. Deiyai
Kab. Deli Serdang
Kab. Demak
Kab. Dharmasraya
Kab. Dogiyai
Kab. Dompu
Kab. Donggala
Kab. Empat Lawang
Kab. Ende
Kab. Enrekang
Kab. Fakfak
Kab. Flores Timur
Kab. Garut
Kab. Gayo Lues
Kab. Gianyar
Kab. Gorontalo
Kab. Gorontalo Utara
Kab. Gowa
Kab. Gresik
Kab. Grobogan
Kab. Gunung Kidul
Kab. Gunung Mas
Kab. Halmahera Barat
Kab. Halmahera Selatan
Kab. Halmahera Tengah
Kab. Halmahera Timur
Kab. Halmahera Utara
Kab. Hulu Sungai Selatan
Kab. Hulu Sungai Tengah
Kab. Hulu Sungai Utara
Kab. Humbang Hasundutan
Kab. Indragiri Hilir
Kab. Indragiri Hulu
Kab. Indramayu
Kab. Intan Jaya
Kab. Jayapura
Kab. Jayawijaya
Kab. Jember
Kab. Jembrana
Kab. Jeneponto
Kab. Jepara
Kab. Jombang
Kab. Kaimana
Kab. Kampar
Kab. Kapuas
Kab. Kapuas Hulu
Kab. Karanganyar
Kab. Karangasem
Kab. Karawang
Kab. Karimun
Kab. Karo
Kab. Katingan
Kab. Kaur
Kab. Kayong Utara
Kab. Kebumen
Kab. Kediri
Kab. Keerom
Kab. Kendal
Kab. Kepahiang
Kab. Kepulauan Anambas
Kab. Kepulauan Aru
Kab. Kepulauan Mentawai
Kab. Kepulauan Meranti
Kab. Kepulauan Sangihe
Kab. Kepulauan Selayar
Kab. Kepulauan Seribu
Kab. Kepulauan Siau Tagulandang Biaro (Sitaro)
Kab. Kepulauan Sula
Kab. Kepulauan Talaud
Kab. Kepulauan Yapen
Kab. Kerinci
Kab. Ketapang
Kab. Klaten
Kab. Klungkung
Kab. Kolaka
Kab. Kolaka Timur
Kab. Kolaka Utara
Kab. Konawe
Kab. Konawe Kepulauan
Kab. Konawe Selatan
Kab. Konawe Utara
Kab. Kotabaru
Kab. Kotawaringin Barat
Kab. Kotawaringin Timur
Kab. Kuantan Singingi
Kab. Kubu Raya
Kab. Kudus
Kab. Kulon Progo
Kab. Kuningan
Kab. Kupang
Kab. Kutai Barat
Kab. Kutai Kartanegara
Kab. Kutai Timur
Kab. Labuhanbatu
Kab. Labuhanbatu Selatan
Kab. Labuhanbatu Utara
Kab. Lahat
Kab. Lamandau
Kab. Lamongan
Kab. Lampung Barat
Kab. Lampung Selatan
Kab. Lampung Tengah
Kab. Lampung Timur
Kab. Lampung Utara
Kab. Landak
Kab. Langkat
Kab. Lanny Jaya
Kab. Lebak
Kab. Lebong
Kab. Lembata
Kab. Lima Puluh Kota
Kab. Lingga
Kab. Lombok Barat
Kab. Lombok Tengah
Kab. Lombok Timur
Kab. Lombok Utara
Kab. Lumajang
Kab. Luwu
Kab. Luwu Timur
Kab. Luwu Utara
Kab. Madiun
Kab. Magelang
Kab. Magetan
Kab. Mahakam Ulu
Kab. Majalengka
Kab. Majene
Kab. Malaka
Kab. Malang
Kab. Malinau
Kab. Maluku Barat Daya
Kab. Maluku Tengah
Kab. Maluku Tenggara
Kab. Maluku Tenggara Barat
Kab. Mamasa
Kab. Mamberamo Raya
Kab. Mamberamo Tengah
Kab. Mamuju
Kab. Mamuju Tengah
Kab. Mamuju Utara
Kab. Mandailing Natal
Kab. Manggarai
Kab. Manggarai Barat
Kab. Manggarai Timur
Kab. Manokwari
Kab. Manokwari Selatan
Kab. Mappi
Kab. Maros
Kab. Maybrat
Kab. Melawi
Kab. Mempawah
Kab. Merangin
Kab. Merauke
Kab. Mesuji
Kab. Mimika
Kab. Minahasa
Kab. Minahasa Selatan
Kab. Minahasa Tenggara
Kab. Minahasa Utara
Kab. Mojokerto
Kab. Morowali
Kab. Morowali Utara
Kab. Muara Enim
Kab. Muaro Jambi
Kab. Muko Muko
Kab. Muna
Kab. Muna Barat
Kab. Murung Raya
Kab. Musi Banyuasin
Kab. Musi Rawas
Kab. Musi Rawas Utara
Kab. Nabire
Kab. Nagan Raya
Kab. Nagekeo
Kab. Natuna
Kab. Nduga
Kab. Ngada
Kab. Nganjuk
Kab. Ngawi
Kab. Nias
Kab. Nias Barat
Kab. Nias Selatan
Kab. Nias Utara
Kab. Nunukan
Kab. Ogan Ilir
Kab. Ogan Komering Ilir
Kab. Ogan Komering Ulu
Kab. Ogan Komering Ulu Selatan
Kab. Ogan Komering Ulu Timur
Kab. Pacitan
Kab. Padang Lawas
Kab. Padang Lawas Utara
Kab. Padang Pariaman
Kab. Pakpak Bharat
Kab. Pamekasan
Kab. Pandeglang
Kab. Pangandaran
Kab. Pangkajene Kepulauan
Kab. Paniai
Kab. Parigi Moutong
Kab. Pasaman
Kab. Pasaman Barat
Kab. Paser
Kab. Pasuruan
Kab. Pati
Kab. Pegunungan Arfak
Kab. Pegunungan Bintang
Kab. Pekalongan
Kab. Pelalawan
Kab. Pemalang
Kab. Penajam Paser Utara
Kab. Penukal Abab Lematang Ilir
Kab. Pesawaran
Kab. Pesisir Barat
Kab. Pesisir Selatan
Kab. Pidie
Kab. Pidie Jaya
Kab. Pinrang
Kab. Pohuwato
Kab. Polewali Mandar
Kab. Ponorogo
Kab. Poso
Kab. Pringsewu
Kab. Probolinggo
Kab. Pulang Pisau
Kab. Pulau Morotai
Kab. Pulau Taliabu
Kab. Puncak
Kab. Puncak Jaya
Kab. Purbalingga
Kab. Purwakarta
Kab. Purworejo
Kab. Raja Ampat
Kab. Rejang Lebong
Kab. Rembang
Kab. Rokan Hilir
Kab. Rokan Hulu
Kab. Rote Ndao
Kab. Sabu Raijua
Kab. Sambas
Kab. Samosir
Kab. Sampang
Kab. Sanggau
Kab. Sarmi
Kab. Sarolangun
Kab. Sekadau
Kab. Seluma
Kab. Semarang
Kab. Seram Bagian Barat
Kab. Seram Bagian Timur
Kab. Serang
Kab. Serdang Bedagai
Kab. Seruyan
Kab. Siak
Kab. Sidenreng Rappang
Kab. Sidoarjo
Kab. Sigi
Kab. Sijunjung
Kab. Sikka
Kab. Simalungun
Kab. Simeulue
Kab. Sinjai
Kab. Sintang
Kab. Situbondo
Kab. Sleman
Kab. Solok
Kab. Solok Selatan
Kab. Soppeng
Kab. Sorong
Kab. Sorong Selatan
Kab. Sragen
Kab. Subang
Kab. Sukabumi
Kab. Sukamara
Kab. Sukoharjo
Kab. Sumba Barat
Kab. Sumba Barat Daya
Kab. Sumba Tengah
Kab. Sumba Timur
Kab. Sumbawa
Kab. Sumbawa Barat
Kab. Sumedang
Kab. Sumenep
Kab. Supiori
Kab. Tabalong
Kab. Tabanan
Kab. Takalar
Kab. Tambrauw
Kab. Tanah Bumbu
Kab. Tanah Datar
Kab. Tanah Laut
Kab. Tana Tidung
Kab. Tana Toraja
Kab. Tangerang
Kab. Tanggamus
Kab. Tanjung Jabung Barat
Kab. Tanjung Jabung Timur
Kab. Tapanuli Selatan
Kab. Tapanuli Tengah
Kab. Tapanuli Utara
Kab. Tapin
Kab. Tasikmalaya
Kab. Tebo
Kab. Tegal
Kab. Teluk Bintuni
Kab. Teluk Wondama
Kab. Temanggung
Kab. Timor Tengah Selatan
Kab. Timor Tengah Utara
Kab. Toba Samosir
Kab. Tojo Una-Una
Kab. Tolikara
Kab. Toli-Toli
Kab. Toraja Utara
Kab. Trenggalek
Kab. Tuban
Kab. Tulang Bawang
Kab. Tulang Bawang Barat
Kab. Tulungagung
Kab. Wajo
Kab. Wakatobi
Kab. Waropen
Kab. Way Kanan
Kab. Wonogiri
Kab. Wonosobo
Kab. Yahukimo
Kab. Yalimo
Kota Ambon
Kota Balikpapan
Kota Banda Aceh
Kota Bandar Lampung
Kota Bandung
Kota Banjar
Kota Banjarbaru
Kota Banjarmasin
Kota Batam
Kota Batu
Kota Bau-Bau
Kota Bekasi
Kota Bengkulu
Kota Bima
Kota Binjai
Kota Bitung
Kota Blitar
Kota Bogor
Kota Bontang
Kota Bukittinggi
Kota Cilegon
Kota Cimahi
Kota Cirebon
Kota Denpasar
Kota Depok
Kota Dumai
Kota Gorontalo
Kota Gunungsitoli
Kota Jakarta Barat
Kota Jakarta Pusat
Kota Jakarta Selatan
Kota Jakarta Timur
Kota Jakarta Utara
Kota Jambi
Kota Jayapura
Kota Kediri
Kota Kendari
Kota Kotamobagu
Kota Kupang
Kota Langsa
Kota Lhokseumawe
Kota Lubuk Linggau
Kota Madiun
Kota Magelang
Kota Makassar
Kota Malang
Kota Manado
Kota Mataram
Kota Medan
Kota Metro
Kota Mojokerto
Kota Padang
Kota Padang Panjang
Kota Padang Sidempuan
Kota Pagar Alam
Kota Palangka Raya
Kota Palembang
Kota Palopo
Kota Palu
Kota Pangkal Pinang
Kota Parepare
Kota Pariaman
Kota Pasuruan
Kota Payakumbuh
Kota Pekalongan
Kota Pekanbaru
Kota Pematang Siantar
Kota Pontianak
Kota Prabumulih
Kota Probolinggo
Kota Sabang
Kota Salatiga
Kota Samarinda
Kota Sawah Lunto
Kota Semarang
Kota Serang
Kota Sibolga
Kota Singkawang
Kota Solok
Kota Sorong
Kota Subulussalam
Kota Sukabumi
Kota Sungaipenuh
Kota Surabaya
Kota Surakarta
Kota Tangerang
Kota Tangerang Selatan
Kota Tanjung Balai
Kota Tanjung Pinang
Kota Tarakan
Kota Tasikmalaya
Kota Tebing Tinggi
Kota Tegal
Kota Ternate
Kota Tidore Kepulauan
Kota Tomohon
Kota Tual
Kota Yogyakarta
Lainnya
')]</value>
      <webElementGuid>e283424c-f37a-43b1-a69e-ffa3993fba45</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
