<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>ul_3 juta rupiah3 - 5 juta rupiah5 - 10 jut_38c9e3</name>
   <tag></tag>
   <elementGuidId>cc8cbc32-c7fc-4139-b489-e8b4d5232d5b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//fieldset[@id='dashboardForm-p-0']/div/div/div/div/div/div[4]/div[4]/div[2]/div/div/div/div/div/ul</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.dropdown-menu.show > div.inner.show > ul.dropdown-menu.inner.show</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>ul</value>
      <webElementGuid>f8a1e890-800b-4535-ad71-25799260ccd8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>dropdown-menu inner show</value>
      <webElementGuid>dc745199-c3d9-43a9-ac9b-c88a2f8aa86c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>&lt; 3 juta rupiah3 - 5 juta rupiah5 - 10 juta rupiah10 - 20 juta rupiah20 - 50 juta rupiah50 - 100 juta rupiah100 - 500 juta rupiah> 500 juta rupiah</value>
      <webElementGuid>f9267ae1-9b4a-44a8-b320-4fd64aec0647</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;dashboardForm-p-0&quot;)/div[@class=&quot;row no-gutters py-2 mt-3&quot;]/div[@class=&quot;col-lg-12&quot;]/div[@class=&quot;body body-verifikasi&quot;]/div[@class=&quot;row no-gutters bg-delta p-3 p-lg-4 text-alfa&quot;]/div[@class=&quot;col&quot;]/div[@class=&quot;form-row double-column&quot;]/div[@class=&quot;col-md-6&quot;]/div[2]/div[@class=&quot;form-group&quot;]/div[@class=&quot;form-line&quot;]/div[@class=&quot;dropdown bootstrap-select form-control ms dropup show&quot;]/div[@class=&quot;dropdown-menu show&quot;]/div[@class=&quot;inner show&quot;]/ul[@class=&quot;dropdown-menu inner show&quot;]</value>
      <webElementGuid>a7b05f54-f7e6-4386-8769-8716e043ce97</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//fieldset[@id='dashboardForm-p-0']/div/div/div/div/div/div[4]/div[4]/div[2]/div/div/div/div/div/ul</value>
      <webElementGuid>f36b1c3e-1ffc-446f-bee0-2b50ccb1a75c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Tidak ada yang dipilih'])[3]/following::ul[1]</value>
      <webElementGuid>9afc25a7-e0b7-4dc1-8275-616ffc09fa1a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Penghasilan Bulanan'])[1]/following::ul[1]</value>
      <webElementGuid>aa1d5460-03c9-4010-babc-95e9d986c7d4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[4]/div[2]/div/div/div/div/div/ul</value>
      <webElementGuid>888893fb-e057-4095-9837-cc493a621dc1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//ul[(text() = '&lt; 3 juta rupiah3 - 5 juta rupiah5 - 10 juta rupiah10 - 20 juta rupiah20 - 50 juta rupiah50 - 100 juta rupiah100 - 500 juta rupiah> 500 juta rupiah' or . = '&lt; 3 juta rupiah3 - 5 juta rupiah5 - 10 juta rupiah10 - 20 juta rupiah20 - 50 juta rupiah50 - 100 juta rupiah100 - 500 juta rupiah> 500 juta rupiah')]</value>
      <webElementGuid>f14b75ff-2b16-4e18-bf5b-c342bd98f36c</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
