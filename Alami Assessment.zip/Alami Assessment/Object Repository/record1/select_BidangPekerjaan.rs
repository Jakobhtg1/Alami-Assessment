<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>select_BidangPekerjaan</name>
   <tag></tag>
   <elementGuidId>2329171a-dcd8-495e-a7c7-84ca4142f1d7</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//select[@id='industryPekerjaan']</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#industryPekerjaan</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>select</value>
      <webElementGuid>a20ba8cb-8879-485d-9512-8cf164a9cc82</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>name</name>
      <type>Main</type>
      <value>user.industryPekerjaan.id</value>
      <webElementGuid>b8d9aaa1-a5f3-4f7e-bd57-ce4e447cb0dc</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>form-control ms</value>
      <webElementGuid>cd880d64-36d6-4d56-abb5-79f6178a5837</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>industryPekerjaan</value>
      <webElementGuid>042243bf-0580-4d7f-b1b5-5b8725157105</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-live-search</name>
      <type>Main</type>
      <value>true</value>
      <webElementGuid>0953ca6c-37a2-4671-aa8e-15d35cef9441</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-size</name>
      <type>Main</type>
      <value>5</value>
      <webElementGuid>72990f02-b36f-4e23-bb8f-d16a7248ccac</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>onchange</name>
      <type>Main</type>
      <value>industryPekerjaanChange(this)</value>
      <webElementGuid>062c734e-ffc3-4cdd-be1d-59e4314b7bf9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tabindex</name>
      <type>Main</type>
      <value>-98</value>
      <webElementGuid>84a71e5a-dfec-46cb-8297-acc4cf31aaa8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
							                                            Administrasi Pemerintahan, Pertahanan, dan Jaminan Sosial Wajib
Aktivitas Badan Internasional dan Badan Ekstra
Aktivitas Jasa lainnya
Aktivitas Kesehatan Manusia dan Aktivitas Sosial
Aktivitas Keuangan dan Asuransi
Aktivitas penyewaan dan sewa guna usaha tanpa hak opsi, ketenagakerjaan, agen perjalanan dan penunjang usaha lainnya
Aktivitas Profesional, Ilmiah dan Teknis
Aktivitas Yang Menghasilkan Barang dan Jasa Oleh Rumah Tangga Yang Digunakan Untuk Memenuhi Kebutuhan Sendiri
Industri Pengolahan
Informasi dan Komunikasi
Kesenian, Hiburan dan Rekreasi
Konstruksi
Pendidikan
Pengadaan Listrik Gas, Uap/Air Panas dan Udara Dingin 
Pengangkutan dan Pergudangan
Penyediaan Akomodasi dan Penyediaan Makan Minum
Perdagangan Besar dan Eceran; Reparasi dan Perawatan Mobil dan Sepeda Motor
Pertambangan dan Penggalian
Pertanian, Kehutanan dan Perikanan
Real Estate
Treatment Air, Treatment Air Limbah, Treatment dan Pemulihan Material Sampah, dan Aktivitas Remediasi
Lainnya
</value>
      <webElementGuid>290db90e-32f1-427e-85f6-60c09665fde5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;industryPekerjaan&quot;)</value>
      <webElementGuid>fc8e3e6a-b721-414e-9b8f-40e94df7d61e</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//select[@id='industryPekerjaan']</value>
      <webElementGuid>7be68791-e62c-4449-987c-149278071fe9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//fieldset[@id='dashboardForm-p-0']/div/div/div/div/div/div[4]/div[3]/div[2]/div/div/div/select</value>
      <webElementGuid>576dd5c1-4160-4940-bcb4-60f3d57fba16</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Bidang Pekerjaan'])[1]/following::select[1]</value>
      <webElementGuid>097d134a-927d-4662-9493-2638524248bd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Lain-lain'])[2]/following::select[1]</value>
      <webElementGuid>f04f8eed-e3c4-4151-92b7-4d91fef6d578</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Tidak ada yang dipilih'])[2]/preceding::select[1]</value>
      <webElementGuid>32a58855-2151-4e06-9b59-07a532ac5b27</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Administrasi Pemerintahan, Pertahanan, dan Jaminan Sosial Wajib'])[2]/preceding::select[1]</value>
      <webElementGuid>5a8607f6-1433-4442-b24a-7aa3dcf0bc67</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/div[2]/div/div/div/select</value>
      <webElementGuid>3265f714-e253-4335-ac5e-b9265ce8ec77</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//select[@name = 'user.industryPekerjaan.id' and @id = 'industryPekerjaan' and (text() = '
							                                            Administrasi Pemerintahan, Pertahanan, dan Jaminan Sosial Wajib
Aktivitas Badan Internasional dan Badan Ekstra
Aktivitas Jasa lainnya
Aktivitas Kesehatan Manusia dan Aktivitas Sosial
Aktivitas Keuangan dan Asuransi
Aktivitas penyewaan dan sewa guna usaha tanpa hak opsi, ketenagakerjaan, agen perjalanan dan penunjang usaha lainnya
Aktivitas Profesional, Ilmiah dan Teknis
Aktivitas Yang Menghasilkan Barang dan Jasa Oleh Rumah Tangga Yang Digunakan Untuk Memenuhi Kebutuhan Sendiri
Industri Pengolahan
Informasi dan Komunikasi
Kesenian, Hiburan dan Rekreasi
Konstruksi
Pendidikan
Pengadaan Listrik Gas, Uap/Air Panas dan Udara Dingin 
Pengangkutan dan Pergudangan
Penyediaan Akomodasi dan Penyediaan Makan Minum
Perdagangan Besar dan Eceran; Reparasi dan Perawatan Mobil dan Sepeda Motor
Pertambangan dan Penggalian
Pertanian, Kehutanan dan Perikanan
Real Estate
Treatment Air, Treatment Air Limbah, Treatment dan Pemulihan Material Sampah, dan Aktivitas Remediasi
Lainnya
' or . = '
							                                            Administrasi Pemerintahan, Pertahanan, dan Jaminan Sosial Wajib
Aktivitas Badan Internasional dan Badan Ekstra
Aktivitas Jasa lainnya
Aktivitas Kesehatan Manusia dan Aktivitas Sosial
Aktivitas Keuangan dan Asuransi
Aktivitas penyewaan dan sewa guna usaha tanpa hak opsi, ketenagakerjaan, agen perjalanan dan penunjang usaha lainnya
Aktivitas Profesional, Ilmiah dan Teknis
Aktivitas Yang Menghasilkan Barang dan Jasa Oleh Rumah Tangga Yang Digunakan Untuk Memenuhi Kebutuhan Sendiri
Industri Pengolahan
Informasi dan Komunikasi
Kesenian, Hiburan dan Rekreasi
Konstruksi
Pendidikan
Pengadaan Listrik Gas, Uap/Air Panas dan Udara Dingin 
Pengangkutan dan Pergudangan
Penyediaan Akomodasi dan Penyediaan Makan Minum
Perdagangan Besar dan Eceran; Reparasi dan Perawatan Mobil dan Sepeda Motor
Pertambangan dan Penggalian
Pertanian, Kehutanan dan Perikanan
Real Estate
Treatment Air, Treatment Air Limbah, Treatment dan Pemulihan Material Sampah, dan Aktivitas Remediasi
Lainnya
')]</value>
      <webElementGuid>84e61810-31cf-4740-a8b0-7d7554a04b51</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
