<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>LinkedIn</name>
   <tag></tag>
   <elementGuidId>159a6585-bc21-475f-b9e6-4c8bfe2a1704</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>LinkedIn</value>
      <webElementGuid>e12ea2c2-fa73-453e-b059-11db45a3ac75</webElementGuid>
   </webElementProperties>
   <locator>//*[(@text = 'LinkedIn' or . = 'LinkedIn')]</locator>
   <locatorStrategy>ATTRIBUTES</locatorStrategy>
</MobileElementEntity>
