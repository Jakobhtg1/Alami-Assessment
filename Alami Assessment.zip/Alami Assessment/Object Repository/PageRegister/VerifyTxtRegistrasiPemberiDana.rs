<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>VerifyTxtRegistrasiPemberiDana</name>
   <tag></tag>
   <elementGuidId>08ccf6d4-749e-43f6-b0f7-6dc2e338381b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>h3</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Syariah penuh. Impact nyata.'])[1]/preceding::h3[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h3</value>
      <webElementGuid>3a8ee34c-fcbf-46b2-be07-35054c15f6ef</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Registrasi Pemberi Dana</value>
      <webElementGuid>c9ca4a01-7772-4098-8a9f-3fd75806e5f4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/div[@class=&quot;page register funder position-relative&quot;]/header[1]/div[@class=&quot;container&quot;]/div[@class=&quot;row text-center&quot;]/div[@class=&quot;col-12&quot;]/h3[1]</value>
      <webElementGuid>4cc8f738-04e5-427e-8753-6219676ffdad</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Syariah penuh. Impact nyata.'])[1]/preceding::h3[1]</value>
      <webElementGuid>428a219c-483f-4e2f-9ea2-2db17958530d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Nama Lengkap'])[1]/preceding::h3[1]</value>
      <webElementGuid>85fbc21d-6df1-4f50-aaec-30cc8754d6cd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Registrasi Pemberi Dana']/parent::*</value>
      <webElementGuid>b1c6bd8b-1bdc-40d3-8024-cdbd07ed8bf8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//h3</value>
      <webElementGuid>1a6ca939-92fc-4ff5-962c-5139a39a62e0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h3[(text() = 'Registrasi Pemberi Dana' or . = 'Registrasi Pemberi Dana')]</value>
      <webElementGuid>60cb60fd-c164-49da-8315-9bcbe53da0fe</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
