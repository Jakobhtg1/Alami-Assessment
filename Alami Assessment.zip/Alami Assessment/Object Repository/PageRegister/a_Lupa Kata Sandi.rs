<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Lupa Kata Sandi</name>
   <tag></tag>
   <elementGuidId>ac1ffdc7-da35-40ca-ab86-b54916ef7241</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>a.text</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//a[contains(text(),'Lupa Kata Sandi')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>ed8cdf9b-596d-43b5-8d58-4d79bfa06c9c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/reset-password</value>
      <webElementGuid>a2b64a24-8390-4534-9671-d417a0f3cc55</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>text</value>
      <webElementGuid>7716ab8f-3f57-4798-89d5-f3b41cc1027f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Lupa Kata Sandi</value>
      <webElementGuid>8175aede-153d-4992-8ddd-246a00f38b3e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/div[@class=&quot;page login&quot;]/main[@class=&quot;full&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-lg-6 px-0&quot;]/div[@class=&quot;right-side&quot;]/form[1]/a[@class=&quot;text&quot;]</value>
      <webElementGuid>33f4b97c-eb0e-4782-a194-a5a469b3e096</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Lupa Kata Sandi')]</value>
      <webElementGuid>b0debddd-ca0b-46f7-b454-dbc58e6013ce</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Assalamualaikum'])[1]/following::a[1]</value>
      <webElementGuid>f603cf49-fe89-4f34-9eff-4fdfb6c9ccc4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='#HijrahFinansial. Membangun Keuangan Syariah di Indonesia'])[1]/following::a[1]</value>
      <webElementGuid>2194bde4-8cc0-425a-b01e-b6b411c20b25</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Masuk Ke Akun Saya'])[1]/preceding::a[1]</value>
      <webElementGuid>2de2c723-7d8f-4c6f-bfb0-3eb3e4f608f5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Daftar disini'])[1]/preceding::a[2]</value>
      <webElementGuid>b38e09e9-3a17-4ce4-ade5-2890a3a0a17a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Lupa Kata Sandi']/parent::*</value>
      <webElementGuid>a8a94893-a976-4f1d-903f-d90d308cb0f5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/reset-password')]</value>
      <webElementGuid>db058b29-619c-4f62-ac60-d50e82437dd8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//form/a</value>
      <webElementGuid>7e981845-ba8a-4d17-a90b-42e99bd24a69</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/reset-password' and (text() = 'Lupa Kata Sandi' or . = 'Lupa Kata Sandi')]</value>
      <webElementGuid>56f08950-2da7-4fea-a621-8429ab92ae54</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
