<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>VerifyTxtKomitmenKeanggotaan</name>
   <tag></tag>
   <elementGuidId>30308d5a-f0a9-4e51-8bf0-f1e1582dd22e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#modalKomitmenKeanggotaan > div.modal-dialog.modal-lg > div.modal-content > div.modal-header > h4</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='modalKomitmenKeanggotaan']/div/div/div/h4</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h4</value>
      <webElementGuid>562c0b13-a35b-46b4-9e56-d5b9e187c3c4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Komitmen Keanggotaan</value>
      <webElementGuid>95a88b04-5d22-4fd8-8886-a5c4f6ff9363</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;modalKomitmenKeanggotaan&quot;)/div[@class=&quot;modal-dialog modal-lg&quot;]/div[@class=&quot;modal-content&quot;]/div[@class=&quot;modal-header&quot;]/h4[1]</value>
      <webElementGuid>714f3b4e-efff-4bc2-a184-b9886fe67a7d</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='modalKomitmenKeanggotaan']/div/div/div/h4</value>
      <webElementGuid>858e2b43-d955-44b4-bce5-d45cb81f62c8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Saya Mengerti'])[1]/following::h4[1]</value>
      <webElementGuid>c0ce0086-1ffc-4a37-a5ee-f05bfb014bd1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Potensi Resiko'])[1]/following::h4[1]</value>
      <webElementGuid>8dcc6150-e4a6-4f64-8c7d-855cf165cbe8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Saya Mengerti'])[2]/preceding::h4[1]</value>
      <webElementGuid>ad4fad96-1020-4cb4-83d4-1012c3fbf997</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Rabu'])[1]/preceding::h4[1]</value>
      <webElementGuid>9ad3b44d-50db-4ad6-8257-afb930be798a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Komitmen Keanggotaan']/parent::*</value>
      <webElementGuid>921ac559-27ca-4bac-8bf0-e63599828d47</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[9]/div/div/div/h4</value>
      <webElementGuid>c07c8221-f51c-48b3-a3d8-5a00b544d203</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h4[(text() = 'Komitmen Keanggotaan' or . = 'Komitmen Keanggotaan')]</value>
      <webElementGuid>11f90c57-8f5c-4acd-958f-c61ec3b3a589</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
