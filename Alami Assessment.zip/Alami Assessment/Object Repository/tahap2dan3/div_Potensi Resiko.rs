<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Potensi Resiko</name>
   <tag></tag>
   <elementGuidId>5ee660a7-f1f9-4273-952c-51161a86be9d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.modal-dialog.modal-lg > div.modal-content > div.modal-header</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='modalPotensiResiko']/div/div/div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>aeb3d415-48dc-4884-85cc-32f96f90708b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>modal-header</value>
      <webElementGuid>150bccd3-4c8a-4f60-a04f-c934df8eda3e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                        Potensi Resiko
                        ×
                    </value>
      <webElementGuid>deadce79-c5b6-42de-a2ae-678d8b0294f3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;modalPotensiResiko&quot;)/div[@class=&quot;modal-dialog modal-lg&quot;]/div[@class=&quot;modal-content&quot;]/div[@class=&quot;modal-header&quot;]</value>
      <webElementGuid>da2974a6-1cc3-413f-a5c9-94f45a35fce6</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='modalPotensiResiko']/div/div/div</value>
      <webElementGuid>f0a2f3d2-daa5-49ca-9938-0537200ac805</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Kembali Ke Dashboard'])[1]/following::div[4]</value>
      <webElementGuid>a56af7b6-dc5d-4ef1-83c6-70953ae35546</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Data Anda akan segera Kami proses dan akan berubah setelah Kami verifikasi'])[1]/following::div[5]</value>
      <webElementGuid>9d331309-419d-446b-8984-5b08f92a28f7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Saya Mengerti'])[1]/preceding::div[3]</value>
      <webElementGuid>b6c04fd2-bc5e-41ff-9dff-05412b09f765</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[8]/div/div/div</value>
      <webElementGuid>06cc6828-3fd0-4d17-afd2-766f3d3e9698</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
                        Potensi Resiko
                        ×
                    ' or . = '
                        Potensi Resiko
                        ×
                    ')]</value>
      <webElementGuid>e6837a97-1deb-4890-a89b-90ee89638d88</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
