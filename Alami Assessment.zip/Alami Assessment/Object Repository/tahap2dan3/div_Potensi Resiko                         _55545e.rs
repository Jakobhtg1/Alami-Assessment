<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Potensi Resiko                         _55545e</name>
   <tag></tag>
   <elementGuidId>0ebb50b5-7d57-4b82-a5f4-843e28794b3a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#modalPotensiResiko</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='modalPotensiResiko']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>9e3614b1-35bd-43fc-9568-c2a1fd8219a2</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>modalPotensiResiko</value>
      <webElementGuid>c2880ffb-4849-4056-84c9-c3a4df35482e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>modal fade show</value>
      <webElementGuid>eb275de8-7d9e-4c51-960e-646c2169c55a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-backdrop</name>
      <type>Main</type>
      <value>static</value>
      <webElementGuid>0dcf2a1e-4b21-4467-bcb1-764ec6313471</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-keyboard</name>
      <type>Main</type>
      <value>false</value>
      <webElementGuid>6e261ca6-cc89-4ba6-8136-ed557123ba5c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tabindex</name>
      <type>Main</type>
      <value>-1</value>
      <webElementGuid>3af68781-cb24-423d-bd81-114eef5371f9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>role</name>
      <type>Main</type>
      <value>dialog</value>
      <webElementGuid>9cfd322d-dc5f-4cfe-b6c6-d1eb0e29f88d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
            
                
                    
                        Potensi Resiko
                        ×
                    
                    
                        
                        
                            
                            
                                
                                    Penggunaan Layanan Pembiayaan Berbasis Teknologi Informasi Berdasarkan Prinsip Syariah (“ALAMI” / “Fintech Lending”) merupakan wujud kesepakatan dan hubungan perdata antara Pemberi Pembiayaan dengan Penerima Pembiayaan, sehingga segala risiko dan akibat hukum daripadanya ditanggung sepenuhnya oleh masing-masing pihak yang berkontrak.
                                    Risiko Pembiayaan atau gagal bayar sepenuhnya tanggung jawab oleh Pemberi Pembiayaan. Tidak ada lembaga atau otoritas negara yang bertanggungjawab atas Risiko gagal bayar ini.
                                    Pemberi Pembiayaan yang belum memiliki pengetahuan dan pengalaman terhadap layanan Pembiayaan ini, disarankan agar tidak menggunakan layanan Pembiayaan ini.
                                    Sebelum memanfaatkan Fintech Lending, Penerima Pembiayaan wajib mempertimbangkan tingkat bagi hasil / marjin / ujroh serta biaya - biaya lainnya sesuai dengan kemampuan dalam melunasi pembiayaan.
                                    Setiap kecurangan tercatat secara digital di dunia maya dan dapat diketahui oleh masyarakat luas di media social serta dapat menjadi alat bukti hukum yang sah menurut peraturan mengenai informasi dan transaksi elektronik dalam proses penyelesaian sengketa dan penegakan hukum.
                                    Masyarakat Pengguna wajib membaca dan memahami informasi ini sebelum membuat keputusan sebagai Pemberi Pembiayaan maupun Penerima Pembiayaan. Keputusan Pengguna untuk memanfaatkan FinTech Lending merupakan suatu wujud dan bukti pemahaman Pengguna atas informasi ini.
                                
                            
                        
                        
                    
                    
                        Saya Mengerti
                    
                
            
        </value>
      <webElementGuid>6ab9fd92-abf1-4781-868c-db8caf849a53</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;modalPotensiResiko&quot;)</value>
      <webElementGuid>811fa33d-5cf5-47d7-b3d2-e71cdf528121</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//div[@id='modalPotensiResiko']</value>
      <webElementGuid>569247e0-857f-4965-a88f-8456bd90f675</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Kembali Ke Dashboard'])[1]/following::div[1]</value>
      <webElementGuid>9fc91e2e-beb2-4533-bf3d-9003da58f4e5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Data Anda akan segera Kami proses dan akan berubah setelah Kami verifikasi'])[1]/following::div[2]</value>
      <webElementGuid>1bd193d5-4a29-4cb2-a1bc-6f165fbb4e39</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[8]</value>
      <webElementGuid>fa9f3293-02ce-44ad-9bd8-a995b67ffcb9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[@id = 'modalPotensiResiko' and (text() = '
            
                
                    
                        Potensi Resiko
                        ×
                    
                    
                        
                        
                            
                            
                                
                                    Penggunaan Layanan Pembiayaan Berbasis Teknologi Informasi Berdasarkan Prinsip Syariah (“ALAMI” / “Fintech Lending”) merupakan wujud kesepakatan dan hubungan perdata antara Pemberi Pembiayaan dengan Penerima Pembiayaan, sehingga segala risiko dan akibat hukum daripadanya ditanggung sepenuhnya oleh masing-masing pihak yang berkontrak.
                                    Risiko Pembiayaan atau gagal bayar sepenuhnya tanggung jawab oleh Pemberi Pembiayaan. Tidak ada lembaga atau otoritas negara yang bertanggungjawab atas Risiko gagal bayar ini.
                                    Pemberi Pembiayaan yang belum memiliki pengetahuan dan pengalaman terhadap layanan Pembiayaan ini, disarankan agar tidak menggunakan layanan Pembiayaan ini.
                                    Sebelum memanfaatkan Fintech Lending, Penerima Pembiayaan wajib mempertimbangkan tingkat bagi hasil / marjin / ujroh serta biaya - biaya lainnya sesuai dengan kemampuan dalam melunasi pembiayaan.
                                    Setiap kecurangan tercatat secara digital di dunia maya dan dapat diketahui oleh masyarakat luas di media social serta dapat menjadi alat bukti hukum yang sah menurut peraturan mengenai informasi dan transaksi elektronik dalam proses penyelesaian sengketa dan penegakan hukum.
                                    Masyarakat Pengguna wajib membaca dan memahami informasi ini sebelum membuat keputusan sebagai Pemberi Pembiayaan maupun Penerima Pembiayaan. Keputusan Pengguna untuk memanfaatkan FinTech Lending merupakan suatu wujud dan bukti pemahaman Pengguna atas informasi ini.
                                
                            
                        
                        
                    
                    
                        Saya Mengerti
                    
                
            
        ' or . = '
            
                
                    
                        Potensi Resiko
                        ×
                    
                    
                        
                        
                            
                            
                                
                                    Penggunaan Layanan Pembiayaan Berbasis Teknologi Informasi Berdasarkan Prinsip Syariah (“ALAMI” / “Fintech Lending”) merupakan wujud kesepakatan dan hubungan perdata antara Pemberi Pembiayaan dengan Penerima Pembiayaan, sehingga segala risiko dan akibat hukum daripadanya ditanggung sepenuhnya oleh masing-masing pihak yang berkontrak.
                                    Risiko Pembiayaan atau gagal bayar sepenuhnya tanggung jawab oleh Pemberi Pembiayaan. Tidak ada lembaga atau otoritas negara yang bertanggungjawab atas Risiko gagal bayar ini.
                                    Pemberi Pembiayaan yang belum memiliki pengetahuan dan pengalaman terhadap layanan Pembiayaan ini, disarankan agar tidak menggunakan layanan Pembiayaan ini.
                                    Sebelum memanfaatkan Fintech Lending, Penerima Pembiayaan wajib mempertimbangkan tingkat bagi hasil / marjin / ujroh serta biaya - biaya lainnya sesuai dengan kemampuan dalam melunasi pembiayaan.
                                    Setiap kecurangan tercatat secara digital di dunia maya dan dapat diketahui oleh masyarakat luas di media social serta dapat menjadi alat bukti hukum yang sah menurut peraturan mengenai informasi dan transaksi elektronik dalam proses penyelesaian sengketa dan penegakan hukum.
                                    Masyarakat Pengguna wajib membaca dan memahami informasi ini sebelum membuat keputusan sebagai Pemberi Pembiayaan maupun Penerima Pembiayaan. Keputusan Pengguna untuk memanfaatkan FinTech Lending merupakan suatu wujud dan bukti pemahaman Pengguna atas informasi ini.
                                
                            
                        
                        
                    
                    
                        Saya Mengerti
                    
                
            
        ')]</value>
      <webElementGuid>510d5a97-bc4a-4cdf-941e-31277f058602</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
