<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Lanjutkan Tahap 3</name>
   <tag></tag>
   <elementGuidId>6f42a30e-5fe7-4475-bb3c-2e4fec9aeb33</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>span.label.step-custom-next</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//form[@id='dashboardForm']/div[3]/ul/li[2]/a/span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>55970c9a-1777-4b2e-8257-e126d0f44581</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>label step-custom-next</value>
      <webElementGuid>a079bf6e-17f3-4525-bc4e-6e46c47d5ec0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Lanjutkan Tahap 3</value>
      <webElementGuid>9f470efd-095d-4d91-a937-b0500a27dc02</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;dashboardForm&quot;)/div[@class=&quot;actions clearfix&quot;]/ul[1]/li[2]/a[1]/span[@class=&quot;label step-custom-next&quot;]</value>
      <webElementGuid>27bc24e2-375b-4c9d-9cfb-97b0e4a5f507</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//form[@id='dashboardForm']/div[3]/ul/li[2]/a/span</value>
      <webElementGuid>d0aa033f-9108-4cd1-93d0-e90792558fa5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Kembali ke tahap 1'])[1]/following::span[1]</value>
      <webElementGuid>96660e67-6268-493b-b37e-66e286e52306</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='komitmen keanggotaan'])[1]/following::span[2]</value>
      <webElementGuid>1eef0d0a-cfdb-491d-ba05-8d4dbc34b06a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Daftar'])[1]/preceding::span[1]</value>
      <webElementGuid>79b967d2-80df-4f48-80e3-6b7e7f89b6b1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Simpan Data Sementara'])[1]/preceding::span[2]</value>
      <webElementGuid>3de362eb-5973-47b0-8fdd-e1780965c6b8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Lanjutkan Tahap 3']/parent::*</value>
      <webElementGuid>612c2e8c-a363-4cf0-a120-7852ee2f56d5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/ul/li[2]/a/span</value>
      <webElementGuid>ec95102a-046a-4af6-8279-e614ca683943</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Lanjutkan Tahap 3' or . = 'Lanjutkan Tahap 3')]</value>
      <webElementGuid>62473428-67e5-4a60-94a6-78054ff90d33</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
