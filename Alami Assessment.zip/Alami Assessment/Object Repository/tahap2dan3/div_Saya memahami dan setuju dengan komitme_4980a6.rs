<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Saya memahami dan setuju dengan komitme_4980a6</name>
   <tag></tag>
   <elementGuidId>4177d209-7229-4359-bfe4-0e8f8e37dcff</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.form-line.error > div.custom-control.custom-checkbox</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//fieldset[@id='dashboardForm-p-2']/div/div/div/div/div/div[4]/div/div[2]/div/div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>4b957533-e052-4352-9b89-190e6e2f46c3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>custom-control custom-checkbox</value>
      <webElementGuid>1b576913-73f2-4ae6-9c87-3e743897e8f5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                                                                        
                                                                        
                                                                            Saya memahami dan setuju dengan komitmen keanggotaan sebagai pengguna layanan yang diberikan oleh PT. ALAMI FINTEK SHARIA.
                                                                        
                                                                    </value>
      <webElementGuid>e1a9ab2c-a98f-4f14-9f13-6b2207f87b86</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;dashboardForm-p-2&quot;)/div[@class=&quot;row no-gutters py-2 mt-3&quot;]/div[@class=&quot;col-lg-12&quot;]/div[@class=&quot;body&quot;]/div[@class=&quot;row no-gutters bg-delta p-3 p-lg-4 text-alfa&quot;]/div[@class=&quot;col&quot;]/div[@class=&quot;form-row double-column&quot;]/div[@class=&quot;col-md-12&quot;]/div[@class=&quot;form-group&quot;]/div[@class=&quot;form-line error&quot;]/div[@class=&quot;custom-control custom-checkbox&quot;]</value>
      <webElementGuid>5781febd-5c20-40f0-aab9-f317ee807d2d</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//fieldset[@id='dashboardForm-p-2']/div/div/div/div/div/div[4]/div/div[2]/div/div</value>
      <webElementGuid>466c0f6c-fb01-4995-9133-f813696d5109</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='potensi resiko'])[1]/following::div[3]</value>
      <webElementGuid>f2c70e60-81a3-4907-a77d-5cedfa517196</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Nomor Rekening'])[1]/following::div[11]</value>
      <webElementGuid>f073a220-7464-4b0f-8e73-28c6f5b2226b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Anda harus memahami dan setuju dengan komitmen keanggotaan'])[1]/preceding::div[1]</value>
      <webElementGuid>c09781a1-1a65-4c6b-9cb1-4e0c7ac77f6c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//fieldset[3]/div/div/div/div/div/div[4]/div/div[2]/div/div</value>
      <webElementGuid>f1de312a-d1a9-4b3e-a444-0209c2b13d7c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
                                                                        
                                                                        
                                                                            Saya memahami dan setuju dengan komitmen keanggotaan sebagai pengguna layanan yang diberikan oleh PT. ALAMI FINTEK SHARIA.
                                                                        
                                                                    ' or . = '
                                                                        
                                                                        
                                                                            Saya memahami dan setuju dengan komitmen keanggotaan sebagai pengguna layanan yang diberikan oleh PT. ALAMI FINTEK SHARIA.
                                                                        
                                                                    ')]</value>
      <webElementGuid>0ebaad86-28fe-4b65-bd4c-8c365ed6e278</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
