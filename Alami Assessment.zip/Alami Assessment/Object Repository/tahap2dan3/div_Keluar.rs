<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Keluar</name>
   <tag></tag>
   <elementGuidId>ea8f980c-d446-4b18-b440-f5a370d80a2e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='dashboard-menu']/ul/li[7]/a/div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>6c7bd218-5721-4596-b72c-4ad39275d7a6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>d-flex</value>
      <webElementGuid>a9e2648e-a524-4739-a1f1-1f3bde922ad1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                            
                                
                            
                            Keluar
                        </value>
      <webElementGuid>0d50a7bb-10d7-417d-ae39-763097be1986</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;dashboard-menu&quot;)/ul[@class=&quot;list-unstyled dashboard-menu-container m-0&quot;]/li[7]/a[@class=&quot;d-block&quot;]/div[@class=&quot;d-flex&quot;]</value>
      <webElementGuid>f0b2f544-9743-42ea-b742-bf9754330b0f</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='dashboard-menu']/ul/li[7]/a/div</value>
      <webElementGuid>3f9fb054-6ff7-4b08-a0a0-3a4207526ea4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Bantuan'])[1]/following::div[1]</value>
      <webElementGuid>a6ebe571-4988-4426-afae-2432e7e6e106</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Kontak Kami'])[1]/following::div[4]</value>
      <webElementGuid>a675b8db-4cce-4be5-89ba-ce02ded98af5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Eliana Orn'])[1]/preceding::div[7]</value>
      <webElementGuid>3b8ba13e-35ea-40ff-acb5-ad9f17e0b62b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[7]/a/div</value>
      <webElementGuid>a959c8f6-4dda-4502-8e87-9c8c741aa540</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
                            
                                
                            
                            Keluar
                        ' or . = '
                            
                                
                            
                            Keluar
                        ')]</value>
      <webElementGuid>7c72bbb8-f152-40d2-8f7b-809dc9940c40</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
