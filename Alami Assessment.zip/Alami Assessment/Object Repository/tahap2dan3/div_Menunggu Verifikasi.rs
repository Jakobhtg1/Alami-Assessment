<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Menunggu Verifikasi</name>
   <tag></tag>
   <elementGuidId>2e843402-215d-4300-b773-43e5d2d4dc01</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.detail-status</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Eliana Orn'])[1]/following::div[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>aada8cb1-8d7c-4b6f-b224-2858e517b431</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>detail-status</value>
      <webElementGuid>412f0a2a-bb20-4c9c-bcff-82be1422896b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-status-id</name>
      <type>Main</type>
      <value>10</value>
      <webElementGuid>829984d3-416b-4e5f-80a0-9bd8deb46dbf</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                                
                                
                                    
                                        Menunggu Verifikasi
                                    
                                    
                                
                            </value>
      <webElementGuid>585dab68-c541-4010-8e41-1fbaea910bf7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/div[@class=&quot;d-lg-flex flex-column&quot;]/div[@class=&quot;d-flex flex-column flex-lg-row flex-shrink-0 custom-hide elemen-profile-container&quot;]/div[@class=&quot;profile-container p-3 p-lg-4 dashboard-left&quot;]/div[@class=&quot;items-profile&quot;]/div[@class=&quot;detail-status&quot;]</value>
      <webElementGuid>b0b74f8e-f5e4-427f-a1fa-85f55c1d5190</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Eliana Orn'])[1]/following::div[2]</value>
      <webElementGuid>cf42f118-f730-4dfc-b95d-5e7278caedba</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Keluar'])[1]/following::div[11]</value>
      <webElementGuid>f3870173-500c-469d-ae83-08a96a70adc5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Ubah Profil'])[1]/preceding::div[1]</value>
      <webElementGuid>71002ac2-0885-4310-8574-2484e29b8522</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/div/div[2]/div</value>
      <webElementGuid>c8081534-dcb4-48b1-9fc5-997a254196b0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
                                
                                
                                    
                                        Menunggu Verifikasi
                                    
                                    
                                
                            ' or . = '
                                
                                
                                    
                                        Menunggu Verifikasi
                                    
                                    
                                
                            ')]</value>
      <webElementGuid>e137533e-0df6-4a4f-a816-cd2ee8560118</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
