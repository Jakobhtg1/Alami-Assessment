<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Data Anda akan segera Kami proses dan a_dfbda9</name>
   <tag></tag>
   <elementGuidId>598c655e-e053-4868-8c11-ba700bfdfece</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.notif</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='modalProfilSudahLengkap']/div/div/div/div/div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>9d460b12-17b3-4c5a-9c83-7840ed64d540</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>notif</value>
      <webElementGuid>6677e6e1-28fb-43f3-8b00-dbb4056f4f30</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                                
                                    
                                    
                                        Data Anda akan segera Kami proses dan akan berubah setelah Kami verifikasi
                                    
                                
                            </value>
      <webElementGuid>dc82bff0-e7a6-4c26-a7f2-1cf41a100f57</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;modalProfilSudahLengkap&quot;)/div[@class=&quot;modal-dialog modal-dialog-centered&quot;]/div[@class=&quot;modal-content&quot;]/div[@class=&quot;modal-body&quot;]/div[@class=&quot;text-center&quot;]/div[@class=&quot;notif&quot;]</value>
      <webElementGuid>763fe359-e576-4019-9ef8-303ebb3647d8</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='modalProfilSudahLengkap']/div/div/div/div/div</value>
      <webElementGuid>9d55e8fc-c8df-47e5-ba85-6a2479635266</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Perubahan Data Anda SudahKami Terima'])[1]/following::div[1]</value>
      <webElementGuid>8b862ac9-7f86-433f-9044-d394a0e2a24e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Ambil Foto'])[1]/following::div[6]</value>
      <webElementGuid>f5d77373-136e-4fad-b4a0-42ef5a075665</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Kembali Ke Dashboard'])[1]/preceding::div[1]</value>
      <webElementGuid>a43057d6-a51c-41ed-a625-047ecf226079</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Potensi Resiko'])[1]/preceding::div[2]</value>
      <webElementGuid>3f0bfd54-127a-4713-b3cd-438a2bbb3aef</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Data Anda akan segera Kami proses dan akan berubah setelah Kami verifikasi']/parent::*</value>
      <webElementGuid>ad14ed3c-6fd7-409e-b6d3-ffff055de93f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[7]/div/div/div/div/div</value>
      <webElementGuid>dc6229fb-34a1-4f6f-a4ce-f16dda782fa7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
                                
                                    
                                    
                                        Data Anda akan segera Kami proses dan akan berubah setelah Kami verifikasi
                                    
                                
                            ' or . = '
                                
                                    
                                    
                                        Data Anda akan segera Kami proses dan akan berubah setelah Kami verifikasi
                                    
                                
                            ')]</value>
      <webElementGuid>1480d970-444c-4eac-8e62-7d1bb61c5bc6</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
