<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h4_Perubahan Data Anda SudahKami Terima</name>
   <tag></tag>
   <elementGuidId>85d64bb6-1a3d-4baf-b9b1-ddd0c0c16eb7</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.text-center > h4</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='modalProfilSudahLengkap']/div/div/div/div/h4</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h4</value>
      <webElementGuid>55091a3b-a43c-4211-8299-49d9dd6ed46a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Perubahan Data Anda SudahKami Terima</value>
      <webElementGuid>417aa0ab-a773-43e6-bd32-9b2d9c455d87</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;modalProfilSudahLengkap&quot;)/div[@class=&quot;modal-dialog modal-dialog-centered&quot;]/div[@class=&quot;modal-content&quot;]/div[@class=&quot;modal-body&quot;]/div[@class=&quot;text-center&quot;]/h4[1]</value>
      <webElementGuid>972872d6-4d7e-4116-a43c-0548464b8fea</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='modalProfilSudahLengkap']/div/div/div/div/h4</value>
      <webElementGuid>a972d9e7-1da0-434c-8222-bdc7a0789ee4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Ambil Foto'])[1]/following::h4[1]</value>
      <webElementGuid>bd1d51a3-51a8-4d4c-863d-ffcaa416c042</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Selfie'])[2]/following::h4[1]</value>
      <webElementGuid>74e754f0-2b50-414a-b670-20555b863a23</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Data Anda akan segera Kami proses dan akan berubah setelah Kami verifikasi'])[1]/preceding::h4[1]</value>
      <webElementGuid>f6d4896d-d158-433a-b078-161ab8a90791</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Kembali Ke Dashboard'])[1]/preceding::h4[1]</value>
      <webElementGuid>c70fb317-cfcc-4ae8-9ffc-79097a8c6b34</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Perubahan Data Anda Sudah']/parent::*</value>
      <webElementGuid>26f13dab-41db-4e03-8aaa-252ca7c64d4e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[7]/div/div/div/div/h4</value>
      <webElementGuid>480dbf1d-8d01-4ef7-bc17-b4e5f4e8b2a9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h4[(text() = 'Perubahan Data Anda SudahKami Terima' or . = 'Perubahan Data Anda SudahKami Terima')]</value>
      <webElementGuid>6efbec39-95c0-459a-bb08-56bcac82abcb</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
