<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_BANK TABUNGAN PENSIUNAN NASIONAL (BTPN)</name>
   <tag></tag>
   <elementGuidId>2d9ccdf7-afa3-4140-ab98-bd3db40a2d03</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.dropdown-menu.show > div.inner.show > ul.dropdown-menu.inner.show > li.active > a.dropdown-item.active > span.text</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//fieldset[@id='dashboardForm-p-2']/div/div/div/div/div/div[2]/div/div[2]/div/div/div/div/div[2]/ul/li/a/span[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>43a48607-caa8-4fc5-af57-aaa039b7bd03</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>text</value>
      <webElementGuid>231dbb4d-3af1-4183-b94c-111e0b9d7063</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>BANK TABUNGAN PENSIUNAN NASIONAL (BTPN)</value>
      <webElementGuid>249b2515-e298-4440-8ebb-47f1db3685b9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;dashboardForm-p-2&quot;)/div[@class=&quot;row no-gutters py-2 mt-3&quot;]/div[@class=&quot;col-lg-12&quot;]/div[@class=&quot;body&quot;]/div[@class=&quot;row no-gutters bg-delta p-3 p-lg-4 text-alfa&quot;]/div[@class=&quot;col&quot;]/div[@class=&quot;form-row double-column&quot;]/div[@class=&quot;col-md-6&quot;]/div[2]/div[@class=&quot;form-group&quot;]/div[@class=&quot;form-line error&quot;]/div[@class=&quot;dropdown bootstrap-select show-tick form-control ms show&quot;]/div[@class=&quot;dropdown-menu show&quot;]/div[@class=&quot;inner show&quot;]/ul[@class=&quot;dropdown-menu inner show&quot;]/li[@class=&quot;active&quot;]/a[@class=&quot;dropdown-item active&quot;]/span[@class=&quot;text&quot;]</value>
      <webElementGuid>f6e8121f-42fb-4d0c-80f5-128a9f546721</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//fieldset[@id='dashboardForm-p-2']/div/div/div/div/div/div[2]/div/div[2]/div/div/div/div/div[2]/ul/li/a/span[2]</value>
      <webElementGuid>f4757a11-6879-4b3f-bcab-6827bb436c7b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Tidak ada yang dipilih'])[11]/following::span[2]</value>
      <webElementGuid>e87cb62c-ac00-49d8-9cdd-44359bf53a3e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Nama Bank'])[1]/following::span[2]</value>
      <webElementGuid>d06b440e-5a2b-4221-9bf0-58930d89407e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Nama Bank tidak boleh kosong'])[1]/preceding::span[1]</value>
      <webElementGuid>c4d652a0-c47d-4d84-b00d-b84e9920fdb7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Nama Pemilik Rekening'])[1]/preceding::span[1]</value>
      <webElementGuid>96a43ae8-7e5a-4272-b076-6b1467dfe97e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//fieldset[3]/div/div/div/div/div/div[2]/div/div[2]/div/div/div/div/div[2]/ul/li/a/span[2]</value>
      <webElementGuid>f2934f3e-460c-4b43-9d0f-cd28e2a714c3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'BANK TABUNGAN PENSIUNAN NASIONAL (BTPN)' or . = 'BANK TABUNGAN PENSIUNAN NASIONAL (BTPN)')]</value>
      <webElementGuid>3c9fd10d-006e-4f53-8da1-f6d3f61ceec1</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
