<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Tidak ada yang dipilih</name>
   <tag></tag>
   <elementGuidId>285adad3-4acb-4500-a4f4-8472833d823b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.dropdown.bootstrap-select.form-control.ms.select-all-cities.dropup > button.btn.dropdown-toggle.bs-placeholder.btn-light > div.filter-option > div.filter-option-inner > div.filter-option-inner-inner</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//fieldset[@id='dashboardForm-p-1']/div/div/div/div/div/div[2]/div/div[3]/div[2]/div/div/div/button/div/div/div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>844a6cd9-c22a-475b-9674-3d5428f2d2b3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>filter-option-inner-inner</value>
      <webElementGuid>b63399e0-d3ad-4822-a773-b0577a6522b2</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Tidak ada yang dipilih</value>
      <webElementGuid>95253995-4c59-4c6a-80f1-767cb099284f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;dashboardForm-p-1&quot;)/div[@class=&quot;row no-gutters py-2 mt-3&quot;]/div[@class=&quot;col-lg-12&quot;]/div[@class=&quot;body body-document&quot;]/div[@class=&quot;row no-gutters bg-delta p-3 p-lg-4 text-alfa&quot;]/div[@class=&quot;col&quot;]/div[@class=&quot;form-row double-column&quot;]/div[@class=&quot;col-md-6&quot;]/div[3]/div[2]/div[@class=&quot;form-group&quot;]/div[@class=&quot;form-line error&quot;]/div[@class=&quot;dropdown bootstrap-select form-control ms select-all-cities dropup&quot;]/button[@class=&quot;btn dropdown-toggle bs-placeholder btn-light&quot;]/div[@class=&quot;filter-option&quot;]/div[@class=&quot;filter-option-inner&quot;]/div[@class=&quot;filter-option-inner-inner&quot;]</value>
      <webElementGuid>315dbda5-cb10-4695-8529-7c779acbdcd9</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//fieldset[@id='dashboardForm-p-1']/div/div/div/div/div/div[2]/div/div[3]/div[2]/div/div/div/button/div/div/div</value>
      <webElementGuid>41abf94b-4bbd-44ea-b263-4b38792a2b61</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Kota Penerbit e-KTP'])[1]/following::div[7]</value>
      <webElementGuid>670a8116-62cb-42d9-81e1-9a0d2ebfdf3b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='e-KTP berlaku seumur hidup'])[1]/following::div[9]</value>
      <webElementGuid>716a610a-5102-4b90-916a-e46af9ff319c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Kab. Aceh Barat'])[4]/preceding::div[2]</value>
      <webElementGuid>7208e77f-d75c-4de6-89a2-d6e4903674c5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Kab. Aceh Barat Daya'])[4]/preceding::div[2]</value>
      <webElementGuid>6dd3d453-c82f-4b69-a561-c248d1d638d8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/div[3]/div[2]/div/div/div/button/div/div/div</value>
      <webElementGuid>bb7b1d57-0738-4d44-9097-4fdfcd6d7cc9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'Tidak ada yang dipilih' or . = 'Tidak ada yang dipilih')]</value>
      <webElementGuid>ed3186d2-970c-45d2-b8b2-d58c8efc992b</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
