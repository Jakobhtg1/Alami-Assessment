<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Komitmen Keanggotaan</name>
   <tag></tag>
   <elementGuidId>027b962b-2eeb-4011-b99a-a627fca73834</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='modalKomitmenKeanggotaan']/div/div/div</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#modalKomitmenKeanggotaan > div.modal-dialog.modal-lg > div.modal-content > div.modal-header</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>d037171c-7908-458a-83cf-433138d5ea3b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>modal-header</value>
      <webElementGuid>17f080f7-b9c4-4773-aaeb-ece68a94f0b8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                        Komitmen Keanggotaan
                        ×
                    </value>
      <webElementGuid>f348c4bd-a663-4b01-9710-4e220fa1e5da</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;modalKomitmenKeanggotaan&quot;)/div[@class=&quot;modal-dialog modal-lg&quot;]/div[@class=&quot;modal-content&quot;]/div[@class=&quot;modal-header&quot;]</value>
      <webElementGuid>634363f4-6ec3-45aa-abf8-2def3c8bfe96</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='modalKomitmenKeanggotaan']/div/div/div</value>
      <webElementGuid>d2665835-2e62-415d-a423-1497d66e19b7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Saya Mengerti'])[1]/following::div[4]</value>
      <webElementGuid>b0eb253f-b100-4116-ab46-d56c49039a98</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Potensi Resiko'])[1]/following::div[7]</value>
      <webElementGuid>f4099e4b-519f-4dac-be61-6d18176e98bd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Saya Mengerti'])[2]/preceding::div[3]</value>
      <webElementGuid>5a55056a-759b-4456-8bf5-16def923919e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[9]/div/div/div</value>
      <webElementGuid>253743b6-de2e-4197-b17e-8700260bdf86</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
                        Komitmen Keanggotaan
                        ×
                    ' or . = '
                        Komitmen Keanggotaan
                        ×
                    ')]</value>
      <webElementGuid>d3cac67b-a16a-43d5-8e99-f0ef89a1649c</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
