<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>VerifyTxtKomitmenKeanggotaan</name>
   <tag></tag>
   <elementGuidId>fccd3d74-b137-4e7c-9da1-369f0ee4cbd2</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='modalKomitmenKeanggotaan']/div/div/div/h4</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#modalKomitmenKeanggotaan > div.modal-dialog.modal-lg > div.modal-content > div.modal-header > h4</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h4</value>
      <webElementGuid>9a0cbda7-7474-479b-928c-5a1792634eff</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Komitmen Keanggotaan</value>
      <webElementGuid>ebc26974-1e5d-4e10-b49d-f1644481c15f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;modalKomitmenKeanggotaan&quot;)/div[@class=&quot;modal-dialog modal-lg&quot;]/div[@class=&quot;modal-content&quot;]/div[@class=&quot;modal-header&quot;]/h4[1]</value>
      <webElementGuid>733683f2-5ad5-40fc-ad34-78e40620f0e5</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='modalKomitmenKeanggotaan']/div/div/div/h4</value>
      <webElementGuid>52e2d0f0-a8f2-4c78-8870-747773231fc3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Saya Mengerti'])[1]/following::h4[1]</value>
      <webElementGuid>7f7d859c-caa0-432e-a04b-7128a4cef5aa</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Potensi Resiko'])[1]/following::h4[1]</value>
      <webElementGuid>26dbcfcc-4003-4bb2-a91d-a0ddcc54ab0b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Saya Mengerti'])[2]/preceding::h4[1]</value>
      <webElementGuid>a452c550-2289-43ce-a606-0973026d412e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Rabu'])[1]/preceding::h4[1]</value>
      <webElementGuid>1e696e46-b102-45d3-a34f-be167a8a12f8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Komitmen Keanggotaan']/parent::*</value>
      <webElementGuid>79e4f489-3f87-4fbf-8d3e-03ab9fd32eca</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[9]/div/div/div/h4</value>
      <webElementGuid>64b394ae-ca93-4832-ae66-29c46aac3b10</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h4[(text() = 'Komitmen Keanggotaan' or . = 'Komitmen Keanggotaan')]</value>
      <webElementGuid>a615982e-ca84-4997-95f4-7101be4ec708</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
