<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>dev_akhir</name>
   <tag></tag>
   <elementGuidId>466982e2-fe58-4bc1-bab1-1b7ea3db9e2b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='modalKomitmenKeanggotaan']/div/div/div[3]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#modalKomitmenKeanggotaan > div.modal-dialog.modal-lg > div.modal-content > div.modal-footer</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>11fb91c5-acab-4f88-9919-1f1e53ef7b3f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>modal-footer</value>
      <webElementGuid>1563cff9-13f7-469a-b501-16fe1fe819e7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                        Saya Mengerti
                    </value>
      <webElementGuid>b107669d-b9c6-449b-929f-7b690455366e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;modalKomitmenKeanggotaan&quot;)/div[@class=&quot;modal-dialog modal-lg&quot;]/div[@class=&quot;modal-content&quot;]/div[@class=&quot;modal-footer&quot;]</value>
      <webElementGuid>3d42ca97-7e4e-40a6-a5e6-3771e7dcfaf4</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='modalKomitmenKeanggotaan']/div/div/div[3]</value>
      <webElementGuid>e281bef9-a183-4a31-a5d5-76f3b9448408</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Komitmen Keanggotaan'])[1]/following::div[3]</value>
      <webElementGuid>8945092d-ac54-405d-ab61-20e3d408c53f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Saya Mengerti'])[1]/following::div[7]</value>
      <webElementGuid>a3bd2d5a-9b43-46e5-9b57-665b821edd9f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Lundi'])[1]/preceding::div[1]</value>
      <webElementGuid>2e6f4455-e84f-4490-a23f-33ca6ac86748</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[9]/div/div/div[3]</value>
      <webElementGuid>f6e287a1-4787-4fdc-a700-f40befa29dcb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
                        Saya Mengerti
                    ' or . = '
                        Saya Mengerti
                    ')]</value>
      <webElementGuid>05e23d9c-fc82-48af-b0e8-d970425361dd</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
