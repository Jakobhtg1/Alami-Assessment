<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>BtnAktifasiEmailDanLogin</name>
   <tag></tag>
   <elementGuidId>bda82b88-69a1-4984-b996-5afd8864cc9e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>a</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='mail']/div/table/tbody/tr/td/table/tbody/tr[2]/td/table/tbody/tr[2]/td/p[6]/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>44df1b0e-7273-4586-b22a-d9577607a306</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://u23291266.ct.sendgrid.net/ls/click?upn=gZdSL1niv8Dq-2F1Zk-2BnPKp4he5BAehP7RPkC9yLunVoFC-2BmgCIKjmbiWezcj7IWNxgFbCMxRMB64jP0Y7MevHp1wYNms3JSKu9WlzH51Zh-2FIfKv6NWEyHB2pD2YFTGTTuoQm6kEmhSf2M-2B3PQSF0-2BmZ2kAY0L4SPJrINYjEo87TnpC2-2Bawvdlp1s72lm-2BpAjnYrbkaFKF1-2F8fbQkqn0LJgxNXi918NOrhG07KhFqLRfI-3D_XPo_NXcgX3YMt39xYOMj-2Fq0Urp8NAAdDEdrXJ3WSER8CzdtFEcMci3X4crGhBT8I0phHWDIusUJ7sbJ5L7PARCLFBXYmmps7s7Sg-2FChb3oaCGEBLvSNoo1LmcOjofARxHTAW1H-2BcRwUNHfnql13-2B5ecGxlBnMKCtuMay6C5gqQ-2BekQ3HVqWnOe1rfCP0RGli8DVhfEZiWNULVKlHwqWwiLPHPm3F3S0vOo6nbqOtT83qNN1j4fzF-2BrCpwQ5CIezftxktGF4q9DntTX-2F3gxZ94yZ9j35FSwfp-2BZ0xTMX61Ej4O8j6lUFS3VveWVJ8jgW1-2BpGbIFNRj1bz8-2Bn0-2FDxnY4Kbqj7VdMRFV5uis-2FUGMpX1ODg-3D</value>
      <webElementGuid>8f32ffc2-022a-414e-b79d-053ba0f88a98</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                                                        Klik Untuk Aktivasi Email &amp; Log-in
                                                    </value>
      <webElementGuid>98943946-3885-4b76-90eb-37391ea94b90</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;mail&quot;)/div[1]/table[1]/tbody[1]/tr[1]/td[1]/table[1]/tbody[1]/tr[2]/td[1]/table[1]/tbody[1]/tr[2]/td[1]/p[6]/a[1]</value>
      <webElementGuid>8f2f1e4f-767b-43be-a345-ee642c44a192</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>ref_element</name>
      <type>Main</type>
      <value>Object Repository/PageYopMail/iframe_Undo_ifmail</value>
      <webElementGuid>e0376153-7ae6-4fb0-b0f3-5801bb6b766e</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='mail']/div/table/tbody/tr/td/table/tbody/tr[2]/td/table/tbody/tr[2]/td/p[6]/a</value>
      <webElementGuid>e8ba4ea7-161d-461e-8f52-bc81246f73d7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Klik Untuk Aktivasi Email &amp; Log-in')]</value>
      <webElementGuid>6d8fa78e-09c6-4976-8d66-cad0c1b72926</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='alami8703@yopmail.com'])[1]/following::a[1]</value>
      <webElementGuid>da13694f-e1f8-42fc-92c4-ecd8b64e02a1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Username/E-mail :'])[1]/following::a[1]</value>
      <webElementGuid>ec9aa75f-419e-492d-9705-0993ab49907a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='di sini'])[1]/preceding::a[1]</value>
      <webElementGuid>efa30110-eb93-49e7-be5d-b42c99a8482c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)=''])[2]/preceding::a[6]</value>
      <webElementGuid>ea5695c7-0fe8-4206-ad58-a9e8e21926ea</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Klik Untuk Aktivasi Email &amp; Log-in']/parent::*</value>
      <webElementGuid>d3d373ac-eae9-47de-b7da-3bde1c07109e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'https://u23291266.ct.sendgrid.net/ls/click?upn=gZdSL1niv8Dq-2F1Zk-2BnPKp4he5BAehP7RPkC9yLunVoFC-2BmgCIKjmbiWezcj7IWNxgFbCMxRMB64jP0Y7MevHp1wYNms3JSKu9WlzH51Zh-2FIfKv6NWEyHB2pD2YFTGTTuoQm6kEmhSf2M-2B3PQSF0-2BmZ2kAY0L4SPJrINYjEo87TnpC2-2Bawvdlp1s72lm-2BpAjnYrbkaFKF1-2F8fbQkqn0LJgxNXi918NOrhG07KhFqLRfI-3D_XPo_NXcgX3YMt39xYOMj-2Fq0Urp8NAAdDEdrXJ3WSER8CzdtFEcMci3X4crGhBT8I0phHWDIusUJ7sbJ5L7PARCLFBXYmmps7s7Sg-2FChb3oaCGEBLvSNoo1LmcOjofARxHTAW1H-2BcRwUNHfnql13-2B5ecGxlBnMKCtuMay6C5gqQ-2BekQ3HVqWnOe1rfCP0RGli8DVhfEZiWNULVKlHwqWwiLPHPm3F3S0vOo6nbqOtT83qNN1j4fzF-2BrCpwQ5CIezftxktGF4q9DntTX-2F3gxZ94yZ9j35FSwfp-2BZ0xTMX61Ej4O8j6lUFS3VveWVJ8jgW1-2BpGbIFNRj1bz8-2Bn0-2FDxnY4Kbqj7VdMRFV5uis-2FUGMpX1ODg-3D')]</value>
      <webElementGuid>6b13e0da-ed15-428c-8ba5-d2e6f2266b0b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//a</value>
      <webElementGuid>e30baffb-6610-4053-a742-af6df435efd9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'https://u23291266.ct.sendgrid.net/ls/click?upn=gZdSL1niv8Dq-2F1Zk-2BnPKp4he5BAehP7RPkC9yLunVoFC-2BmgCIKjmbiWezcj7IWNxgFbCMxRMB64jP0Y7MevHp1wYNms3JSKu9WlzH51Zh-2FIfKv6NWEyHB2pD2YFTGTTuoQm6kEmhSf2M-2B3PQSF0-2BmZ2kAY0L4SPJrINYjEo87TnpC2-2Bawvdlp1s72lm-2BpAjnYrbkaFKF1-2F8fbQkqn0LJgxNXi918NOrhG07KhFqLRfI-3D_XPo_NXcgX3YMt39xYOMj-2Fq0Urp8NAAdDEdrXJ3WSER8CzdtFEcMci3X4crGhBT8I0phHWDIusUJ7sbJ5L7PARCLFBXYmmps7s7Sg-2FChb3oaCGEBLvSNoo1LmcOjofARxHTAW1H-2BcRwUNHfnql13-2B5ecGxlBnMKCtuMay6C5gqQ-2BekQ3HVqWnOe1rfCP0RGli8DVhfEZiWNULVKlHwqWwiLPHPm3F3S0vOo6nbqOtT83qNN1j4fzF-2BrCpwQ5CIezftxktGF4q9DntTX-2F3gxZ94yZ9j35FSwfp-2BZ0xTMX61Ej4O8j6lUFS3VveWVJ8jgW1-2BpGbIFNRj1bz8-2Bn0-2FDxnY4Kbqj7VdMRFV5uis-2FUGMpX1ODg-3D' and (text() = '
                                                        Klik Untuk Aktivasi Email &amp; Log-in
                                                    ' or . = '
                                                        Klik Untuk Aktivasi Email &amp; Log-in
                                                    ')]</value>
      <webElementGuid>705d6b90-ae2c-4a94-bd52-1f6956cc972c</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
