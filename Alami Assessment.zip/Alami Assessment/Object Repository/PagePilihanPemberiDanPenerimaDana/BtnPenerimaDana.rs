<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>BtnPenerimaDana</name>
   <tag></tag>
   <elementGuidId>4335e64b-ce27-4d02-a8bb-2d65a90f08ff</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Pemberi Dana'])[1]/following::div[3]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>a127448d-36d6-4bda-a99c-57f42b09c107</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>heading-5-homepage</value>
      <webElementGuid>e02e54a7-cfe3-4664-848d-d8aea36c2331</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Penerima Dana </value>
      <webElementGuid>0e93c285-9360-4693-8fe3-3727f0e9905d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/div[@class=&quot;page register&quot;]/main[@class=&quot;register&quot;]/div[@class=&quot;container text-center&quot;]/div[@class=&quot;row my-3 px-lg-3 px-4 d-flex align-items-center justify-content-center&quot;]/div[@class=&quot;col-sm-5 col-6 px-0&quot;]/a[1]/div[@class=&quot;box&quot;]/div[@class=&quot;heading-5-homepage&quot;]</value>
      <webElementGuid>0c93f476-5ea0-4276-af5f-9b1795b8f541</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Pemberi Dana'])[1]/following::div[3]</value>
      <webElementGuid>e5056a2f-4fce-45e4-86f1-cc688cbfbe65</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Pilih jenis akun Kamu'])[1]/following::div[7]</value>
      <webElementGuid>40b7b3f2-0691-4fd0-9f6d-5e1c8cc61ca5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='masuk'])[1]/preceding::div[1]</value>
      <webElementGuid>8f8b39e1-ae13-4203-b8a3-2d3f32c27efc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Capture object:'])[1]/preceding::div[2]</value>
      <webElementGuid>f23a092a-cf81-4dd2-9cee-0a3cea28b6a8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Penerima Dana']/parent::*</value>
      <webElementGuid>e0696ec4-1f52-4faf-995f-11b7f89799f2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/a/div/div</value>
      <webElementGuid>ff1a8e8b-bc68-4da1-adb6-08ef2c575ba2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'Penerima Dana ' or . = 'Penerima Dana ')]</value>
      <webElementGuid>d6d8174e-42a6-42e0-9e95-84f75b838428</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
