<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>VerifyTxtCaraSyariahYangAman</name>
   <tag></tag>
   <elementGuidId>4e1f75e2-eaab-468f-8036-246a74ee046a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>h3</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Pilih jenis akun Kamu'])[1]/preceding::h3[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h3</value>
      <webElementGuid>94828938-f1c8-4c5a-9afc-d9333a1b2dac</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Cara Syariah yang Aman. Memberi Pendanaan dan Mendapatkan Pembiayaan.</value>
      <webElementGuid>64af941d-c738-45c1-a89c-cd0f8154ba98</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/div[@class=&quot;page register&quot;]/header[1]/div[@class=&quot;container&quot;]/div[@class=&quot;row text-center&quot;]/div[@class=&quot;col-10 mx-auto&quot;]/h3[1]</value>
      <webElementGuid>220b84a0-6a7d-49fd-b941-e91ff419c1b7</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Pilih jenis akun Kamu'])[1]/preceding::h3[1]</value>
      <webElementGuid>48506877-73a3-4f45-8b97-b7b590a979dd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Pemberi Dana'])[1]/preceding::h3[1]</value>
      <webElementGuid>b6b839af-df56-4617-b388-46d0e3b1f4cb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Cara Syariah yang Aman.']/parent::*</value>
      <webElementGuid>6e14dd29-8ac8-4c29-8687-759e88d88d35</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//h3</value>
      <webElementGuid>c1a20cff-b762-4bdf-b849-587768f1f5cb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h3[(text() = 'Cara Syariah yang Aman. Memberi Pendanaan dan Mendapatkan Pembiayaan.' or . = 'Cara Syariah yang Aman. Memberi Pendanaan dan Mendapatkan Pembiayaan.')]</value>
      <webElementGuid>4e9fb20c-1741-465f-8d59-ff9c382d2bf6</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
