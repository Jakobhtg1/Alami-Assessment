<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>UserInfo</name>
   <tag></tag>
   <elementGuidId>2d1a41cf-2291-4fb6-be76-2338638214f7</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Keluar'])[1]/following::strong[1]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>strong</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>strong</value>
      <webElementGuid>c3ddc5e5-e0ec-4567-b13e-ead0a23fcb48</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Fallon Raynor</value>
      <webElementGuid>6f72cca4-7a12-4a5b-9a6e-bc8a33f58166</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/div[@class=&quot;d-lg-flex flex-column&quot;]/div[@class=&quot;d-flex flex-column flex-lg-row flex-shrink-0 custom-hide elemen-profile-container&quot;]/div[@class=&quot;profile-container p-3 p-lg-4 dashboard-left&quot;]/div[@class=&quot;d-flex&quot;]/div[@class=&quot;flex-grow-1 pl-2&quot;]/span[@class=&quot;d-block text-alfa pt-1&quot;]/strong[1]</value>
      <webElementGuid>10d51f20-3d57-4120-9664-0aa4452dd6e3</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Keluar'])[1]/following::strong[1]</value>
      <webElementGuid>ad89b2fe-08cb-40f2-9587-201ee94332e6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Bantuan'])[1]/following::strong[1]</value>
      <webElementGuid>4b469ac4-1690-4eae-a89f-34c8a1ff85d2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Belum terverifikasi'])[1]/preceding::strong[1]</value>
      <webElementGuid>bfd03b99-a2fa-42aa-81c6-a6540dc9f2d1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Total Pendanaan (IDR)'])[1]/preceding::strong[1]</value>
      <webElementGuid>a2e8ecda-d3ad-47cb-9138-23337eb8669f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Fallon Raynor']/parent::*</value>
      <webElementGuid>af0b34de-bf51-444b-97df-a18708d47062</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//strong</value>
      <webElementGuid>66f554f7-066e-4fd4-b516-2f4b0e8a169b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//strong[(text() = 'Fallon Raynor' or . = 'Fallon Raynor')]</value>
      <webElementGuid>798f6b4f-0c97-48f1-b4ff-fe09d82fe269</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
