<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>select_TipeAkun</name>
   <tag></tag>
   <elementGuidId>37ecaf8f-fccc-4a5c-8b97-c460af34fd9e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//select[@id='tipeAkun']</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#tipeAkun</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>select</value>
      <webElementGuid>db4004ad-ee82-4111-b1f8-af48e8cfb636</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>name</name>
      <type>Main</type>
      <value>tipeAkun</value>
      <webElementGuid>55ee3da7-2b5f-4829-8e13-3113916fdff7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>form-control ms is-invalid</value>
      <webElementGuid>787425b8-7d55-4c94-b59d-369048825816</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>tipeAkun</value>
      <webElementGuid>e957443d-8a03-4145-8997-07e1ea3cd521</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>onchange</name>
      <type>Main</type>
      <value>tipeAkunChange(this)</value>
      <webElementGuid>1384cc93-42d0-4efe-9ec3-b746f6c8bdcb</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tabindex</name>
      <type>Main</type>
      <value>-98</value>
      <webElementGuid>7a675a0c-4988-4348-bc87-d0d73437f4b4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-required</name>
      <type>Main</type>
      <value>true</value>
      <webElementGuid>f2fa9b08-4069-4496-8105-5ef8de7e0c6e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                                                                            
                                                                                Individual - WNI (Mewakili Diri Sendiri)
                                                                            
                                                                                Individual - WNA (Mewakili Diri Sendiri)
                                                                            
                                                                                Badan Hukum - WNI (Mewakili Suatu Badan Hukum)
                                                                            
                                                                        </value>
      <webElementGuid>776fe303-ecf1-4368-a02b-ab71862f6248</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;tipeAkun&quot;)</value>
      <webElementGuid>a0d81a6b-7960-4166-9f30-264d88a258b0</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//select[@id='tipeAkun']</value>
      <webElementGuid>2ec4f49e-7970-46d4-87a2-95ff19b4afca</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//fieldset[@id='dashboardForm-p-0']/div/div/div/div/div/div/div[2]/div[2]/div/div/div/select</value>
      <webElementGuid>33eddd8a-9452-46eb-a1d6-e34664e31600</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Tipe Akun'])[1]/following::select[1]</value>
      <webElementGuid>d0ff01d0-4f29-4751-9f2f-52c8242565a9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Tipe Akun Pemberi Dana'])[1]/following::select[1]</value>
      <webElementGuid>d25753f2-c782-4b2f-994f-d3cffa24325a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Tidak ada yang dipilih'])[1]/preceding::select[1]</value>
      <webElementGuid>3b7f9e9b-4b76-409d-9504-2f5dfb74c3af</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Individual - WNI (Mewakili Diri Sendiri)'])[2]/preceding::select[1]</value>
      <webElementGuid>b0c11987-42c6-4074-a2ba-b6c625c6ece7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//select</value>
      <webElementGuid>e76f7fba-d1a1-4714-ba28-af8b9168dd4b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//select[@name = 'tipeAkun' and @id = 'tipeAkun' and (text() = '
                                                                            
                                                                                Individual - WNI (Mewakili Diri Sendiri)
                                                                            
                                                                                Individual - WNA (Mewakili Diri Sendiri)
                                                                            
                                                                                Badan Hukum - WNI (Mewakili Suatu Badan Hukum)
                                                                            
                                                                        ' or . = '
                                                                            
                                                                                Individual - WNI (Mewakili Diri Sendiri)
                                                                            
                                                                                Individual - WNA (Mewakili Diri Sendiri)
                                                                            
                                                                                Badan Hukum - WNI (Mewakili Suatu Badan Hukum)
                                                                            
                                                                        ')]</value>
      <webElementGuid>77e7ec07-94ad-455b-813b-9bfe594915fa</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
