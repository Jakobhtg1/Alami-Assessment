<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>select_Pekerjaan</name>
   <tag></tag>
   <elementGuidId>b4ebc368-3f6d-4b4b-bdd3-43f88dafa089</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//select[@id='pekerjaan']</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#pekerjaan</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>select</value>
      <webElementGuid>96feac62-c2c6-4bc6-86df-26705851e20e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>name</name>
      <type>Main</type>
      <value>user.rdlJob.id</value>
      <webElementGuid>98bb057e-9878-42ba-96b3-256ce2ced487</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>form-control ms</value>
      <webElementGuid>b86d410a-6d2e-49c4-aed0-e46daee54821</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>pekerjaan</value>
      <webElementGuid>6a56eac6-65e2-4a5b-b276-a8867598ca9c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>onchange</name>
      <type>Main</type>
      <value>rdlJobChange(this)</value>
      <webElementGuid>e3557477-ea0b-4bb9-a876-586e6395ba3a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-required</name>
      <type>Main</type>
      <value>true</value>
      <webElementGuid>e17fe347-5dfb-49ba-a941-6d3adc75e0b3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tabindex</name>
      <type>Main</type>
      <value>-98</value>
      <webElementGuid>17ac1ed2-7d7e-4e7c-b9ff-5f30d3c933b7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
							                                            Pegawai Negeri
Pegawai Swasta
Pegawai BUMN/BUMD
TNI/POLRI
Pedagang
Petani/Nelayan
Pelajar/Mahasiswa
Ibu Rumah Tangga
Tidak Bekerja
Wiraswasta
Pejabat Negara
Akuntan
Pengacara/Notaris
Profesi
Pensiunan
Dosen/Guru Swasta
Dosen/Guru Negeri
Dokter
Pegawai BNI
Unit Afiliasi BNI
Lain-lain
</value>
      <webElementGuid>a12a3817-2663-4594-a8d5-0ba7d5650a62</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;pekerjaan&quot;)</value>
      <webElementGuid>f23cd2a4-352d-4af5-9797-ed5cd2e9bf69</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//select[@id='pekerjaan']</value>
      <webElementGuid>7281ff38-5009-467c-94f9-24cabe6eb434</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//fieldset[@id='dashboardForm-p-0']/div/div/div/div/div/div[4]/div[2]/div[2]/div/div/div/select</value>
      <webElementGuid>bd70c8dc-53c4-44d0-a574-4f74c20793ef</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Pekerjaan'])[1]/following::select[1]</value>
      <webElementGuid>9e86c7cd-0afd-40ea-9a0c-1f0e06e5a46d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Informasi Pekerjaan'])[1]/following::select[1]</value>
      <webElementGuid>5c10f98a-4266-461b-b25b-956d454d7468</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Tidak ada yang dipilih'])[2]/preceding::select[1]</value>
      <webElementGuid>52cc11f2-8d8f-41a0-a9be-97cee221e703</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Pegawai Negeri'])[2]/preceding::select[1]</value>
      <webElementGuid>7a77a06f-d3a3-4467-9a3c-4027b7336e33</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[4]/div[2]/div[2]/div/div/div/select</value>
      <webElementGuid>7a7b7b5e-9f1f-49a3-9b7a-911b48576a17</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//select[@name = 'user.rdlJob.id' and @id = 'pekerjaan' and (text() = '
							                                            Pegawai Negeri
Pegawai Swasta
Pegawai BUMN/BUMD
TNI/POLRI
Pedagang
Petani/Nelayan
Pelajar/Mahasiswa
Ibu Rumah Tangga
Tidak Bekerja
Wiraswasta
Pejabat Negara
Akuntan
Pengacara/Notaris
Profesi
Pensiunan
Dosen/Guru Swasta
Dosen/Guru Negeri
Dokter
Pegawai BNI
Unit Afiliasi BNI
Lain-lain
' or . = '
							                                            Pegawai Negeri
Pegawai Swasta
Pegawai BUMN/BUMD
TNI/POLRI
Pedagang
Petani/Nelayan
Pelajar/Mahasiswa
Ibu Rumah Tangga
Tidak Bekerja
Wiraswasta
Pejabat Negara
Akuntan
Pengacara/Notaris
Profesi
Pensiunan
Dosen/Guru Swasta
Dosen/Guru Negeri
Dokter
Pegawai BNI
Unit Afiliasi BNI
Lain-lain
')]</value>
      <webElementGuid>3a5dfea0-893a-4d28-97a0-eace194fbc8d</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
