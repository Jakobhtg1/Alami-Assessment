<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>ListTipeAkun</name>
   <tag></tag>
   <elementGuidId>9a5fadc6-bcfd-47f7-9b0a-32a9ce95b155</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[(text() = '
                                                                Tipe Akun
                                                            ' or . = '
                                                                Tipe Akun
                                                            ')]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.col-form-label</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>1c247c2d-b1d3-47ab-a4d9-b7c3d05d4102</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>col-form-label</value>
      <webElementGuid>e7c38635-474d-45a6-a153-72089ddcea07</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                                                                Tipe Akun
                                                            </value>
      <webElementGuid>51014b6f-b9b1-4028-958b-9be1f84f70c6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;dashboardForm-p-0&quot;)/div[@class=&quot;row no-gutters py-2 mt-3&quot;]/div[@class=&quot;col-lg-12&quot;]/div[@class=&quot;body body-verifikasi&quot;]/div[@class=&quot;row no-gutters bg-delta p-3 p-lg-4 text-alfa&quot;]/div[@class=&quot;col&quot;]/div[@class=&quot;form-row double-column&quot;]/div[@class=&quot;col-md-6&quot;]/div[@class=&quot;col-form-label&quot;]</value>
      <webElementGuid>9c57f1f3-cf5f-41bb-b756-bc71a32f7d8e</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//fieldset[@id='dashboardForm-p-0']/div/div/div/div/div/div/div[2]/div</value>
      <webElementGuid>b526d066-6cde-4390-8bc4-8505933f914a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Tipe Akun Pemberi Dana'])[1]/following::div[2]</value>
      <webElementGuid>e4366c4c-b2cf-48c0-8ada-f8100472ccc9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Profil Pemberi Dana (5 Menit)'])[2]/following::div[9]</value>
      <webElementGuid>3bc5b3d8-927c-4715-8463-87895cc740ef</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Tidak ada yang dipilih'])[1]/preceding::div[1]</value>
      <webElementGuid>6c0a92de-d2d0-404f-8b80-68067e1bda6e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/div/div/div/div/div/div[2]/div</value>
      <webElementGuid>f9a6717f-d591-4b37-b254-587d9144f60d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value></value>
      <webElementGuid>e8d29c28-11d0-4a25-87e6-e108dee7eb0b</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
