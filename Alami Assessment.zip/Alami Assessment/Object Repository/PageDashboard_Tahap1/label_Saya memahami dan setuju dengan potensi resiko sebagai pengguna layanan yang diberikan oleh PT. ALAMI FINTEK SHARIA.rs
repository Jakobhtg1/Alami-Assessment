<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>label_Saya memahami dan setuju dengan potensi resiko sebagai pengguna layanan yang diberikan oleh PT. ALAMI FINTEK SHARIA</name>
   <tag></tag>
   <elementGuidId>dcfb16d4-891d-41cb-9b32-858ad97e1031</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.form-line > div.custom-control.custom-checkbox > label.custom-control-label</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//label[@onclick='potensiResikoClick(this)']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>label</value>
      <webElementGuid>a2e97f4b-5499-4c35-b90a-d84f66a7c1b3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>custom-control-label</value>
      <webElementGuid>ae94faaf-20fa-4d67-bf7d-640a02fc8f8e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>for</name>
      <type>Main</type>
      <value>disable-buildin-click</value>
      <webElementGuid>6ba6b37f-ce5a-4a7e-9775-2f5abd31a3f9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>onclick</name>
      <type>Main</type>
      <value>potensiResikoClick(this)</value>
      <webElementGuid>e23186dd-8bbf-4ed3-9e63-a74a98a0a241</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                                                                            Saya memahami dan setuju dengan potensi resiko sebagai pengguna layanan yang diberikan oleh PT. ALAMI FINTEK SHARIA
                                                                        </value>
      <webElementGuid>dfa27560-3a78-49eb-9afa-701e8620688b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;dashboardForm-p-2&quot;)/div[@class=&quot;row no-gutters py-2 mt-3&quot;]/div[@class=&quot;col-lg-12&quot;]/div[@class=&quot;body&quot;]/div[@class=&quot;row no-gutters bg-delta p-3 p-lg-4 text-alfa&quot;]/div[@class=&quot;col&quot;]/div[@class=&quot;form-row double-column&quot;]/div[@class=&quot;col-md-12&quot;]/div[@class=&quot;form-group&quot;]/div[@class=&quot;form-line&quot;]/div[@class=&quot;custom-control custom-checkbox&quot;]/label[@class=&quot;custom-control-label&quot;]</value>
      <webElementGuid>d1bb3647-2c50-40c4-aff7-161ac91de395</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//label[@onclick='potensiResikoClick(this)']</value>
      <webElementGuid>32511d53-e3b2-46a3-b495-91ef77c3c5e1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//fieldset[@id='dashboardForm-p-2']/div/div/div/div/div/div[4]/div/div/div/div/label</value>
      <webElementGuid>053c8a5a-4dd3-4eb3-942c-ea79a71a44ed</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Nomor Rekening'])[1]/following::label[1]</value>
      <webElementGuid>407bd165-60ec-44cb-9fed-203737fa5e41</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='harus sesuai'])[1]/following::label[2]</value>
      <webElementGuid>4c5241fb-9de6-4ac2-8033-3e744bf6425c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='komitmen keanggotaan'])[1]/preceding::label[1]</value>
      <webElementGuid>7340b020-b888-4119-abea-301879f40bd5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Saya memahami dan setuju dengan']/parent::*</value>
      <webElementGuid>c36e5224-fd8b-41b6-b5be-30d3a04923f4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//fieldset[3]/div/div/div/div/div/div[4]/div/div/div/div/label</value>
      <webElementGuid>c3bcd1a8-d0b1-450b-8c13-e86152b9ddb1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//label[(text() = '
                                                                            Saya memahami dan setuju dengan potensi resiko sebagai pengguna layanan yang diberikan oleh PT. ALAMI FINTEK SHARIA
                                                                        ' or . = '
                                                                            Saya memahami dan setuju dengan potensi resiko sebagai pengguna layanan yang diberikan oleh PT. ALAMI FINTEK SHARIA
                                                                        ')]</value>
      <webElementGuid>cd5bdaef-4574-4031-91ea-bbc7dcb94186</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
