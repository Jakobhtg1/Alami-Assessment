<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>select_Kab_Kota</name>
   <tag></tag>
   <elementGuidId>03a56d0d-0abc-460b-97fe-8ee9be4d6a28</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//select[@id='city']</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#city</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>select</value>
      <webElementGuid>83e0f395-e97a-4dd3-9535-a788bfa319d9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>name</name>
      <type>Main</type>
      <value>user.location.parent.parent.id</value>
      <webElementGuid>7202023b-1ca5-4909-aa93-ef9cb24053c6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>form-control ms</value>
      <webElementGuid>311b7e08-98ae-4c34-95d9-2ad5f1239de6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>city</value>
      <webElementGuid>5906bf71-50a3-4a57-90a1-03bf4c201661</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-size</name>
      <type>Main</type>
      <value>5</value>
      <webElementGuid>d15d9569-b816-46f5-812f-67d8d52ed02b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-live-search</name>
      <type>Main</type>
      <value>true</value>
      <webElementGuid>c6a7ee07-7b31-41ba-b8a7-c9ff93e76917</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>onchange</name>
      <type>Main</type>
      <value>cityChange(this)</value>
      <webElementGuid>663bbc7f-a0df-453d-a95a-c7094263b706</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-required</name>
      <type>Main</type>
      <value>true</value>
      <webElementGuid>64bdc27b-a60b-4509-aedf-65972d480c31</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tabindex</name>
      <type>Main</type>
      <value>-98</value>
      <webElementGuid>b069e8be-7c89-4f18-a91c-e86d5f858f29</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
																		Kab. Aceh Barat
Kab. Aceh Barat Daya
Kab. Aceh Besar
Kab. Aceh Jaya
Kab. Aceh Selatan
Kab. Aceh Singkil
Kab. Aceh Tamiang
Kab. Aceh Tengah
Kab. Aceh Tenggara
Kab. Aceh Timur
Kab. Aceh Utara
Kab. Agam
Kab. Alor
Kab. Asahan
Kab. Asmat
Kab. Badung
Kab. Balangan
Kab. Bandung
Kab. Bandung Barat
Kab. Banggai
Kab. Banggai Kepulauan
Kab. Banggai Laut
Kab. Bangka
Kab. Bangka Barat
Kab. Bangkalan
Kab. Bangka Selatan
Kab. Bangka Tengah
Kab. Bangli
Kab. Banjar
Kab. Banjarnegara
Kab. Bantaeng
Kab. Bantul
Kab. Banyuasin
Kab. Banyumas
Kab. Banyuwangi
Kab. Barito Kuala
Kab. Barito Selatan
Kab. Barito Timur
Kab. Barito Utara
Kab. Barru
Kab. Batang
Kab. Batang Hari
Kab. Batu Bara
Kab. Bekasi
Kab. Belitung
Kab. Belitung Timur
Kab. Belu
Kab. Bener Meriah
Kab. Bengkalis
Kab. Bengkayang
Kab. Bengkulu Selatan
Kab. Bengkulu Tengah
Kab. Bengkulu Utara
Kab. Berau
Kab. Biak Numfor
Kab. Bima
Kab. Bintan
Kab. Bireuen
Kab. Blitar
Kab. Blora
Kab. Boalemo
Kab. Bogor
Kab. Bojonegoro
Kab. Bolaang Mongondow
Kab. Bolaang Mongondow Selatan
Kab. Bolaang Mongondow Timur
Kab. Bolaang Mongondow Utara
Kab. Bombana
Kab. Bondowoso
Kab. Bone
Kab. Bone Bolango
Kab. Boven Digoel
Kab. Boyolali
Kab. Brebes
Kab. Buleleng
Kab. Bulukumba
Kab. Bulungan
Kab. Bungo
Kab. Buol
Kab. Buru
Kab. Buru Selatan
Kab. Buton
Kab. Buton Selatan
Kab. Buton Tengah
Kab. Buton Utara
Kab. Ciamis
Kab. Cianjur
Kab. Cilacap
Kab. Cirebon
Kab. Dairi
Kab. Deiyai
Kab. Deli Serdang
Kab. Demak
Kab. Dharmasraya
Kab. Dogiyai
Kab. Dompu
Kab. Donggala
Kab. Empat Lawang
Kab. Ende
Kab. Enrekang
Kab. Fakfak
Kab. Flores Timur
Kab. Garut
Kab. Gayo Lues
Kab. Gianyar
Kab. Gorontalo
Kab. Gorontalo Utara
Kab. Gowa
Kab. Gresik
Kab. Grobogan
Kab. Gunung Kidul
Kab. Gunung Mas
Kab. Halmahera Barat
Kab. Halmahera Selatan
Kab. Halmahera Tengah
Kab. Halmahera Timur
Kab. Halmahera Utara
Kab. Hulu Sungai Selatan
Kab. Hulu Sungai Tengah
Kab. Hulu Sungai Utara
Kab. Humbang Hasundutan
Kab. Indragiri Hilir
Kab. Indragiri Hulu
Kab. Indramayu
Kab. Intan Jaya
Kab. Jayapura
Kab. Jayawijaya
Kab. Jember
Kab. Jembrana
Kab. Jeneponto
Kab. Jepara
Kab. Jombang
Kab. Kaimana
Kab. Kampar
Kab. Kapuas
Kab. Kapuas Hulu
Kab. Karanganyar
Kab. Karangasem
Kab. Karawang
Kab. Karimun
Kab. Karo
Kab. Katingan
Kab. Kaur
Kab. Kayong Utara
Kab. Kebumen
Kab. Kediri
Kab. Keerom
Kab. Kendal
Kab. Kepahiang
Kab. Kepulauan Anambas
Kab. Kepulauan Aru
Kab. Kepulauan Mentawai
Kab. Kepulauan Meranti
Kab. Kepulauan Sangihe
Kab. Kepulauan Selayar
Kab. Kepulauan Seribu
Kab. Kepulauan Siau Tagulandang Biaro (Sitaro)
Kab. Kepulauan Sula
Kab. Kepulauan Talaud
Kab. Kepulauan Yapen
Kab. Kerinci
Kab. Ketapang
Kab. Klaten
Kab. Klungkung
Kab. Kolaka
Kab. Kolaka Timur
Kab. Kolaka Utara
Kab. Konawe
Kab. Konawe Kepulauan
Kab. Konawe Selatan
Kab. Konawe Utara
Kab. Kotabaru
Kab. Kotawaringin Barat
Kab. Kotawaringin Timur
Kab. Kuantan Singingi
Kab. Kubu Raya
Kab. Kudus
Kab. Kulon Progo
Kab. Kuningan
Kab. Kupang
Kab. Kutai Barat
Kab. Kutai Kartanegara
Kab. Kutai Timur
Kab. Labuhanbatu
Kab. Labuhanbatu Selatan
Kab. Labuhanbatu Utara
Kab. Lahat
Kab. Lamandau
Kab. Lamongan
Kab. Lampung Barat
Kab. Lampung Selatan
Kab. Lampung Tengah
Kab. Lampung Timur
Kab. Lampung Utara
Kab. Landak
Kab. Langkat
Kab. Lanny Jaya
Kab. Lebak
Kab. Lebong
Kab. Lembata
Kab. Lima Puluh Kota
Kab. Lingga
Kab. Lombok Barat
Kab. Lombok Tengah
Kab. Lombok Timur
Kab. Lombok Utara
Kab. Lumajang
Kab. Luwu
Kab. Luwu Timur
Kab. Luwu Utara
Kab. Madiun
Kab. Magelang
Kab. Magetan
Kab. Mahakam Ulu
Kab. Majalengka
Kab. Majene
Kab. Malaka
Kab. Malang
Kab. Malinau
Kab. Maluku Barat Daya
Kab. Maluku Tengah
Kab. Maluku Tenggara
Kab. Maluku Tenggara Barat
Kab. Mamasa
Kab. Mamberamo Raya
Kab. Mamberamo Tengah
Kab. Mamuju
Kab. Mamuju Tengah
Kab. Mamuju Utara
Kab. Mandailing Natal
Kab. Manggarai
Kab. Manggarai Barat
Kab. Manggarai Timur
Kab. Manokwari
Kab. Manokwari Selatan
Kab. Mappi
Kab. Maros
Kab. Maybrat
Kab. Melawi
Kab. Mempawah
Kab. Merangin
Kab. Merauke
Kab. Mesuji
Kab. Mimika
Kab. Minahasa
Kab. Minahasa Selatan
Kab. Minahasa Tenggara
Kab. Minahasa Utara
Kab. Mojokerto
Kab. Morowali
Kab. Morowali Utara
Kab. Muara Enim
Kab. Muaro Jambi
Kab. Muko Muko
Kab. Muna
Kab. Muna Barat
Kab. Murung Raya
Kab. Musi Banyuasin
Kab. Musi Rawas
Kab. Musi Rawas Utara
Kab. Nabire
Kab. Nagan Raya
Kab. Nagekeo
Kab. Natuna
Kab. Nduga
Kab. Ngada
Kab. Nganjuk
Kab. Ngawi
Kab. Nias
Kab. Nias Barat
Kab. Nias Selatan
Kab. Nias Utara
Kab. Nunukan
Kab. Ogan Ilir
Kab. Ogan Komering Ilir
Kab. Ogan Komering Ulu
Kab. Ogan Komering Ulu Selatan
Kab. Ogan Komering Ulu Timur
Kab. Pacitan
Kab. Padang Lawas
Kab. Padang Lawas Utara
Kab. Padang Pariaman
Kab. Pakpak Bharat
Kab. Pamekasan
Kab. Pandeglang
Kab. Pangandaran
Kab. Pangkajene Kepulauan
Kab. Paniai
Kab. Parigi Moutong
Kab. Pasaman
Kab. Pasaman Barat
Kab. Paser
Kab. Pasuruan
Kab. Pati
Kab. Pegunungan Arfak
Kab. Pegunungan Bintang
Kab. Pekalongan
Kab. Pelalawan
Kab. Pemalang
Kab. Penajam Paser Utara
Kab. Penukal Abab Lematang Ilir
Kab. Pesawaran
Kab. Pesisir Barat
Kab. Pesisir Selatan
Kab. Pidie
Kab. Pidie Jaya
Kab. Pinrang
Kab. Pohuwato
Kab. Polewali Mandar
Kab. Ponorogo
Kab. Poso
Kab. Pringsewu
Kab. Probolinggo
Kab. Pulang Pisau
Kab. Pulau Morotai
Kab. Pulau Taliabu
Kab. Puncak
Kab. Puncak Jaya
Kab. Purbalingga
Kab. Purwakarta
Kab. Purworejo
Kab. Raja Ampat
Kab. Rejang Lebong
Kab. Rembang
Kab. Rokan Hilir
Kab. Rokan Hulu
Kab. Rote Ndao
Kab. Sabu Raijua
Kab. Sambas
Kab. Samosir
Kab. Sampang
Kab. Sanggau
Kab. Sarmi
Kab. Sarolangun
Kab. Sekadau
Kab. Seluma
Kab. Semarang
Kab. Seram Bagian Barat
Kab. Seram Bagian Timur
Kab. Serang
Kab. Serdang Bedagai
Kab. Seruyan
Kab. Siak
Kab. Sidenreng Rappang
Kab. Sidoarjo
Kab. Sigi
Kab. Sijunjung
Kab. Sikka
Kab. Simalungun
Kab. Simeulue
Kab. Sinjai
Kab. Sintang
Kab. Situbondo
Kab. Sleman
Kab. Solok
Kab. Solok Selatan
Kab. Soppeng
Kab. Sorong
Kab. Sorong Selatan
Kab. Sragen
Kab. Subang
Kab. Sukabumi
Kab. Sukamara
Kab. Sukoharjo
Kab. Sumba Barat
Kab. Sumba Barat Daya
Kab. Sumba Tengah
Kab. Sumba Timur
Kab. Sumbawa
Kab. Sumbawa Barat
Kab. Sumedang
Kab. Sumenep
Kab. Supiori
Kab. Tabalong
Kab. Tabanan
Kab. Takalar
Kab. Tambrauw
Kab. Tanah Bumbu
Kab. Tanah Datar
Kab. Tanah Laut
Kab. Tana Tidung
Kab. Tana Toraja
Kab. Tangerang
Kab. Tanggamus
Kab. Tanjung Jabung Barat
Kab. Tanjung Jabung Timur
Kab. Tapanuli Selatan
Kab. Tapanuli Tengah
Kab. Tapanuli Utara
Kab. Tapin
Kab. Tasikmalaya
Kab. Tebo
Kab. Tegal
Kab. Teluk Bintuni
Kab. Teluk Wondama
Kab. Temanggung
Kab. Timor Tengah Selatan
Kab. Timor Tengah Utara
Kab. Toba Samosir
Kab. Tojo Una-Una
Kab. Tolikara
Kab. Toli-Toli
Kab. Toraja Utara
Kab. Trenggalek
Kab. Tuban
Kab. Tulang Bawang
Kab. Tulang Bawang Barat
Kab. Tulungagung
Kab. Wajo
Kab. Wakatobi
Kab. Waropen
Kab. Way Kanan
Kab. Wonogiri
Kab. Wonosobo
Kab. Yahukimo
Kab. Yalimo
Kota Ambon
Kota Balikpapan
Kota Banda Aceh
Kota Bandar Lampung
Kota Bandung
Kota Banjar
Kota Banjarbaru
Kota Banjarmasin
Kota Batam
Kota Batu
Kota Bau-Bau
Kota Bekasi
Kota Bengkulu
Kota Bima
Kota Binjai
Kota Bitung
Kota Blitar
Kota Bogor
Kota Bontang
Kota Bukittinggi
Kota Cilegon
Kota Cimahi
Kota Cirebon
Kota Denpasar
Kota Depok
Kota Dumai
Kota Gorontalo
Kota Gunungsitoli
Kota Jakarta Barat
Kota Jakarta Pusat
Kota Jakarta Selatan
Kota Jakarta Timur
Kota Jakarta Utara
Kota Jambi
Kota Jayapura
Kota Kediri
Kota Kendari
Kota Kotamobagu
Kota Kupang
Kota Langsa
Kota Lhokseumawe
Kota Lubuk Linggau
Kota Madiun
Kota Magelang
Kota Makassar
Kota Malang
Kota Manado
Kota Mataram
Kota Medan
Kota Metro
Kota Mojokerto
Kota Padang
Kota Padang Panjang
Kota Padang Sidempuan
Kota Pagar Alam
Kota Palangka Raya
Kota Palembang
Kota Palopo
Kota Palu
Kota Pangkal Pinang
Kota Parepare
Kota Pariaman
Kota Pasuruan
Kota Payakumbuh
Kota Pekalongan
Kota Pekanbaru
Kota Pematang Siantar
Kota Pontianak
Kota Prabumulih
Kota Probolinggo
Kota Sabang
Kota Salatiga
Kota Samarinda
Kota Sawah Lunto
Kota Semarang
Kota Serang
Kota Sibolga
Kota Singkawang
Kota Solok
Kota Sorong
Kota Subulussalam
Kota Sukabumi
Kota Sungaipenuh
Kota Surabaya
Kota Surakarta
Kota Tangerang
Kota Tangerang Selatan
Kota Tanjung Balai
Kota Tanjung Pinang
Kota Tarakan
Kota Tasikmalaya
Kota Tebing Tinggi
Kota Tegal
Kota Ternate
Kota Tidore Kepulauan
Kota Tomohon
Kota Tual
Kota Yogyakarta
</value>
      <webElementGuid>3b262977-0b8c-4339-bdaf-bcd1a1f6fdb1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;city&quot;)</value>
      <webElementGuid>ea31ada8-e03a-4659-9752-d6b1f48e4b06</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//select[@id='city']</value>
      <webElementGuid>4776fd19-9430-476a-a7e1-4c8b89094183</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//fieldset[@id='dashboardForm-p-0']/div/div/div/div/div/div[3]/div[7]/div[2]/div/div/div/select</value>
      <webElementGuid>6797b81d-0b2a-4d93-b57e-3ab47eeacb1a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Kabupaten / Kota'])[1]/following::select[1]</value>
      <webElementGuid>1315c5b9-e25b-44d9-97a6-5ab08e9e90d8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sumatera Utara'])[2]/following::select[1]</value>
      <webElementGuid>7c999673-3ad1-4be2-adeb-86de660efb85</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Tidak ada yang dipilih'])[2]/preceding::select[1]</value>
      <webElementGuid>915066d2-85d0-4370-bc68-27aa8471656b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Kota Depok'])[3]/preceding::select[1]</value>
      <webElementGuid>f445c89e-05b0-4aba-876a-3821aacddf90</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/div[7]/div[2]/div/div/div/select</value>
      <webElementGuid>a24b6211-ed16-407a-af25-e5765db69607</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//select[@name = 'user.location.parent.parent.id' and @id = 'city' and (text() = '
																		Kab. Aceh Barat
Kab. Aceh Barat Daya
Kab. Aceh Besar
Kab. Aceh Jaya
Kab. Aceh Selatan
Kab. Aceh Singkil
Kab. Aceh Tamiang
Kab. Aceh Tengah
Kab. Aceh Tenggara
Kab. Aceh Timur
Kab. Aceh Utara
Kab. Agam
Kab. Alor
Kab. Asahan
Kab. Asmat
Kab. Badung
Kab. Balangan
Kab. Bandung
Kab. Bandung Barat
Kab. Banggai
Kab. Banggai Kepulauan
Kab. Banggai Laut
Kab. Bangka
Kab. Bangka Barat
Kab. Bangkalan
Kab. Bangka Selatan
Kab. Bangka Tengah
Kab. Bangli
Kab. Banjar
Kab. Banjarnegara
Kab. Bantaeng
Kab. Bantul
Kab. Banyuasin
Kab. Banyumas
Kab. Banyuwangi
Kab. Barito Kuala
Kab. Barito Selatan
Kab. Barito Timur
Kab. Barito Utara
Kab. Barru
Kab. Batang
Kab. Batang Hari
Kab. Batu Bara
Kab. Bekasi
Kab. Belitung
Kab. Belitung Timur
Kab. Belu
Kab. Bener Meriah
Kab. Bengkalis
Kab. Bengkayang
Kab. Bengkulu Selatan
Kab. Bengkulu Tengah
Kab. Bengkulu Utara
Kab. Berau
Kab. Biak Numfor
Kab. Bima
Kab. Bintan
Kab. Bireuen
Kab. Blitar
Kab. Blora
Kab. Boalemo
Kab. Bogor
Kab. Bojonegoro
Kab. Bolaang Mongondow
Kab. Bolaang Mongondow Selatan
Kab. Bolaang Mongondow Timur
Kab. Bolaang Mongondow Utara
Kab. Bombana
Kab. Bondowoso
Kab. Bone
Kab. Bone Bolango
Kab. Boven Digoel
Kab. Boyolali
Kab. Brebes
Kab. Buleleng
Kab. Bulukumba
Kab. Bulungan
Kab. Bungo
Kab. Buol
Kab. Buru
Kab. Buru Selatan
Kab. Buton
Kab. Buton Selatan
Kab. Buton Tengah
Kab. Buton Utara
Kab. Ciamis
Kab. Cianjur
Kab. Cilacap
Kab. Cirebon
Kab. Dairi
Kab. Deiyai
Kab. Deli Serdang
Kab. Demak
Kab. Dharmasraya
Kab. Dogiyai
Kab. Dompu
Kab. Donggala
Kab. Empat Lawang
Kab. Ende
Kab. Enrekang
Kab. Fakfak
Kab. Flores Timur
Kab. Garut
Kab. Gayo Lues
Kab. Gianyar
Kab. Gorontalo
Kab. Gorontalo Utara
Kab. Gowa
Kab. Gresik
Kab. Grobogan
Kab. Gunung Kidul
Kab. Gunung Mas
Kab. Halmahera Barat
Kab. Halmahera Selatan
Kab. Halmahera Tengah
Kab. Halmahera Timur
Kab. Halmahera Utara
Kab. Hulu Sungai Selatan
Kab. Hulu Sungai Tengah
Kab. Hulu Sungai Utara
Kab. Humbang Hasundutan
Kab. Indragiri Hilir
Kab. Indragiri Hulu
Kab. Indramayu
Kab. Intan Jaya
Kab. Jayapura
Kab. Jayawijaya
Kab. Jember
Kab. Jembrana
Kab. Jeneponto
Kab. Jepara
Kab. Jombang
Kab. Kaimana
Kab. Kampar
Kab. Kapuas
Kab. Kapuas Hulu
Kab. Karanganyar
Kab. Karangasem
Kab. Karawang
Kab. Karimun
Kab. Karo
Kab. Katingan
Kab. Kaur
Kab. Kayong Utara
Kab. Kebumen
Kab. Kediri
Kab. Keerom
Kab. Kendal
Kab. Kepahiang
Kab. Kepulauan Anambas
Kab. Kepulauan Aru
Kab. Kepulauan Mentawai
Kab. Kepulauan Meranti
Kab. Kepulauan Sangihe
Kab. Kepulauan Selayar
Kab. Kepulauan Seribu
Kab. Kepulauan Siau Tagulandang Biaro (Sitaro)
Kab. Kepulauan Sula
Kab. Kepulauan Talaud
Kab. Kepulauan Yapen
Kab. Kerinci
Kab. Ketapang
Kab. Klaten
Kab. Klungkung
Kab. Kolaka
Kab. Kolaka Timur
Kab. Kolaka Utara
Kab. Konawe
Kab. Konawe Kepulauan
Kab. Konawe Selatan
Kab. Konawe Utara
Kab. Kotabaru
Kab. Kotawaringin Barat
Kab. Kotawaringin Timur
Kab. Kuantan Singingi
Kab. Kubu Raya
Kab. Kudus
Kab. Kulon Progo
Kab. Kuningan
Kab. Kupang
Kab. Kutai Barat
Kab. Kutai Kartanegara
Kab. Kutai Timur
Kab. Labuhanbatu
Kab. Labuhanbatu Selatan
Kab. Labuhanbatu Utara
Kab. Lahat
Kab. Lamandau
Kab. Lamongan
Kab. Lampung Barat
Kab. Lampung Selatan
Kab. Lampung Tengah
Kab. Lampung Timur
Kab. Lampung Utara
Kab. Landak
Kab. Langkat
Kab. Lanny Jaya
Kab. Lebak
Kab. Lebong
Kab. Lembata
Kab. Lima Puluh Kota
Kab. Lingga
Kab. Lombok Barat
Kab. Lombok Tengah
Kab. Lombok Timur
Kab. Lombok Utara
Kab. Lumajang
Kab. Luwu
Kab. Luwu Timur
Kab. Luwu Utara
Kab. Madiun
Kab. Magelang
Kab. Magetan
Kab. Mahakam Ulu
Kab. Majalengka
Kab. Majene
Kab. Malaka
Kab. Malang
Kab. Malinau
Kab. Maluku Barat Daya
Kab. Maluku Tengah
Kab. Maluku Tenggara
Kab. Maluku Tenggara Barat
Kab. Mamasa
Kab. Mamberamo Raya
Kab. Mamberamo Tengah
Kab. Mamuju
Kab. Mamuju Tengah
Kab. Mamuju Utara
Kab. Mandailing Natal
Kab. Manggarai
Kab. Manggarai Barat
Kab. Manggarai Timur
Kab. Manokwari
Kab. Manokwari Selatan
Kab. Mappi
Kab. Maros
Kab. Maybrat
Kab. Melawi
Kab. Mempawah
Kab. Merangin
Kab. Merauke
Kab. Mesuji
Kab. Mimika
Kab. Minahasa
Kab. Minahasa Selatan
Kab. Minahasa Tenggara
Kab. Minahasa Utara
Kab. Mojokerto
Kab. Morowali
Kab. Morowali Utara
Kab. Muara Enim
Kab. Muaro Jambi
Kab. Muko Muko
Kab. Muna
Kab. Muna Barat
Kab. Murung Raya
Kab. Musi Banyuasin
Kab. Musi Rawas
Kab. Musi Rawas Utara
Kab. Nabire
Kab. Nagan Raya
Kab. Nagekeo
Kab. Natuna
Kab. Nduga
Kab. Ngada
Kab. Nganjuk
Kab. Ngawi
Kab. Nias
Kab. Nias Barat
Kab. Nias Selatan
Kab. Nias Utara
Kab. Nunukan
Kab. Ogan Ilir
Kab. Ogan Komering Ilir
Kab. Ogan Komering Ulu
Kab. Ogan Komering Ulu Selatan
Kab. Ogan Komering Ulu Timur
Kab. Pacitan
Kab. Padang Lawas
Kab. Padang Lawas Utara
Kab. Padang Pariaman
Kab. Pakpak Bharat
Kab. Pamekasan
Kab. Pandeglang
Kab. Pangandaran
Kab. Pangkajene Kepulauan
Kab. Paniai
Kab. Parigi Moutong
Kab. Pasaman
Kab. Pasaman Barat
Kab. Paser
Kab. Pasuruan
Kab. Pati
Kab. Pegunungan Arfak
Kab. Pegunungan Bintang
Kab. Pekalongan
Kab. Pelalawan
Kab. Pemalang
Kab. Penajam Paser Utara
Kab. Penukal Abab Lematang Ilir
Kab. Pesawaran
Kab. Pesisir Barat
Kab. Pesisir Selatan
Kab. Pidie
Kab. Pidie Jaya
Kab. Pinrang
Kab. Pohuwato
Kab. Polewali Mandar
Kab. Ponorogo
Kab. Poso
Kab. Pringsewu
Kab. Probolinggo
Kab. Pulang Pisau
Kab. Pulau Morotai
Kab. Pulau Taliabu
Kab. Puncak
Kab. Puncak Jaya
Kab. Purbalingga
Kab. Purwakarta
Kab. Purworejo
Kab. Raja Ampat
Kab. Rejang Lebong
Kab. Rembang
Kab. Rokan Hilir
Kab. Rokan Hulu
Kab. Rote Ndao
Kab. Sabu Raijua
Kab. Sambas
Kab. Samosir
Kab. Sampang
Kab. Sanggau
Kab. Sarmi
Kab. Sarolangun
Kab. Sekadau
Kab. Seluma
Kab. Semarang
Kab. Seram Bagian Barat
Kab. Seram Bagian Timur
Kab. Serang
Kab. Serdang Bedagai
Kab. Seruyan
Kab. Siak
Kab. Sidenreng Rappang
Kab. Sidoarjo
Kab. Sigi
Kab. Sijunjung
Kab. Sikka
Kab. Simalungun
Kab. Simeulue
Kab. Sinjai
Kab. Sintang
Kab. Situbondo
Kab. Sleman
Kab. Solok
Kab. Solok Selatan
Kab. Soppeng
Kab. Sorong
Kab. Sorong Selatan
Kab. Sragen
Kab. Subang
Kab. Sukabumi
Kab. Sukamara
Kab. Sukoharjo
Kab. Sumba Barat
Kab. Sumba Barat Daya
Kab. Sumba Tengah
Kab. Sumba Timur
Kab. Sumbawa
Kab. Sumbawa Barat
Kab. Sumedang
Kab. Sumenep
Kab. Supiori
Kab. Tabalong
Kab. Tabanan
Kab. Takalar
Kab. Tambrauw
Kab. Tanah Bumbu
Kab. Tanah Datar
Kab. Tanah Laut
Kab. Tana Tidung
Kab. Tana Toraja
Kab. Tangerang
Kab. Tanggamus
Kab. Tanjung Jabung Barat
Kab. Tanjung Jabung Timur
Kab. Tapanuli Selatan
Kab. Tapanuli Tengah
Kab. Tapanuli Utara
Kab. Tapin
Kab. Tasikmalaya
Kab. Tebo
Kab. Tegal
Kab. Teluk Bintuni
Kab. Teluk Wondama
Kab. Temanggung
Kab. Timor Tengah Selatan
Kab. Timor Tengah Utara
Kab. Toba Samosir
Kab. Tojo Una-Una
Kab. Tolikara
Kab. Toli-Toli
Kab. Toraja Utara
Kab. Trenggalek
Kab. Tuban
Kab. Tulang Bawang
Kab. Tulang Bawang Barat
Kab. Tulungagung
Kab. Wajo
Kab. Wakatobi
Kab. Waropen
Kab. Way Kanan
Kab. Wonogiri
Kab. Wonosobo
Kab. Yahukimo
Kab. Yalimo
Kota Ambon
Kota Balikpapan
Kota Banda Aceh
Kota Bandar Lampung
Kota Bandung
Kota Banjar
Kota Banjarbaru
Kota Banjarmasin
Kota Batam
Kota Batu
Kota Bau-Bau
Kota Bekasi
Kota Bengkulu
Kota Bima
Kota Binjai
Kota Bitung
Kota Blitar
Kota Bogor
Kota Bontang
Kota Bukittinggi
Kota Cilegon
Kota Cimahi
Kota Cirebon
Kota Denpasar
Kota Depok
Kota Dumai
Kota Gorontalo
Kota Gunungsitoli
Kota Jakarta Barat
Kota Jakarta Pusat
Kota Jakarta Selatan
Kota Jakarta Timur
Kota Jakarta Utara
Kota Jambi
Kota Jayapura
Kota Kediri
Kota Kendari
Kota Kotamobagu
Kota Kupang
Kota Langsa
Kota Lhokseumawe
Kota Lubuk Linggau
Kota Madiun
Kota Magelang
Kota Makassar
Kota Malang
Kota Manado
Kota Mataram
Kota Medan
Kota Metro
Kota Mojokerto
Kota Padang
Kota Padang Panjang
Kota Padang Sidempuan
Kota Pagar Alam
Kota Palangka Raya
Kota Palembang
Kota Palopo
Kota Palu
Kota Pangkal Pinang
Kota Parepare
Kota Pariaman
Kota Pasuruan
Kota Payakumbuh
Kota Pekalongan
Kota Pekanbaru
Kota Pematang Siantar
Kota Pontianak
Kota Prabumulih
Kota Probolinggo
Kota Sabang
Kota Salatiga
Kota Samarinda
Kota Sawah Lunto
Kota Semarang
Kota Serang
Kota Sibolga
Kota Singkawang
Kota Solok
Kota Sorong
Kota Subulussalam
Kota Sukabumi
Kota Sungaipenuh
Kota Surabaya
Kota Surakarta
Kota Tangerang
Kota Tangerang Selatan
Kota Tanjung Balai
Kota Tanjung Pinang
Kota Tarakan
Kota Tasikmalaya
Kota Tebing Tinggi
Kota Tegal
Kota Ternate
Kota Tidore Kepulauan
Kota Tomohon
Kota Tual
Kota Yogyakarta
' or . = '
																		Kab. Aceh Barat
Kab. Aceh Barat Daya
Kab. Aceh Besar
Kab. Aceh Jaya
Kab. Aceh Selatan
Kab. Aceh Singkil
Kab. Aceh Tamiang
Kab. Aceh Tengah
Kab. Aceh Tenggara
Kab. Aceh Timur
Kab. Aceh Utara
Kab. Agam
Kab. Alor
Kab. Asahan
Kab. Asmat
Kab. Badung
Kab. Balangan
Kab. Bandung
Kab. Bandung Barat
Kab. Banggai
Kab. Banggai Kepulauan
Kab. Banggai Laut
Kab. Bangka
Kab. Bangka Barat
Kab. Bangkalan
Kab. Bangka Selatan
Kab. Bangka Tengah
Kab. Bangli
Kab. Banjar
Kab. Banjarnegara
Kab. Bantaeng
Kab. Bantul
Kab. Banyuasin
Kab. Banyumas
Kab. Banyuwangi
Kab. Barito Kuala
Kab. Barito Selatan
Kab. Barito Timur
Kab. Barito Utara
Kab. Barru
Kab. Batang
Kab. Batang Hari
Kab. Batu Bara
Kab. Bekasi
Kab. Belitung
Kab. Belitung Timur
Kab. Belu
Kab. Bener Meriah
Kab. Bengkalis
Kab. Bengkayang
Kab. Bengkulu Selatan
Kab. Bengkulu Tengah
Kab. Bengkulu Utara
Kab. Berau
Kab. Biak Numfor
Kab. Bima
Kab. Bintan
Kab. Bireuen
Kab. Blitar
Kab. Blora
Kab. Boalemo
Kab. Bogor
Kab. Bojonegoro
Kab. Bolaang Mongondow
Kab. Bolaang Mongondow Selatan
Kab. Bolaang Mongondow Timur
Kab. Bolaang Mongondow Utara
Kab. Bombana
Kab. Bondowoso
Kab. Bone
Kab. Bone Bolango
Kab. Boven Digoel
Kab. Boyolali
Kab. Brebes
Kab. Buleleng
Kab. Bulukumba
Kab. Bulungan
Kab. Bungo
Kab. Buol
Kab. Buru
Kab. Buru Selatan
Kab. Buton
Kab. Buton Selatan
Kab. Buton Tengah
Kab. Buton Utara
Kab. Ciamis
Kab. Cianjur
Kab. Cilacap
Kab. Cirebon
Kab. Dairi
Kab. Deiyai
Kab. Deli Serdang
Kab. Demak
Kab. Dharmasraya
Kab. Dogiyai
Kab. Dompu
Kab. Donggala
Kab. Empat Lawang
Kab. Ende
Kab. Enrekang
Kab. Fakfak
Kab. Flores Timur
Kab. Garut
Kab. Gayo Lues
Kab. Gianyar
Kab. Gorontalo
Kab. Gorontalo Utara
Kab. Gowa
Kab. Gresik
Kab. Grobogan
Kab. Gunung Kidul
Kab. Gunung Mas
Kab. Halmahera Barat
Kab. Halmahera Selatan
Kab. Halmahera Tengah
Kab. Halmahera Timur
Kab. Halmahera Utara
Kab. Hulu Sungai Selatan
Kab. Hulu Sungai Tengah
Kab. Hulu Sungai Utara
Kab. Humbang Hasundutan
Kab. Indragiri Hilir
Kab. Indragiri Hulu
Kab. Indramayu
Kab. Intan Jaya
Kab. Jayapura
Kab. Jayawijaya
Kab. Jember
Kab. Jembrana
Kab. Jeneponto
Kab. Jepara
Kab. Jombang
Kab. Kaimana
Kab. Kampar
Kab. Kapuas
Kab. Kapuas Hulu
Kab. Karanganyar
Kab. Karangasem
Kab. Karawang
Kab. Karimun
Kab. Karo
Kab. Katingan
Kab. Kaur
Kab. Kayong Utara
Kab. Kebumen
Kab. Kediri
Kab. Keerom
Kab. Kendal
Kab. Kepahiang
Kab. Kepulauan Anambas
Kab. Kepulauan Aru
Kab. Kepulauan Mentawai
Kab. Kepulauan Meranti
Kab. Kepulauan Sangihe
Kab. Kepulauan Selayar
Kab. Kepulauan Seribu
Kab. Kepulauan Siau Tagulandang Biaro (Sitaro)
Kab. Kepulauan Sula
Kab. Kepulauan Talaud
Kab. Kepulauan Yapen
Kab. Kerinci
Kab. Ketapang
Kab. Klaten
Kab. Klungkung
Kab. Kolaka
Kab. Kolaka Timur
Kab. Kolaka Utara
Kab. Konawe
Kab. Konawe Kepulauan
Kab. Konawe Selatan
Kab. Konawe Utara
Kab. Kotabaru
Kab. Kotawaringin Barat
Kab. Kotawaringin Timur
Kab. Kuantan Singingi
Kab. Kubu Raya
Kab. Kudus
Kab. Kulon Progo
Kab. Kuningan
Kab. Kupang
Kab. Kutai Barat
Kab. Kutai Kartanegara
Kab. Kutai Timur
Kab. Labuhanbatu
Kab. Labuhanbatu Selatan
Kab. Labuhanbatu Utara
Kab. Lahat
Kab. Lamandau
Kab. Lamongan
Kab. Lampung Barat
Kab. Lampung Selatan
Kab. Lampung Tengah
Kab. Lampung Timur
Kab. Lampung Utara
Kab. Landak
Kab. Langkat
Kab. Lanny Jaya
Kab. Lebak
Kab. Lebong
Kab. Lembata
Kab. Lima Puluh Kota
Kab. Lingga
Kab. Lombok Barat
Kab. Lombok Tengah
Kab. Lombok Timur
Kab. Lombok Utara
Kab. Lumajang
Kab. Luwu
Kab. Luwu Timur
Kab. Luwu Utara
Kab. Madiun
Kab. Magelang
Kab. Magetan
Kab. Mahakam Ulu
Kab. Majalengka
Kab. Majene
Kab. Malaka
Kab. Malang
Kab. Malinau
Kab. Maluku Barat Daya
Kab. Maluku Tengah
Kab. Maluku Tenggara
Kab. Maluku Tenggara Barat
Kab. Mamasa
Kab. Mamberamo Raya
Kab. Mamberamo Tengah
Kab. Mamuju
Kab. Mamuju Tengah
Kab. Mamuju Utara
Kab. Mandailing Natal
Kab. Manggarai
Kab. Manggarai Barat
Kab. Manggarai Timur
Kab. Manokwari
Kab. Manokwari Selatan
Kab. Mappi
Kab. Maros
Kab. Maybrat
Kab. Melawi
Kab. Mempawah
Kab. Merangin
Kab. Merauke
Kab. Mesuji
Kab. Mimika
Kab. Minahasa
Kab. Minahasa Selatan
Kab. Minahasa Tenggara
Kab. Minahasa Utara
Kab. Mojokerto
Kab. Morowali
Kab. Morowali Utara
Kab. Muara Enim
Kab. Muaro Jambi
Kab. Muko Muko
Kab. Muna
Kab. Muna Barat
Kab. Murung Raya
Kab. Musi Banyuasin
Kab. Musi Rawas
Kab. Musi Rawas Utara
Kab. Nabire
Kab. Nagan Raya
Kab. Nagekeo
Kab. Natuna
Kab. Nduga
Kab. Ngada
Kab. Nganjuk
Kab. Ngawi
Kab. Nias
Kab. Nias Barat
Kab. Nias Selatan
Kab. Nias Utara
Kab. Nunukan
Kab. Ogan Ilir
Kab. Ogan Komering Ilir
Kab. Ogan Komering Ulu
Kab. Ogan Komering Ulu Selatan
Kab. Ogan Komering Ulu Timur
Kab. Pacitan
Kab. Padang Lawas
Kab. Padang Lawas Utara
Kab. Padang Pariaman
Kab. Pakpak Bharat
Kab. Pamekasan
Kab. Pandeglang
Kab. Pangandaran
Kab. Pangkajene Kepulauan
Kab. Paniai
Kab. Parigi Moutong
Kab. Pasaman
Kab. Pasaman Barat
Kab. Paser
Kab. Pasuruan
Kab. Pati
Kab. Pegunungan Arfak
Kab. Pegunungan Bintang
Kab. Pekalongan
Kab. Pelalawan
Kab. Pemalang
Kab. Penajam Paser Utara
Kab. Penukal Abab Lematang Ilir
Kab. Pesawaran
Kab. Pesisir Barat
Kab. Pesisir Selatan
Kab. Pidie
Kab. Pidie Jaya
Kab. Pinrang
Kab. Pohuwato
Kab. Polewali Mandar
Kab. Ponorogo
Kab. Poso
Kab. Pringsewu
Kab. Probolinggo
Kab. Pulang Pisau
Kab. Pulau Morotai
Kab. Pulau Taliabu
Kab. Puncak
Kab. Puncak Jaya
Kab. Purbalingga
Kab. Purwakarta
Kab. Purworejo
Kab. Raja Ampat
Kab. Rejang Lebong
Kab. Rembang
Kab. Rokan Hilir
Kab. Rokan Hulu
Kab. Rote Ndao
Kab. Sabu Raijua
Kab. Sambas
Kab. Samosir
Kab. Sampang
Kab. Sanggau
Kab. Sarmi
Kab. Sarolangun
Kab. Sekadau
Kab. Seluma
Kab. Semarang
Kab. Seram Bagian Barat
Kab. Seram Bagian Timur
Kab. Serang
Kab. Serdang Bedagai
Kab. Seruyan
Kab. Siak
Kab. Sidenreng Rappang
Kab. Sidoarjo
Kab. Sigi
Kab. Sijunjung
Kab. Sikka
Kab. Simalungun
Kab. Simeulue
Kab. Sinjai
Kab. Sintang
Kab. Situbondo
Kab. Sleman
Kab. Solok
Kab. Solok Selatan
Kab. Soppeng
Kab. Sorong
Kab. Sorong Selatan
Kab. Sragen
Kab. Subang
Kab. Sukabumi
Kab. Sukamara
Kab. Sukoharjo
Kab. Sumba Barat
Kab. Sumba Barat Daya
Kab. Sumba Tengah
Kab. Sumba Timur
Kab. Sumbawa
Kab. Sumbawa Barat
Kab. Sumedang
Kab. Sumenep
Kab. Supiori
Kab. Tabalong
Kab. Tabanan
Kab. Takalar
Kab. Tambrauw
Kab. Tanah Bumbu
Kab. Tanah Datar
Kab. Tanah Laut
Kab. Tana Tidung
Kab. Tana Toraja
Kab. Tangerang
Kab. Tanggamus
Kab. Tanjung Jabung Barat
Kab. Tanjung Jabung Timur
Kab. Tapanuli Selatan
Kab. Tapanuli Tengah
Kab. Tapanuli Utara
Kab. Tapin
Kab. Tasikmalaya
Kab. Tebo
Kab. Tegal
Kab. Teluk Bintuni
Kab. Teluk Wondama
Kab. Temanggung
Kab. Timor Tengah Selatan
Kab. Timor Tengah Utara
Kab. Toba Samosir
Kab. Tojo Una-Una
Kab. Tolikara
Kab. Toli-Toli
Kab. Toraja Utara
Kab. Trenggalek
Kab. Tuban
Kab. Tulang Bawang
Kab. Tulang Bawang Barat
Kab. Tulungagung
Kab. Wajo
Kab. Wakatobi
Kab. Waropen
Kab. Way Kanan
Kab. Wonogiri
Kab. Wonosobo
Kab. Yahukimo
Kab. Yalimo
Kota Ambon
Kota Balikpapan
Kota Banda Aceh
Kota Bandar Lampung
Kota Bandung
Kota Banjar
Kota Banjarbaru
Kota Banjarmasin
Kota Batam
Kota Batu
Kota Bau-Bau
Kota Bekasi
Kota Bengkulu
Kota Bima
Kota Binjai
Kota Bitung
Kota Blitar
Kota Bogor
Kota Bontang
Kota Bukittinggi
Kota Cilegon
Kota Cimahi
Kota Cirebon
Kota Denpasar
Kota Depok
Kota Dumai
Kota Gorontalo
Kota Gunungsitoli
Kota Jakarta Barat
Kota Jakarta Pusat
Kota Jakarta Selatan
Kota Jakarta Timur
Kota Jakarta Utara
Kota Jambi
Kota Jayapura
Kota Kediri
Kota Kendari
Kota Kotamobagu
Kota Kupang
Kota Langsa
Kota Lhokseumawe
Kota Lubuk Linggau
Kota Madiun
Kota Magelang
Kota Makassar
Kota Malang
Kota Manado
Kota Mataram
Kota Medan
Kota Metro
Kota Mojokerto
Kota Padang
Kota Padang Panjang
Kota Padang Sidempuan
Kota Pagar Alam
Kota Palangka Raya
Kota Palembang
Kota Palopo
Kota Palu
Kota Pangkal Pinang
Kota Parepare
Kota Pariaman
Kota Pasuruan
Kota Payakumbuh
Kota Pekalongan
Kota Pekanbaru
Kota Pematang Siantar
Kota Pontianak
Kota Prabumulih
Kota Probolinggo
Kota Sabang
Kota Salatiga
Kota Samarinda
Kota Sawah Lunto
Kota Semarang
Kota Serang
Kota Sibolga
Kota Singkawang
Kota Solok
Kota Sorong
Kota Subulussalam
Kota Sukabumi
Kota Sungaipenuh
Kota Surabaya
Kota Surakarta
Kota Tangerang
Kota Tangerang Selatan
Kota Tanjung Balai
Kota Tanjung Pinang
Kota Tarakan
Kota Tasikmalaya
Kota Tebing Tinggi
Kota Tegal
Kota Ternate
Kota Tidore Kepulauan
Kota Tomohon
Kota Tual
Kota Yogyakarta
')]</value>
      <webElementGuid>364547d8-e149-486d-a905-8ddbb3049d4e</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
