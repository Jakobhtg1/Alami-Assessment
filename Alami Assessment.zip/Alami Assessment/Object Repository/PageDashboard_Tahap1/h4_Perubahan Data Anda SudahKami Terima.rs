<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h4_Perubahan Data Anda SudahKami Terima</name>
   <tag></tag>
   <elementGuidId>545ac2f3-30d6-427b-8ce8-ddeddc20fba4</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.text-center > h4</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='modalProfilSudahLengkap']/div/div/div/div/h4</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h4</value>
      <webElementGuid>e8697a85-2cfc-40d0-8b1d-10740a287ebf</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Perubahan Data Anda SudahKami Terima</value>
      <webElementGuid>ccc60580-5f6c-4359-9be3-c45a1e3a1be4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;modalProfilSudahLengkap&quot;)/div[@class=&quot;modal-dialog modal-dialog-centered&quot;]/div[@class=&quot;modal-content&quot;]/div[@class=&quot;modal-body&quot;]/div[@class=&quot;text-center&quot;]/h4[1]</value>
      <webElementGuid>30adf4d4-0b54-40d5-9a6b-a1039417e1f8</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='modalProfilSudahLengkap']/div/div/div/div/h4</value>
      <webElementGuid>5dabf2d9-e42f-4d8e-b126-11ce893bb90d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Ambil Foto'])[1]/following::h4[1]</value>
      <webElementGuid>3bc383ab-d428-44d0-b366-05fde94b770b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Selfie'])[2]/following::h4[1]</value>
      <webElementGuid>a6ae53e0-bf20-4fd3-9c7c-3aca0df08c63</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Data Anda akan segera Kami proses dan akan berubah setelah Kami verifikasi'])[1]/preceding::h4[1]</value>
      <webElementGuid>56634714-ed55-45da-be40-c6e0f13234c1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Kembali Ke Dashboard'])[1]/preceding::h4[1]</value>
      <webElementGuid>141c4785-2d5a-47a9-8909-c00d154835d7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Perubahan Data Anda Sudah']/parent::*</value>
      <webElementGuid>c4659bde-cde8-4cd1-a5da-2b1a2439df6e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[7]/div/div/div/div/h4</value>
      <webElementGuid>6d3d2890-3253-4ed7-8635-d8c5cc8fafd8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h4[(text() = 'Perubahan Data Anda SudahKami Terima' or . = 'Perubahan Data Anda SudahKami Terima')]</value>
      <webElementGuid>c0f1755e-9df3-4467-aa7e-a22b27547cf2</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
