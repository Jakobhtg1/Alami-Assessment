<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Data Anda akan segera Kami proses dan akan berubah setelah Kami verifikasi</name>
   <tag></tag>
   <elementGuidId>f7903a86-ecb5-4f1a-b9f5-cc9906999361</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.notif</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='modalProfilSudahLengkap']/div/div/div/div/div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>2c8c00f7-e5a3-41c0-bf53-873565f13720</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>notif</value>
      <webElementGuid>12885062-6d6f-4b81-ac6d-b7e6fbaf6626</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                                
                                    
                                    
                                        Data Anda akan segera Kami proses dan akan berubah setelah Kami verifikasi
                                    
                                
                            </value>
      <webElementGuid>45c6b963-570c-4e60-ab48-438d79e20e98</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;modalProfilSudahLengkap&quot;)/div[@class=&quot;modal-dialog modal-dialog-centered&quot;]/div[@class=&quot;modal-content&quot;]/div[@class=&quot;modal-body&quot;]/div[@class=&quot;text-center&quot;]/div[@class=&quot;notif&quot;]</value>
      <webElementGuid>4bf7613b-01fa-4c1f-956e-3f4d9415f467</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='modalProfilSudahLengkap']/div/div/div/div/div</value>
      <webElementGuid>f137c206-d951-40fc-b293-d763da5116fb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Perubahan Data Anda SudahKami Terima'])[1]/following::div[1]</value>
      <webElementGuid>46d8cb8f-2a17-40b0-b087-419b2d8a12be</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Ambil Foto'])[1]/following::div[6]</value>
      <webElementGuid>2c5ab4a0-de16-48c2-ac1e-7d00dd897707</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Kembali Ke Dashboard'])[1]/preceding::div[1]</value>
      <webElementGuid>0698e5f2-4e76-4ac7-be65-e42fad0608bf</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Potensi Resiko'])[1]/preceding::div[2]</value>
      <webElementGuid>5640aa17-a0a6-477e-89d2-73e70bcebfa2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Data Anda akan segera Kami proses dan akan berubah setelah Kami verifikasi']/parent::*</value>
      <webElementGuid>fe25e04a-b56b-4e4e-abd3-3a68c605753f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[7]/div/div/div/div/div</value>
      <webElementGuid>2fadb659-5807-4d2e-ba14-11424d99e358</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
                                
                                    
                                    
                                        Data Anda akan segera Kami proses dan akan berubah setelah Kami verifikasi
                                    
                                
                            ' or . = '
                                
                                    
                                    
                                        Data Anda akan segera Kami proses dan akan berubah setelah Kami verifikasi
                                    
                                
                            ')]</value>
      <webElementGuid>47f4024f-9456-4452-bbec-fc973423d277</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
