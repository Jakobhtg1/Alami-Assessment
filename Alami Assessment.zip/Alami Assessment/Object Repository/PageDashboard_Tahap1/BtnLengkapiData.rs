<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>BtnLengkapiData</name>
   <tag></tag>
   <elementGuidId>e6e23fef-7cd3-424d-853e-ee607e669399</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>a.btn.btn-primary.alm-alert-orenji</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='right-container-content']/section/div/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>73f5df9a-a11e-42ef-b20f-6e4dcac5d9de</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/funder/verificationform</value>
      <webElementGuid>f12cf7ac-60d0-461a-8520-0b28f6d6dae0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>btn btn-primary alm-alert-orenji</value>
      <webElementGuid>c318f4a6-70eb-4db2-a30f-aa9fe83d7c9a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                                    Lengkapi Data
                                </value>
      <webElementGuid>9408b895-6881-4618-a51d-8815348de9c9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;right-container-content&quot;)/section[@class=&quot;content&quot;]/div[@class=&quot;alert alert-alm alert-dismissible&quot;]/a[@class=&quot;btn btn-primary alm-alert-orenji&quot;]</value>
      <webElementGuid>ef54d87e-86c2-431d-9521-ae26945bdf59</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='right-container-content']/section/div/a</value>
      <webElementGuid>6fcd81ad-10d3-4d18-a204-aa09fbe031e8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Lengkapi Data')]</value>
      <webElementGuid>cad5d355-fa54-43e4-bd1d-f99d6f815bb3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Maaf, akun anda belum terverifikasi, silahkan lengkapi data anda.'])[1]/following::a[1]</value>
      <webElementGuid>ea64b467-d89a-4e9d-b174-a18485a29f1f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Beranda'])[1]/preceding::a[1]</value>
      <webElementGuid>9ece0b93-b51e-4b8f-af6c-7251c52922e1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='current step:'])[1]/preceding::a[1]</value>
      <webElementGuid>58601966-fa70-4d81-b4d8-585223d87f57</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Lengkapi Data']/parent::*</value>
      <webElementGuid>c71dadc4-506b-4598-855f-f190ddb6093e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/funder/verificationform')]</value>
      <webElementGuid>565f3ea6-4947-4a45-ae8a-cb46e38bc392</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//section/div/a</value>
      <webElementGuid>49b46a4a-51cf-42a7-aa7c-988e34cf5e0d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/funder/verificationform' and (text() = '
                                    Lengkapi Data
                                ' or . = '
                                    Lengkapi Data
                                ')]</value>
      <webElementGuid>23c34245-5575-4d0b-bd12-1f3faf90750a</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
