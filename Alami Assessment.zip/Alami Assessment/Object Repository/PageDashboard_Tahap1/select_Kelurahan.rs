<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>select_Kelurahan</name>
   <tag></tag>
   <elementGuidId>a81560b1-cac9-49bb-b198-8db0e7b2cd4a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//select[@id='regency']</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#regency</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>select</value>
      <webElementGuid>201bc2fa-360c-4480-8f16-ee6d662961a0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>name</name>
      <type>Main</type>
      <value>user.location.id</value>
      <webElementGuid>f45c15a0-e2a2-423a-9712-494c228ecda9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>form-control ms is-invalid</value>
      <webElementGuid>6fa096c8-eec2-49d9-b50c-490e60e8671a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>regency</value>
      <webElementGuid>4a2c67f1-334d-4ee6-a0b1-ba88a19942db</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-size</name>
      <type>Main</type>
      <value>5</value>
      <webElementGuid>f3a0a763-1bf3-442a-9730-06712685cdf8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>onchange</name>
      <type>Main</type>
      <value>regencyChange(this)</value>
      <webElementGuid>80ee1e2e-9e8d-413c-8827-8fa62d7f35c3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-required</name>
      <type>Main</type>
      <value>true</value>
      <webElementGuid>0f2c3285-fe00-49f6-a3e2-844268d5624a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tabindex</name>
      <type>Main</type>
      <value>-98</value>
      <webElementGuid>3b50de62-dede-4d51-bfa8-fb27cf930f7c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-invalid</name>
      <type>Main</type>
      <value>true</value>
      <webElementGuid>b706390d-ab32-4108-8cd9-a3e38f82972c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
																		Depok
Depok Jaya
Mampang
Pancoran Mas
Rangkapan Jaya Baru (Rangkapanjaya Baru)
Rangkapan Jaya (Rangkapanjaya)
</value>
      <webElementGuid>ff1b0892-19c8-4985-9feb-4c924dc25516</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;regency&quot;)</value>
      <webElementGuid>c7c8b1e2-4b94-4bd7-a7e8-81b3fef0231d</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//select[@id='regency']</value>
      <webElementGuid>c4502a3b-eae5-4d51-b344-67443595b247</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//fieldset[@id='dashboardForm-p-0']/div/div/div/div/div/div[3]/div[9]/div[2]/div/div/div/select</value>
      <webElementGuid>7bd162ec-8d81-4c42-98f6-43fedcca6979</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Kelurahan / Desa'])[1]/following::select[1]</value>
      <webElementGuid>e6598295-f1f3-4768-8f5d-fe044b6f6f17</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Tapos'])[2]/following::select[1]</value>
      <webElementGuid>d518c10d-4066-4ab9-8c8b-a9fec6c528c4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Tidak ada yang dipilih'])[2]/preceding::select[1]</value>
      <webElementGuid>68a53b46-2321-4014-95b2-29ab608aef3c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Depok'])[2]/preceding::select[1]</value>
      <webElementGuid>1bd6236e-4d84-46a7-930a-432e95b46d53</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/div[9]/div[2]/div/div/div/select</value>
      <webElementGuid>d64c231e-62ed-430b-9882-bfad0e3c0e0f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//select[@name = 'user.location.id' and @id = 'regency' and (text() = '
																		Depok
Depok Jaya
Mampang
Pancoran Mas
Rangkapan Jaya Baru (Rangkapanjaya Baru)
Rangkapan Jaya (Rangkapanjaya)
' or . = '
																		Depok
Depok Jaya
Mampang
Pancoran Mas
Rangkapan Jaya Baru (Rangkapanjaya Baru)
Rangkapan Jaya (Rangkapanjaya)
')]</value>
      <webElementGuid>6df6687e-7605-4909-aebf-55de45a1bf07</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
