<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>btn_Batal</name>
   <tag></tag>
   <elementGuidId>1e1d4dc4-d39b-4672-a0c7-f96b341ed6de</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@class = 'dtp-select-month-after']</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>a.dtp-select-month-after > i.material-icons</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='dtp_WEjKZ']/div/div/div/div/div[3]/a/i</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>dtp-btn-cancel btn btn-flat</value>
      <webElementGuid>2aacd31d-da4d-4c52-af52-c6d9b57b6eb0</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='dtp_WEjKZ']/div/div/div/div/div[3]/a/i</value>
      <webElementGuid>ee504ffb-1ded-4508-bc33-40c2c8acc930</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='SEP'])[1]/following::i[1]</value>
      <webElementGuid>0565d2e6-9c90-4f76-8bc5-e13fef507eef</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='chevron_left'])[1]/following::i[1]</value>
      <webElementGuid>653be5c8-f274-47c4-98d5-bea621eb1548</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='chevron_left'])[2]/preceding::i[1]</value>
      <webElementGuid>14706a5e-6b5f-424b-a10a-103105689918</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='chevron_right'])[2]/preceding::i[2]</value>
      <webElementGuid>c15c797b-97d6-4a04-98c0-f9b0358031ab</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='chevron_right']/parent::*</value>
      <webElementGuid>07c75235-11eb-40a6-9fb3-af4017cb7ec8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/a/i</value>
      <webElementGuid>d9e65dd3-25d8-4363-85de-783e1ce1667c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//i[(text() = 'chevron_right' or . = 'chevron_right')]</value>
      <webElementGuid>4ed982d4-1431-433f-b67b-ed40fb42c1fc</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
