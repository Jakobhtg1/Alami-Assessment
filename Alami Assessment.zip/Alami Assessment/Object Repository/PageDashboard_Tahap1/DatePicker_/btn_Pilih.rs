<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>btn_Pilih</name>
   <tag></tag>
   <elementGuidId>9785f0e8-3c34-40f7-9c3a-081e1f7565bc</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@class = 'dtp-btn-ok btn btn-flat']</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>a.dtp-select-month-after > i.material-icons</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='dtp_WEjKZ']/div/div/div/div/div[3]/a/i</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>dtp-btn-ok btn btn-flat</value>
      <webElementGuid>15011c2d-436f-4380-beda-9c776cb9296e</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='dtp_WEjKZ']/div/div/div/div/div[3]/a/i</value>
      <webElementGuid>1093d457-b9ce-4d24-a7fd-6a96002969b4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='SEP'])[1]/following::i[1]</value>
      <webElementGuid>75aa7dcc-9b93-452a-9174-94f7264570d5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='chevron_left'])[1]/following::i[1]</value>
      <webElementGuid>94ccec49-7d8c-43b4-8d74-803b9cc307e2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='chevron_left'])[2]/preceding::i[1]</value>
      <webElementGuid>d0c9bc67-b434-4ecc-98bf-95d59edcb8fe</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='chevron_right'])[2]/preceding::i[2]</value>
      <webElementGuid>c1fe922b-74ea-4b8b-8936-d2fc8a5ff9cc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='chevron_right']/parent::*</value>
      <webElementGuid>725bbddf-e4ce-46e8-8470-9efb646ab92a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/a/i</value>
      <webElementGuid>89f91af1-3e41-4def-982b-440668dd8087</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//i[(text() = 'chevron_right' or . = 'chevron_right')]</value>
      <webElementGuid>9846b9ce-fb9b-4604-98c5-f1f23325d2ec</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
