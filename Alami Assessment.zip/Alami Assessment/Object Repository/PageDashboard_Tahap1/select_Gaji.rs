<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>select_Gaji</name>
   <tag></tag>
   <elementGuidId>9d27d3fa-73c3-4882-afca-f17736f0e3b3</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//select[@id='monthlyIncome']</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#monthlyIncome</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>select</value>
      <webElementGuid>66c25c98-b7da-4c5b-9602-77e2cf75d04d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>name</name>
      <type>Main</type>
      <value>user.rdlMonthlyIncome.id</value>
      <webElementGuid>5fbfbeda-cc18-47dd-89c6-ece6b57fc262</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>form-control ms</value>
      <webElementGuid>b3f71be8-ddb5-4dd0-ad0e-0b7326bd77c4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>monthlyIncome</value>
      <webElementGuid>be28e49a-94f2-4ac8-b3a7-7f3dc59ab73c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-size</name>
      <type>Main</type>
      <value>5</value>
      <webElementGuid>9d58ff87-2fcd-46a5-a51d-b7b60689e8ab</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tabindex</name>
      <type>Main</type>
      <value>-98</value>
      <webElementGuid>e67bfd77-ae3e-4665-b657-6f235ecdbda3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-required</name>
      <type>Main</type>
      <value>true</value>
      <webElementGuid>9c7048de-fa4c-4c2f-8407-89bdab52432e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
							                                            &lt; 3 juta rupiah
3 - 5 juta rupiah
5 - 10 juta rupiah
10 - 20 juta rupiah
20 - 50 juta rupiah
50 - 100 juta rupiah
100 - 500 juta rupiah
> 500 juta rupiah
</value>
      <webElementGuid>84fdf50f-69f9-444c-b29e-93154750e71b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;dashboardForm-p-0&quot;)/div[@class=&quot;row no-gutters py-2 mt-3&quot;]/div[@class=&quot;col-lg-12&quot;]/div[@class=&quot;body body-verifikasi&quot;]/div[@class=&quot;row no-gutters bg-delta p-3 p-lg-4 text-alfa&quot;]/div[@class=&quot;col&quot;]/div[@class=&quot;form-row double-column&quot;]/div[@class=&quot;col-md-6&quot;]/div[2]/div[@class=&quot;form-group&quot;]/div[@class=&quot;form-line&quot;]/div[@class=&quot;dropdown bootstrap-select form-control ms dropup show&quot;]/select[@id=&quot;monthlyIncome&quot;]</value>
      <webElementGuid>c14d0860-30dd-429f-a769-12afbeb50170</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//select[@id='monthlyIncome']</value>
      <webElementGuid>0c8c9235-3afe-40af-bc53-56a98a528c80</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//fieldset[@id='dashboardForm-p-0']/div/div/div/div/div/div[4]/div[4]/div[2]/div/div/div/select</value>
      <webElementGuid>28710eb2-f09e-4947-84d9-e84258b9e70a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Penghasilan Bulanan'])[1]/following::select[1]</value>
      <webElementGuid>b3d09680-3647-4684-b3c2-56c0e5ff8b9a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Lainnya'])[3]/following::select[1]</value>
      <webElementGuid>ca5c618c-649f-4f1f-a86f-38cd5711373d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Tidak ada yang dipilih'])[3]/preceding::select[1]</value>
      <webElementGuid>3b6d3797-c908-43d4-a4cc-bb1ebe2bb8d6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='&lt; 3 juta rupiah'])[2]/preceding::select[1]</value>
      <webElementGuid>85a9a0b2-6a73-4ae8-b615-b7c8eda818a9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[4]/div[2]/div/div/div/select</value>
      <webElementGuid>eec4c0f6-badd-47b5-b939-9cb447903090</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//select[@name = 'user.rdlMonthlyIncome.id' and @id = 'monthlyIncome' and (text() = '
							                                            &lt; 3 juta rupiah
3 - 5 juta rupiah
5 - 10 juta rupiah
10 - 20 juta rupiah
20 - 50 juta rupiah
50 - 100 juta rupiah
100 - 500 juta rupiah
> 500 juta rupiah
' or . = '
							                                            &lt; 3 juta rupiah
3 - 5 juta rupiah
5 - 10 juta rupiah
10 - 20 juta rupiah
20 - 50 juta rupiah
50 - 100 juta rupiah
100 - 500 juta rupiah
> 500 juta rupiah
')]</value>
      <webElementGuid>ef17a8a4-5c90-4e12-9617-9ff04e422a29</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
