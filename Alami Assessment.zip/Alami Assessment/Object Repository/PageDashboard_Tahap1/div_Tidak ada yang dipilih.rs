<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Tidak ada yang dipilih</name>
   <tag></tag>
   <elementGuidId>dde435a2-3baa-4a3d-8395-dc34c403aa27</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.dropdown.bootstrap-select.show-tick.form-control.ms > button.btn.dropdown-toggle.bs-placeholder.btn-light > div.filter-option > div.filter-option-inner > div.filter-option-inner-inner</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//fieldset[@id='dashboardForm-p-2']/div/div/div/div/div/div[2]/div/div[2]/div/div/div/button/div/div/div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>a309f27c-1f56-4b4f-ba55-dc537e033935</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>filter-option-inner-inner</value>
      <webElementGuid>855dd9ff-b34c-4690-9aa3-1c64526c662a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Tidak ada yang dipilih</value>
      <webElementGuid>428f3abe-6750-45e6-a318-05ad09b80d1e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;dashboardForm-p-2&quot;)/div[@class=&quot;row no-gutters py-2 mt-3&quot;]/div[@class=&quot;col-lg-12&quot;]/div[@class=&quot;body&quot;]/div[@class=&quot;row no-gutters bg-delta p-3 p-lg-4 text-alfa&quot;]/div[@class=&quot;col&quot;]/div[@class=&quot;form-row double-column&quot;]/div[@class=&quot;col-md-6&quot;]/div[2]/div[@class=&quot;form-group&quot;]/div[@class=&quot;form-line&quot;]/div[@class=&quot;dropdown bootstrap-select show-tick form-control ms&quot;]/button[@class=&quot;btn dropdown-toggle bs-placeholder btn-light&quot;]/div[@class=&quot;filter-option&quot;]/div[@class=&quot;filter-option-inner&quot;]/div[@class=&quot;filter-option-inner-inner&quot;]</value>
      <webElementGuid>adb3ba27-c4df-48a1-b86c-e7b642748eae</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//fieldset[@id='dashboardForm-p-2']/div/div/div/div/div/div[2]/div/div[2]/div/div/div/button/div/div/div</value>
      <webElementGuid>5dc5a64a-76f2-4043-8502-2e118edd4a72</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Nama Bank'])[1]/following::div[7]</value>
      <webElementGuid>b33362f6-8735-4d38-9488-1a0062fe7431</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Informasi Rekening Bank'])[1]/following::div[10]</value>
      <webElementGuid>db9c5616-14b5-473c-be73-2eb5718923cd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='ALTOPAY'])[2]/preceding::div[2]</value>
      <webElementGuid>4cce49e9-d20b-4f55-a8cf-139e5cd159a0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='AMAR INDONESIA'])[2]/preceding::div[2]</value>
      <webElementGuid>df7ef6bf-7a89-4a90-ac49-d73cbe036dcd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//fieldset[3]/div/div/div/div/div/div[2]/div/div[2]/div/div/div/button/div/div/div</value>
      <webElementGuid>6191378d-a680-4de8-9adf-584eaa2d1931</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'Tidak ada yang dipilih' or . = 'Tidak ada yang dipilih')]</value>
      <webElementGuid>b4f23d1b-c43c-402e-bd78-acbe161aff11</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
