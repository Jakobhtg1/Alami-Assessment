<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>select_Individual - WNI (Mewakili Diri Send_a6f99a</name>
   <tag></tag>
   <elementGuidId>0cefd6af-036e-45c9-9c4f-5da28eef2885</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//select[@id='tipeAkun']</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#tipeAkun</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>select</value>
      <webElementGuid>e0fd14fc-20f4-4bee-9e1c-dd9bc21d9770</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>name</name>
      <type>Main</type>
      <value>tipeAkun</value>
      <webElementGuid>dd1c4b97-5493-4e76-8266-bc27e86b00de</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>form-control ms is-invalid</value>
      <webElementGuid>fc1c29b0-70d4-4030-bf51-9fb859f27f5a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>tipeAkun</value>
      <webElementGuid>5c227a01-c112-4e1a-825e-f66f6733e564</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>onchange</name>
      <type>Main</type>
      <value>tipeAkunChange(this)</value>
      <webElementGuid>1857b5ea-8d9f-4ead-8015-45d46272412c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tabindex</name>
      <type>Main</type>
      <value>-98</value>
      <webElementGuid>cdfb9641-8914-4c8a-990f-3db5bc118ef3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-required</name>
      <type>Main</type>
      <value>true</value>
      <webElementGuid>d726025e-8308-4673-857b-fbf2bd27ab25</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                                                                            
                                                                                Individual - WNI (Mewakili Diri Sendiri)
                                                                            
                                                                                Individual - WNA (Mewakili Diri Sendiri)
                                                                            
                                                                                Badan Hukum - WNI (Mewakili Suatu Badan Hukum)
                                                                            
                                                                        </value>
      <webElementGuid>b32cb92a-0ea9-4272-836a-50a22ae37bb4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;tipeAkun&quot;)</value>
      <webElementGuid>3ebb4ed3-7023-46fb-9674-149f14e2e18f</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//select[@id='tipeAkun']</value>
      <webElementGuid>7b990fe6-4be6-4391-a8e5-64c94aef376f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//fieldset[@id='dashboardForm-p-0']/div/div/div/div/div/div/div[2]/div[2]/div/div/div/select</value>
      <webElementGuid>12dd93f7-ba48-4f2a-a9d1-5ddbc4a418f5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Tipe Akun'])[1]/following::select[1]</value>
      <webElementGuid>46d20c34-7bda-405e-8560-90e10976abb8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Tipe Akun Pemberi Dana'])[1]/following::select[1]</value>
      <webElementGuid>b5bd09ac-8764-47f2-9b79-d7ea729ba29e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Tidak ada yang dipilih'])[1]/preceding::select[1]</value>
      <webElementGuid>0470d98e-6070-4d32-8929-0ef27497f1c5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Individual - WNI (Mewakili Diri Sendiri)'])[2]/preceding::select[1]</value>
      <webElementGuid>bc695da6-966d-4eea-965a-08fa45eb4b40</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//select</value>
      <webElementGuid>2321d9ad-0408-470e-9198-bc5d8fe920f4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//select[@name = 'tipeAkun' and @id = 'tipeAkun' and (text() = '
                                                                            
                                                                                Individual - WNI (Mewakili Diri Sendiri)
                                                                            
                                                                                Individual - WNA (Mewakili Diri Sendiri)
                                                                            
                                                                                Badan Hukum - WNI (Mewakili Suatu Badan Hukum)
                                                                            
                                                                        ' or . = '
                                                                            
                                                                                Individual - WNI (Mewakili Diri Sendiri)
                                                                            
                                                                                Individual - WNA (Mewakili Diri Sendiri)
                                                                            
                                                                                Badan Hukum - WNI (Mewakili Suatu Badan Hukum)
                                                                            
                                                                        ')]</value>
      <webElementGuid>41c2359d-b47c-4dbd-a392-ced109614eaa</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
