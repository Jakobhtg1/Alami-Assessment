<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>label_e-KTP berlaku seumur hidup</name>
   <tag></tag>
   <elementGuidId>582325e0-1053-4b88-85fe-84d01b4f24eb</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//fieldset[@id='dashboardForm-p-1']/div/div/div/div/div/div[2]/div/div[2]/div[3]/div/label</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>label</value>
      <webElementGuid>ffeb50db-ca25-4a45-977a-c37fabd011f3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>custom-control-label</value>
      <webElementGuid>48c2a3a6-3503-4d43-a5a2-bf66fde3ce3a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>for</name>
      <type>Main</type>
      <value>ktpSeumurHidup</value>
      <webElementGuid>400b69ea-ad5d-49cb-a964-ce9442664f01</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                                                                            e-KTP berlaku seumur hidup
                                                                        </value>
      <webElementGuid>9215c355-daca-453d-939b-182082ed3fe5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;dashboardForm-p-1&quot;)/div[@class=&quot;row no-gutters py-2 mt-3&quot;]/div[@class=&quot;col-lg-12&quot;]/div[@class=&quot;body body-document&quot;]/div[@class=&quot;row no-gutters bg-delta p-3 p-lg-4 text-alfa&quot;]/div[@class=&quot;col&quot;]/div[@class=&quot;form-row double-column&quot;]/div[@class=&quot;col-md-6&quot;]/div[2]/div[3]/div[@class=&quot;custom-control custom-checkbox&quot;]/label[@class=&quot;custom-control-label&quot;]</value>
      <webElementGuid>fd0b6743-9cdb-4c88-ab3a-8198647b7146</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//fieldset[@id='dashboardForm-p-1']/div/div/div/div/div/div[2]/div/div[2]/div[3]/div/label</value>
      <webElementGuid>397e1254-ce7b-4974-89c9-abc0a7710c41</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='KTP Berlaku Hingga'])[1]/following::label[1]</value>
      <webElementGuid>2e4cf465-8fd0-492d-9282-aace8a99bc5b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Nomor e-KTP'])[1]/following::label[2]</value>
      <webElementGuid>1108b994-de89-47dc-b589-73734fb67ae0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Kota Penerbit e-KTP'])[1]/preceding::label[1]</value>
      <webElementGuid>36f26c26-404d-4b11-9cf8-d0b4f762ba56</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Tidak ada yang dipilih'])[11]/preceding::label[2]</value>
      <webElementGuid>22bc5b07-ff0c-41bc-8055-d15baf35b666</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='e-KTP berlaku seumur hidup']/parent::*</value>
      <webElementGuid>d405641b-0401-4f97-9a93-daf7d2cd2715</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/div[2]/div[3]/div/label</value>
      <webElementGuid>caf0276c-b43e-44ee-94e4-343e00fbd710</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//label[(text() = '
                                                                            e-KTP berlaku seumur hidup
                                                                        ' or . = '
                                                                            e-KTP berlaku seumur hidup
                                                                        ')]</value>
      <webElementGuid>8ad0e459-ab22-4b2f-b56e-42c666065526</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
