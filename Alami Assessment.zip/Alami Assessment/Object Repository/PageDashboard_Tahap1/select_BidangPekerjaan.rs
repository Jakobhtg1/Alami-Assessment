<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>select_BidangPekerjaan</name>
   <tag></tag>
   <elementGuidId>b9adb876-10ab-4789-bc02-847fa0cf953e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//select[@id='industryPekerjaan']</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#industryPekerjaan</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>select</value>
      <webElementGuid>67d92cf0-10b6-4a1a-9aee-3a151b133266</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>name</name>
      <type>Main</type>
      <value>user.industryPekerjaan.id</value>
      <webElementGuid>98ba871a-7d02-4e60-b5dd-ab3a9feb1134</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>form-control ms</value>
      <webElementGuid>165750ea-0006-494f-91ee-e288030023e1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>industryPekerjaan</value>
      <webElementGuid>527b954e-10df-4a81-bfc0-320d5a15cedd</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-live-search</name>
      <type>Main</type>
      <value>true</value>
      <webElementGuid>a9457ae2-2140-4dc1-aa37-9a61e3e26eff</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-size</name>
      <type>Main</type>
      <value>5</value>
      <webElementGuid>60172f8b-18b1-4ccb-b49d-56529b34fd55</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>onchange</name>
      <type>Main</type>
      <value>industryPekerjaanChange(this)</value>
      <webElementGuid>8aa7baee-8cd6-44d8-97ed-b4fc25552bdb</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tabindex</name>
      <type>Main</type>
      <value>-98</value>
      <webElementGuid>a3a88818-8fa2-4830-a394-055f5ad12a0a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
							                                            Administrasi Pemerintahan, Pertahanan, dan Jaminan Sosial Wajib
Aktivitas Badan Internasional dan Badan Ekstra
Aktivitas Jasa lainnya
Aktivitas Kesehatan Manusia dan Aktivitas Sosial
Aktivitas Keuangan dan Asuransi
Aktivitas penyewaan dan sewa guna usaha tanpa hak opsi, ketenagakerjaan, agen perjalanan dan penunjang usaha lainnya
Aktivitas Profesional, Ilmiah dan Teknis
Aktivitas Yang Menghasilkan Barang dan Jasa Oleh Rumah Tangga Yang Digunakan Untuk Memenuhi Kebutuhan Sendiri
Industri Pengolahan
Informasi dan Komunikasi
Kesenian, Hiburan dan Rekreasi
Konstruksi
Pendidikan
Pengadaan Listrik Gas, Uap/Air Panas dan Udara Dingin 
Pengangkutan dan Pergudangan
Penyediaan Akomodasi dan Penyediaan Makan Minum
Perdagangan Besar dan Eceran; Reparasi dan Perawatan Mobil dan Sepeda Motor
Pertambangan dan Penggalian
Pertanian, Kehutanan dan Perikanan
Real Estate
Treatment Air, Treatment Air Limbah, Treatment dan Pemulihan Material Sampah, dan Aktivitas Remediasi
Lainnya
</value>
      <webElementGuid>3366571d-41e5-4c20-9b80-bf9e0d48c087</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;industryPekerjaan&quot;)</value>
      <webElementGuid>a01434ba-2a94-4d45-a9f1-04160ce0dbd9</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//select[@id='industryPekerjaan']</value>
      <webElementGuid>80eb92fe-8c18-48f9-90c4-ab3bc66ab142</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//fieldset[@id='dashboardForm-p-0']/div/div/div/div/div/div[4]/div[3]/div[2]/div/div/div/select</value>
      <webElementGuid>0a993edb-fc5d-4bed-8de3-c3eb311f84fd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Bidang Pekerjaan'])[1]/following::select[1]</value>
      <webElementGuid>6c0da50a-6a18-405a-a072-3680dc9cbd3e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Lain-lain'])[2]/following::select[1]</value>
      <webElementGuid>1318cdc6-95c8-486b-bd3c-ee018d31b4f7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Tidak ada yang dipilih'])[2]/preceding::select[1]</value>
      <webElementGuid>761e35cb-7b37-46ae-b9f3-399b599ea244</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Administrasi Pemerintahan, Pertahanan, dan Jaminan Sosial Wajib'])[2]/preceding::select[1]</value>
      <webElementGuid>d8b994ab-59ee-4039-8568-828a945222e7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/div[2]/div/div/div/select</value>
      <webElementGuid>1bde78da-b1b2-4695-9381-c77d1afee9bf</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//select[@name = 'user.industryPekerjaan.id' and @id = 'industryPekerjaan' and (text() = '
							                                            Administrasi Pemerintahan, Pertahanan, dan Jaminan Sosial Wajib
Aktivitas Badan Internasional dan Badan Ekstra
Aktivitas Jasa lainnya
Aktivitas Kesehatan Manusia dan Aktivitas Sosial
Aktivitas Keuangan dan Asuransi
Aktivitas penyewaan dan sewa guna usaha tanpa hak opsi, ketenagakerjaan, agen perjalanan dan penunjang usaha lainnya
Aktivitas Profesional, Ilmiah dan Teknis
Aktivitas Yang Menghasilkan Barang dan Jasa Oleh Rumah Tangga Yang Digunakan Untuk Memenuhi Kebutuhan Sendiri
Industri Pengolahan
Informasi dan Komunikasi
Kesenian, Hiburan dan Rekreasi
Konstruksi
Pendidikan
Pengadaan Listrik Gas, Uap/Air Panas dan Udara Dingin 
Pengangkutan dan Pergudangan
Penyediaan Akomodasi dan Penyediaan Makan Minum
Perdagangan Besar dan Eceran; Reparasi dan Perawatan Mobil dan Sepeda Motor
Pertambangan dan Penggalian
Pertanian, Kehutanan dan Perikanan
Real Estate
Treatment Air, Treatment Air Limbah, Treatment dan Pemulihan Material Sampah, dan Aktivitas Remediasi
Lainnya
' or . = '
							                                            Administrasi Pemerintahan, Pertahanan, dan Jaminan Sosial Wajib
Aktivitas Badan Internasional dan Badan Ekstra
Aktivitas Jasa lainnya
Aktivitas Kesehatan Manusia dan Aktivitas Sosial
Aktivitas Keuangan dan Asuransi
Aktivitas penyewaan dan sewa guna usaha tanpa hak opsi, ketenagakerjaan, agen perjalanan dan penunjang usaha lainnya
Aktivitas Profesional, Ilmiah dan Teknis
Aktivitas Yang Menghasilkan Barang dan Jasa Oleh Rumah Tangga Yang Digunakan Untuk Memenuhi Kebutuhan Sendiri
Industri Pengolahan
Informasi dan Komunikasi
Kesenian, Hiburan dan Rekreasi
Konstruksi
Pendidikan
Pengadaan Listrik Gas, Uap/Air Panas dan Udara Dingin 
Pengangkutan dan Pergudangan
Penyediaan Akomodasi dan Penyediaan Makan Minum
Perdagangan Besar dan Eceran; Reparasi dan Perawatan Mobil dan Sepeda Motor
Pertambangan dan Penggalian
Pertanian, Kehutanan dan Perikanan
Real Estate
Treatment Air, Treatment Air Limbah, Treatment dan Pemulihan Material Sampah, dan Aktivitas Remediasi
Lainnya
')]</value>
      <webElementGuid>79fcff9e-d301-4705-a67b-b01b6471536f</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
