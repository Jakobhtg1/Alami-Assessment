<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>BtnMasuk</name>
   <tag></tag>
   <elementGuidId>31d6a417-56ba-4fe4-a00b-dad78e590117</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>a.btn.btn-full-primary.w-100</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//a[contains(text(),'Masuk ke Akun Saya')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>493e34e3-784c-4000-b713-e07632bd78e9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/login</value>
      <webElementGuid>aec24e1a-b0f8-4368-bbf1-be490fee0458</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>btn btn-full-primary w-100</value>
      <webElementGuid>85ac7440-2dfe-47bc-8626-2443302b731f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Masuk ke Akun Saya</value>
      <webElementGuid>6a142c15-52a5-4cbc-b3d8-18fd581d1214</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/div[@class=&quot;page register funder position-relative&quot;]/main[@class=&quot;register success&quot;]/div[@class=&quot;container text-center&quot;]/div[@class=&quot;box&quot;]/div[@class=&quot;main&quot;]/section[@class=&quot;one&quot;]/a[@class=&quot;btn btn-full-primary w-100&quot;]</value>
      <webElementGuid>9a7cffe0-22eb-4c47-a1bf-d12c807e15b5</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Masuk ke Akun Saya')]</value>
      <webElementGuid>d3ae0eab-3283-4325-bdee-8900765ec2df</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Alhamdulillah!'])[1]/following::a[1]</value>
      <webElementGuid>7d192fc0-3e85-451c-a115-0ded92804fd8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Registrasi Pemberi Dana'])[1]/following::a[1]</value>
      <webElementGuid>e3fe57e4-626b-4933-af4a-add91be17c6b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='masuk'])[1]/preceding::a[1]</value>
      <webElementGuid>a1464120-5ddd-4386-a3b5-40f2a3962d3c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Capture object:'])[1]/preceding::a[2]</value>
      <webElementGuid>a69f3564-ec2b-46dd-bbfc-66c474c111b9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Masuk ke Akun Saya']/parent::*</value>
      <webElementGuid>f76b4d13-9be4-42fa-ad79-26ffd6b03ef8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/login')]</value>
      <webElementGuid>5dd41d4a-0e9a-41bd-afe6-4be652c0facb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//section/a</value>
      <webElementGuid>73cee0bd-eda2-4de8-940b-5d1a4b25d408</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/login' and (text() = 'Masuk ke Akun Saya' or . = 'Masuk ke Akun Saya')]</value>
      <webElementGuid>d51f58e8-15f1-4fb8-89a7-576fbc20d02c</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
