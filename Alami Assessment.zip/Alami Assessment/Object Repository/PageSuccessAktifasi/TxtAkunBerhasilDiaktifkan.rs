<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>TxtAkunBerhasilDiaktifkan</name>
   <tag></tag>
   <elementGuidId>b836567e-85c3-421e-8f72-b178fc42526d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>p</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Alhamdulillah!'])[1]/following::p[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>p</value>
      <webElementGuid>bf1c6670-a6a2-4e0e-a4b9-3daa8ebc33a5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Akun Kamu sudah berhasil diaktifkan sebagai Pemberi Dana. Silahkan klik link login dibawah ini untuk masuk.</value>
      <webElementGuid>135afd71-e2a5-435f-9cfe-64aab150c9f5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/div[@class=&quot;page register funder position-relative&quot;]/main[@class=&quot;register success&quot;]/div[@class=&quot;container text-center&quot;]/div[@class=&quot;box&quot;]/div[@class=&quot;main&quot;]/section[@class=&quot;one&quot;]/p[1]</value>
      <webElementGuid>86abc284-3ca8-46fb-a701-7886891ac9a3</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Alhamdulillah!'])[1]/following::p[1]</value>
      <webElementGuid>1efc5494-c25e-42b7-95db-c3777d087f49</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Registrasi Pemberi Dana'])[1]/following::p[1]</value>
      <webElementGuid>38d896a2-61d6-4ee3-a902-5fe9172f4883</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Masuk ke Akun Saya'])[1]/preceding::p[1]</value>
      <webElementGuid>8c67a33e-dd10-4d74-af89-3e4b8fa56f63</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='masuk'])[1]/preceding::p[2]</value>
      <webElementGuid>80dc2e41-26dd-4f1e-9b71-25938b192987</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Akun Kamu sudah berhasil diaktifkan sebagai Pemberi Dana. Silahkan klik link login dibawah ini untuk masuk.']/parent::*</value>
      <webElementGuid>c6d385db-6a34-4b19-b0fa-c203b4ddd4c3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//p</value>
      <webElementGuid>61e2fd04-3d63-4484-9612-41d8cfc71f8c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//p[(text() = 'Akun Kamu sudah berhasil diaktifkan sebagai Pemberi Dana. Silahkan klik link login dibawah ini untuk masuk.' or . = 'Akun Kamu sudah berhasil diaktifkan sebagai Pemberi Dana. Silahkan klik link login dibawah ini untuk masuk.')]</value>
      <webElementGuid>09340866-fdf1-45eb-8ac6-632412f9e5ef</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
