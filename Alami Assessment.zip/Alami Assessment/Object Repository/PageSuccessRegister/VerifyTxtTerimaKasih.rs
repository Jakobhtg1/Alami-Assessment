<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>VerifyTxtTerimaKasih</name>
   <tag></tag>
   <elementGuidId>b3bd3be9-9f87-4cfd-ae0c-1b33a5fa14af</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>section.one > h3</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Registrasi Pemberi Dana'])[1]/following::h3[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h3</value>
      <webElementGuid>3a56271d-90cd-4df4-a165-2ba32820ef65</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Terima Kasih!</value>
      <webElementGuid>42b8ebe0-7930-4288-b67d-5184176622bd</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/div[@class=&quot;page register funder position-relative&quot;]/main[@class=&quot;register success&quot;]/div[@class=&quot;container text-center&quot;]/div[@class=&quot;box&quot;]/div[@class=&quot;main&quot;]/section[@class=&quot;one&quot;]/h3[1]</value>
      <webElementGuid>0692bbd6-1840-4099-b504-8c6bf3fd46d7</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Registrasi Pemberi Dana'])[1]/following::h3[1]</value>
      <webElementGuid>a92d662e-dff0-4826-ace8-0cfb1fb47183</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Kirim Ulang Aktivasi Email'])[1]/preceding::h3[1]</value>
      <webElementGuid>3bca6a88-f54c-4e85-b38b-805a7f32e1fc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='masuk'])[1]/preceding::h3[1]</value>
      <webElementGuid>6bed58c9-2c6c-470d-8d8f-029179bb3a3c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Terima Kasih!']/parent::*</value>
      <webElementGuid>754caf20-9833-4a77-b7d0-a0bea174316e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//section/h3</value>
      <webElementGuid>6f55b347-75d3-4d66-b9d4-1eb636b96784</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h3[(text() = 'Terima Kasih!' or . = 'Terima Kasih!')]</value>
      <webElementGuid>c51ac5f5-e488-4688-a962-f6d8e7e063be</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
