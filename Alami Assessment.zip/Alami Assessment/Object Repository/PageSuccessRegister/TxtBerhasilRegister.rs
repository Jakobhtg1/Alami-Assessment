<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>TxtBerhasilRegister</name>
   <tag></tag>
   <elementGuidId>18d831b0-dee0-460e-823f-6d5448655f16</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>p</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Terima Kasih!'])[1]/following::p[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>p</value>
      <webElementGuid>eae5aeb5-27a0-47a7-aa3b-e19d8e5d5aa8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Kamu sudah berhasil mendaftar sebagai Pemberi Dana. Silahkan klik link aktivasi yang dikirimkan ke email Kamu.</value>
      <webElementGuid>773ca394-a033-44a7-a097-53a257194f67</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/div[@class=&quot;page register funder position-relative&quot;]/main[@class=&quot;register success&quot;]/div[@class=&quot;container text-center&quot;]/div[@class=&quot;box&quot;]/div[@class=&quot;main&quot;]/section[@class=&quot;one&quot;]/p[1]</value>
      <webElementGuid>a71d5516-4a84-4e26-b976-289449fcb34a</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Terima Kasih!'])[1]/following::p[1]</value>
      <webElementGuid>c564238b-dae7-4065-94ea-14f700e8655a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Registrasi Pemberi Dana'])[1]/following::p[1]</value>
      <webElementGuid>5f33bf85-94e2-4643-99ab-c8aa120932ea</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Kirim Ulang Aktivasi Email'])[1]/preceding::p[2]</value>
      <webElementGuid>5a030407-9e41-4f72-90d4-a8c0022c8b14</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='masuk'])[1]/preceding::p[3]</value>
      <webElementGuid>5f61ffec-98bd-4ed6-ab08-da15818e982e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Kamu sudah berhasil mendaftar sebagai Pemberi Dana. Silahkan klik link aktivasi yang dikirimkan ke email Kamu.']/parent::*</value>
      <webElementGuid>467e76b3-3b8f-4b38-b3f3-7e5c5aab6332</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//p</value>
      <webElementGuid>73609fad-b33d-4f56-94a0-247f4e240f77</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//p[(text() = 'Kamu sudah berhasil mendaftar sebagai Pemberi Dana. Silahkan klik link aktivasi yang dikirimkan ke email Kamu.' or . = 'Kamu sudah berhasil mendaftar sebagai Pemberi Dana. Silahkan klik link aktivasi yang dikirimkan ke email Kamu.')]</value>
      <webElementGuid>b3a92647-0291-440e-bf71-8dff9a800ed9</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
