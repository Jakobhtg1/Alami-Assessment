import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import alamiassessment.RandomData as RandomData
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

'Open Lending Page'

WebUI.openBrowser('')

WebUI.navigateToUrl(GlobalVariable.URL)

WebUI.waitForElementVisible(findTestObject('PageLending/ImgAlami'), GlobalVariable.timeout)

WebUI.waitForElementPresent(findTestObject('PageLending/VerifyTextHijarahFinasial'), GlobalVariable.timeout)

WebUI.waitForElementPresent(findTestObject('PageLending/VerifyTextMembangunIndustriKeuanganSyariah'), GlobalVariable.timeout)


'Register as Pemberi Dana'

WebUI.click(findTestObject('PageLending/LinKDaftarDiSini'))

WebUI.waitForElementPresent(findTestObject('PagePilihanPemberiDanPenerimaDana/VerifyTxtCaraSyariahYangAman'), GlobalVariable.timeout)

WebUI.click(findTestObject('PagePilihanPemberiDanPenerimaDana/BtnPemberiDana'))

WebUI.verifyElementPresent(findTestObject('PageRegister/VerifyTxtRegistrasiPemberiDana'), 10)


'Input Register Form'

GlobalVariable.NamaLengkap = RandomData.generateRandomFullName()

NoHp = RandomData.randomDoubleFunc(8)

GlobalVariable.NoHP = ('0813' + NoHp)

Email = RandomData.randomDoubleFunc(4)

GlobalVariable.Email = (('alami' + Email) + '@yopmail.com')

WebUI.setText(findTestObject('PageRegister/TxtNama'), GlobalVariable.NamaLengkap)

WebUI.setText(findTestObject('PageRegister/TxtEmail'), GlobalVariable.Email)

WebUI.setText(findTestObject('PageRegister/TxtNoPhone'), GlobalVariable.NoHP)

WebUI.setText(findTestObject('PageRegister/TxtPassword'), GlobalVariable.Password)

WebUI.click(findTestObject('PageRegister/RbIndividual'))

WebUI.setText(findTestObject('PageRegister/TxtKodeReferral'), '123456')

WebUI.click(findTestObject('PageRegister/ListReferral'))

WebUI.scrollToElement(findTestObject('PageRegister/ListReferral'), 3)

WebUI.click(findTestObject('PageRegister/BtnLanjutkan'))



