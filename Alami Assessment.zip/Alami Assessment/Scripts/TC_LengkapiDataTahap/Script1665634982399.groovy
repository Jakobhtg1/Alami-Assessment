import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import alamiassessment.RandomData as RandomData
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys
import java.awt.Robot as Robot
import java.awt.Toolkit as Toolkit
import java.awt.datatransfer.StringSelection as StringSelection
import java.awt.event.KeyEvent as KeyEvent
import com.kms.katalon.core.webui.common.WebUiCommonHelper as WebUiCommonHelper
import org.openqa.selenium.WebElement as WebElement
import javax.script.*

String NamaIbuKandung = ('Ibu' + ' ') + GlobalVariable.NamaLengkap

String KontakDarurat = ('Saudara' + ' ') + GlobalVariable.NamaLengkap

String NoKontakDarurat = '0817' + RandomData.randomDoubleFunc(8)

//WebUI.click(findTestObject('record1/button_Lengkapi Profil Sekarang'))
'Form Tahap 1'

WebUI.selectOptionByValue(findTestObject('PageDashboard_Tahap1/select_TipeAkun'), '1', true)

WebUI.click(findTestObject('PageDashboard_Tahap1/Btn_NamaLengkap'))

WebUI.click(findTestObject('PageDashboard_Tahap1/ListBapak'))

WebUI.executeJavaScript('document.getElementsByClassName(\'form-control\')[11].removeAttribute(\'readonly\');', null)

WebUI.click(findTestObject('record1/label_Laki-laki'))

'Input Tanggal Lahir'

WebUI.click(findTestObject('PageDashboard_Tahap1/datepicker1'), FailureHandling.STOP_ON_FAILURE)

WebUI.click(findTestObject('PageDashboard_Tahap1/DatePicker_/btn_prevMonth'))

WebUI.click(findTestObject('PageDashboard_Tahap1/DatePicker_/btn_prevMonth'))

WebUI.click(findTestObject('PageDashboard_Tahap1/DatePicker_/btn_YearBefore'))

WebUI.click(findTestObject('PageDashboard_Tahap1/DatePicker_/btn_YearBefore'))

WebUI.click(findTestObject('PageDashboard_Tahap1/DatePicker_/Day'))

WebUI.click(findTestObject('PageDashboard_Tahap1/DatePicker_/btn_Pilih'))

WebUI.selectOptionByValue(findTestObject('PageDashboard_Tahap1/select_TempatLahir'), 'Kota Pekanbaru', true)

WebUI.selectOptionByValue(findTestObject('PageDashboard_Tahap1/select_Agama'), '2', true)

WebUI.selectOptionByValue(findTestObject('PageDashboard_Tahap1/select_StatusPernikahan'), 'M', true)

WebUI.setText(findTestObject('PageDashboard_Tahap1/TxtNamaIbuKandung'), NamaIbuKandung)

WebUI.selectOptionByValue(findTestObject('PageDashboard_Tahap1/select_Pendidikan'), '05', true)

WebUI.setText(findTestObject('PageDashboard_Tahap1/TxtAlamat'), 'Cluster Rumahan')

WebUI.setText(findTestObject('PageDashboard_Tahap1/TxtRt'), '013')

WebUI.setText(findTestObject('PageDashboard_Tahap1/TxtRw'), '002')

WebUI.selectOptionByValue(findTestObject('PageDashboard_Tahap1/select_Kab_Kota'), '203', true)

WebUI.selectOptionByValue(findTestObject('PageDashboard_Tahap1/select_Kecamatan'), '819e1e86-b1ee-42f9-a9c2-a33f58db66d4', 
    true)

WebUI.selectOptionByValue(findTestObject('PageDashboard_Tahap1/select_Kelurahan'), '55139ac6-d85c-4fff-ba4a-9bb896efe7e6', 
    true)

WebUI.selectOptionByValue(findTestObject('PageDashboard_Tahap1/select_Pekerjaan'), '02', true)

WebUI.selectOptionByValue(findTestObject('PageDashboard_Tahap1/select_BidangPekerjaan'), '55', true)

WebUI.selectOptionByValue(findTestObject('PageDashboard_Tahap1/select_Gaji'), '44000000', true)

WebUI.selectOptionByValue(findTestObject('PageDashboard_Tahap1/select_SumberPenghasilan'), '1', true)

WebUI.setText(findTestObject('PageDashboard_Tahap1/TxtKontakDarurat'), KontakDarurat)

WebUI.setText(findTestObject('PageDashboard_Tahap1/NoKontakDarurat'), NoKontakDarurat)

WebUI.click(findTestObject('PageDashboard_Tahap1/BtnLanjutkanTahap2'))

'Form Tahap 2'
NoKTP = RandomData.randomDoubleFunc(16)

NoNPWP = RandomData.randomDoubleFunc(15)

WebUI.setText(findTestObject('PageDashboardTahap2/input_KTP'), NoKTP)

WebUI.click(findTestObject('PageDashboardTahap2/label_e-KTPSeumurHidup'))

CustomKeywords.'alamiassessment.UploadFile.uploadFile'(findTestObject('Object Repository/PageDashboardTahap2/Upload Foto KTP'), 
    '"C:\\Users\\User\\Katalon Studio\\Alami Assessment\\Data Files\\KTP.png"')

WebUI.selectOptionByValue(findTestObject('PageDashboardTahap2/KotaPenerbitKTP'), 'Kota Depok', true)

WebUI.setText(findTestObject('PageDashboardTahap2/input_NPWP'), NoNPWP)

CustomKeywords.'alamiassessment.UploadFile.uploadFile'(findTestObject('PageDashboardTahap2/UploadFotoNPWP'), '"C:\\Users\\User\\Katalon Studio\\Alami Assessment\\Data Files\\NPWP.png"')

WebUI.click(findTestObject('PageDashboardTahap2/i_photo_camera'))

WebUI.delay(5)

'Allow Camera'
Robot robot = new Robot()

robot.keyPress(KeyEvent.VK_TAB)

robot.keyRelease(KeyEvent.VK_TAB)

robot.keyPress(KeyEvent.VK_TAB)

robot.keyRelease(KeyEvent.VK_TAB)

robot.keyPress(KeyEvent.VK_ENTER)

robot.keyRelease(KeyEvent.VK_ENTER)

WebUI.delay(5)

WebUI.click(findTestObject('PageDashboardTahap2/button_Ambil Foto'))

WebUI.click(findTestObject('PageDashboardTahap2/BtnLanjutkanTahap3'))

'Tahap 3'
WebUI.selectOptionByValue(findTestObject('Object Repository/tahap2dan3/ListBank'), '103', true)

NoRek = RandomData.randomDoubleFunc(12)

WebUI.setText(findTestObject('PageDashboarTahap3/input_NoRek'), NoRek)

WebUI.click(findTestObject('PageDashboarTahap3/label_Persetujuan1'))


WebUI.verifyElementPresent(findTestObject('Object Repository/tahap2dan3/div_Potensi Resiko'), GlobalVariable.timeout)

WebUI.scrollToElement(findTestObject('PageDashboarTahap3/label_Agreement1'), 0)

WebUI.click(findTestObject('PageDashboarTahap3/button_Saya Mengerti'))

WebUI.click(findTestObject('PageDashboarTahap3/label_Persetujuan2'))


WebUI.delay(5)

'JavaScript scroll to end'
WebElement element = WebUiCommonHelper.findWebElement(findTestObject('PageDashboarTahap3/canvas_agreement'), 30)

WebUI.executeJavaScript('arguments[0].scrollTop=arguments[0].scrollHeight', Arrays.asList(element))

WebUI.click(findTestObject('PageDashboarTahap3/button_Saya Mengerti_Komitmen_Keanggotaan'))

WebUI.click(findTestObject('PageDashboarTahap3/BtnDaftar'))

WebUI.click(findTestObject('PageDashboarTahap3/button_OK_ProsesTidakDapatDibatalkan'))

WebUI.click(findTestObject('PageDashboarTahap3/button_Kembali Ke Dashboard'))

'Validasi User Berhasil Mendaftar'
WebUI.verifyElementPresent(findTestObject('PageDashboarTahap3/VerifyTxtBerhasilMelengkapiData'), GlobalVariable.timeout)

