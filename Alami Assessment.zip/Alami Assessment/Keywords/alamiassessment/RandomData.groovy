package alamiassessment

import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.checkpoint.Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testcase.TestCase
import com.kms.katalon.core.testdata.TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows

import internal.GlobalVariable
import java.time.LocalDate
import org.apache.commons.lang3.RandomUtils
import java.time.format.DateTimeFormatter
import com.github.javafaker.Faker as Names

public class RandomData {
	public static String randomDoubleFunc(int length){

		/**
		 * Using Math Function
		 * import java.lang.Math
		 * length => 14 ktp, length => 12 phone number
		 */
		double rand = Math.random();
		String randomStr = String.valueOf(rand).replace("0.", "");
		return randomStr.substring(0, length);
	}

	public static String generateRandomNIK(){
		LocalDate birthOfDate = LocalDate.of(RandomUtils.nextInt(1980, 1996), RandomUtils.nextInt(1, 12), RandomUtils.nextInt(1, 30));
		String[] randomAreaCode = findTestData('API/Dataset_KTP').getAllData();
		int areaCode = new Random().nextInt(randomAreaCode.length);
		String nik = randomAreaCode[areaCode].toString().replaceAll('\\[', '').replaceAll('\\]','') + birthOfDate.format(DateTimeFormatter.ofPattern("ddMMyy")) + '000' + RandomUtils.nextInt(2, 9);
	}

	public static String generateRandomName() {
		def randomName = new Names();
		String fullName = randomName.name().nameWithMiddle();
	}

	public static String generateRandomFirstName() {
		def randomName = new Names();
		String fullName = randomName.name().firstName()
	}

	public static String generateRandomFullName() {
		def randomName = new Names();
		String fullName = randomName.name().fullName()
	}
}
