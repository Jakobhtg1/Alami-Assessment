package alamiassessment

import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.checkpoint.Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testcase.TestCase
import com.kms.katalon.core.testdata.TestData
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows

import org.openqa.selenium.By
import org.openqa.selenium.JavascriptExecutor
import org.openqa.selenium.WebElement
import org.openqa.selenium.support.ui.ExpectedConditions
import org.openqa.selenium.support.ui.WebDriverWait
import com.kms.katalon.core.webui.common.WebUiCommonHelper

import com.kms.katalon.core.util.KeywordUtil
import java.text.SimpleDateFormat

import com.kms.katalon.core.webui.driver.DriverFactory

import internal.GlobalVariable

public class DatePicker {
	/**
	 * Select mobile date picker with date format is 'dd MMMM yyyy',
	 * applicable to Wishlist Page, History Page, Report Page
	 * @param day 
	 * @param month
	 * @param year
	 */
	@Keyword
	def setDatePicker(String day, String month, String year) {
		String expectedDate = day + ' ' + month+ ' ' + year

		TestObject to = findTestObject('PageDashboard_Tahap1/datepicker1', [('day') : day])

		String format = "dd MMMM yyyy"

		setDatePicker(to, expectedDate, format)
	}
	/**
	 * Set mobile date picker as expected
	 * @param to represent a mobile element to select
	 * @param expectedDate Expected date that contains 'day month year',
	 * @param format that Date format such as 'dd MMMM yyyy'
	 */
	@Keyword
	def setMobileDatePicker(TestObject to, String expectedDate, String format) {

		if(Mobile.verifyElementVisible(to, GlobalVariable.timeout, FailureHandling.OPTIONAL) == false){
			WebUI.click(findTestObject('Android/DatePicker/BtnCancel'))
			KeywordUtil.markFailed('Cancel. Calender element is not found!')
		}

		String defaultDate =  WebUI.getAttribute(to, 'id', GlobalVariable.timeout)

		if(isValidFormat(defaultDate, format) == true) {

			boolean selected = false;

			while (selected == false) {

				String actualSelectedDate =  WebUI.getAttribute(to, 'id', GlobalVariable.timeout)

				Date firstYearMonth = changeDateFormat(actualSelectedDate, format, 'MMMM yyyy')
				Date secondYearMonth = changeDateFormat(expectedDate, format, 'MMMM yyyy')

				if (firstYearMonth.equals(secondYearMonth)) {
					WebUI.click(to)
					WebUI.click(findTestObject('PageDashboard_Tahap1/DatePicker_/btn_Pilih'))
					selected = true
				}

				if (firstYearMonth.after(secondYearMonth)) {
					WebUI.click(to)
					WebUI.click(findTestObject('PageDashboard_Tahap1/DatePicker_/btn_prevMonth'))
				}

				if (firstYearMonth.before(secondYearMonth)) {
					WebUI.click(to)
					WebUI.click(findTestObject('PageDashboard_Tahap1/DatePicker_/btn_MonthAfter'))
				}
			}
		}
		else {
			WebUI.click(findTestObject('PageDashboard_Tahap1/DatePicker_/btn_Batal'))
			KeywordUtil.markFailed('Cancel. Date format is invalid!')
		}
	}
	/**
	 * Check the date format is valid or not
	 * @param strDate
	 * @param format
	 * @return true if the date format is true; otherwise, false
	 */
	@Keyword
	def boolean isValidFormat(String strDate, String format) {
		SimpleDateFormat sdfrmt = new SimpleDateFormat(format);
		sdfrmt.setLenient(false);
		try {
			Date date = sdfrmt.parse(strDate);
			KeywordUtil.logInfo(strDate+" is valid date format")
			return true
		}
		catch (Exception e) {
			KeywordUtil.markError(strDate+" is invalid date format")
			return false
		}
	}
	/**
	 * Change date format to a new format
	 * @param date
	 * @param oldFormat
	 * @param newFormat
	 * @return date with the new format
	 */
	@Keyword
	def changeDateFormat(String date, String oldFormat, String newFormat) {
		SimpleDateFormat sdf = new SimpleDateFormat(oldFormat)
		Date strDate = sdf.parse(date)

		sdf.applyPattern(newFormat)

		String newStrDate = sdf.format(strDate)

		Date newDate = sdf.parse(newStrDate)
	}
}
