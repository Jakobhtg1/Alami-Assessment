
/**
 * This class is generated automatically by Katalon Studio and should not be modified or deleted.
 */

import java.lang.String

import com.kms.katalon.core.testobject.TestObject

import com.kms.katalon.core.model.FailureHandling


 /**
	 * Select mobile date picker with date format is 'dd MMMM yyyy',
	 * applicable to Wishlist Page, History Page, Report Page
	 * @param day 
	 * @param month
	 * @param year
	 */ 
def static "alamiassessment.DatePicker.setDatePicker"(
    	String day	
     , 	String month	
     , 	String year	) {
    (new alamiassessment.DatePicker()).setDatePicker(
        	day
         , 	month
         , 	year)
}

 /**
	 * Set mobile date picker as expected
	 * @param to represent a mobile element to select
	 * @param expectedDate Expected date that contains 'day month year',
	 * @param format that Date format such as 'dd MMMM yyyy'
	 */ 
def static "alamiassessment.DatePicker.setMobileDatePicker"(
    	TestObject to	
     , 	String expectedDate	
     , 	String format	) {
    (new alamiassessment.DatePicker()).setMobileDatePicker(
        	to
         , 	expectedDate
         , 	format)
}

 /**
	 * Check the date format is valid or not
	 * @param strDate
	 * @param format
	 * @return true if the date format is true; otherwise, false
	 */ 
def static "alamiassessment.DatePicker.isValidFormat"(
    	String strDate	
     , 	String format	) {
    (new alamiassessment.DatePicker()).isValidFormat(
        	strDate
         , 	format)
}

 /**
	 * Change date format to a new format
	 * @param date
	 * @param oldFormat
	 * @param newFormat
	 * @return date with the new format
	 */ 
def static "alamiassessment.DatePicker.changeDateFormat"(
    	String date	
     , 	String oldFormat	
     , 	String newFormat	) {
    (new alamiassessment.DatePicker()).changeDateFormat(
        	date
         , 	oldFormat
         , 	newFormat)
}

 /**
	 * File Upload
	 */ 
def static "alamiassessment.UploadFile.uploadFile"(
    	TestObject to	
     , 	String filePath	) {
    (new alamiassessment.UploadFile()).uploadFile(
        	to
         , 	filePath)
}


def static "com.katalon.plugin.keyword.calendar.SetDateCalendarKeyword.setDate"(
    	TestObject to	
     , 	int day	
     , 	int month	
     , 	int year	
     , 	int slideTimeOut	
     , 	FailureHandling flowControl	) {
    (new com.katalon.plugin.keyword.calendar.SetDateCalendarKeyword()).setDate(
        	to
         , 	day
         , 	month
         , 	year
         , 	slideTimeOut
         , 	flowControl)
}
